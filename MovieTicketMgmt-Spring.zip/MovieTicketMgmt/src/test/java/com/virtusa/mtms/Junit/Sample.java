package com.virtusa.mtms.Junit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.virtusa.mtms.Controller.AdminController;
import com.virtusa.mtms.Dao.ILocationRepositoryImpl;
import com.virtusa.mtms.Entity.Location;

@SpringBootTest
public class Sample {
	
	
	@Autowired
	AdminController admin;
	
	
	@Autowired
	ILocationRepositoryImpl loc;
	
	@Test
	public void addMoney()
	{
		List<Location> cl=loc.findAll();
		assertEquals(cl,admin.showLocation()); 
	}

}
