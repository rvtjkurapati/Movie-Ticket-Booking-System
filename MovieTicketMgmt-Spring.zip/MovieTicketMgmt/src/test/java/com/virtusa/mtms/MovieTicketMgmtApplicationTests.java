package com.virtusa.mtms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieTicketMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
