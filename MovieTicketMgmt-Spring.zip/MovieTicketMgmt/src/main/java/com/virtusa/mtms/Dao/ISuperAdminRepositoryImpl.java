package com.virtusa.mtms.Dao;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.mtms.Entity.SuperAdmin;
@Repository
@Transactional
public interface ISuperAdminRepositoryImpl extends JpaRepository<SuperAdmin, Integer>{

	@Query("select c from superadmin c where c.uname = ?1")
	public List<SuperAdmin> findByName(String name);
}
