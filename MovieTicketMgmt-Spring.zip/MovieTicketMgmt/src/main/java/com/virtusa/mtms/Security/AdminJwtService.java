package com.virtusa.mtms.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.virtusa.mtms.Entity.Admin;

@Service
public class AdminJwtService implements UserDetailsService {

	@Autowired
	IAdminJwt adminJwt;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Admin ad = adminJwt.findByUname(username);
		return new IAdminDetails(ad);
	}

}
