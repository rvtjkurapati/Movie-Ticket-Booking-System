package com.virtusa.mtms.Service;

import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.mtms.Dao.IBookingRepositoryImpl;
import com.virtusa.mtms.Dao.ICityRepositoryImpl;
import com.virtusa.mtms.Dao.ICustomerRepositoryImpl;
import com.virtusa.mtms.Dao.IMovieRepositoryImpl;
import com.virtusa.mtms.Dao.ITheatreRepositoryImpl;
import com.virtusa.mtms.Entity.Availability;
import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Theatre;
import com.virtusa.mtms.Exceptions.BadRequestException;
import com.virtusa.mtms.Exceptions.NotFoundException;

@Component
public class IGuestServiceImpl {

	@Autowired
	IMovieRepositoryImpl mv;

	@Autowired
	ICustomerRepositoryImpl cust;

	@Autowired
	ICityRepositoryImpl ct;

	@Autowired
	ITheatreRepositoryImpl ts;

	@Autowired
	IBookingRepositoryImpl book;

	@Autowired
	Environment env;

	private static final Logger guestlog = LoggerFactory.getLogger(IGuestServiceImpl.class);

	public List<City> showCity() {
		List<City> cl = ct.findAll();
		if (cl.isEmpty()) {
			guestlog.error(env.getProperty("cnf"));
			throw new NotFoundException(env.getProperty("cnf"));
		}
		guestlog.info(env.getProperty("cls"));
		return cl;
	}

	public String welcome() {
		String wel = "\t\t\t\t\t\t\t" + " __          __  _                          \r\n" + "\t\t\t\t\t\t\t"
				+ " \\ \\        / / | |                         \r\n" + "\t\t\t\t\t\t\t"
				+ "  \\ \\  /\\  / /__| | ___ ___  _ __ ___   ___ \r\n" + "\t\t\t\t\t\t\t"
				+ "   \\ \\/  \\/ / _ \\ |/ __/ _ \\| '_ ` _ \\ / _ \\\r\n" + "\t\t\t\t\t\t\t"
				+ "    \\  /\\  /  __/ | (_| (_) | | | | | |  __/\r\n" + "\t\t\t\t\t\t\t"
				+ "     \\/  \\/ \\___|_|\\___\\___/|_| |_| |_|\\___|";

		String to = "\t\t\t\t\t\t\t\t\t\t\t" + "  _        \r\n" + "\t\t\t\t\t\t\t\t\t\t\t" + " | |       \r\n"
				+ "\t\t\t\t\t\t\t\t\t\t\t" + " | |_ ___  \r\n" + "\t\t\t\t\t\t\t\t\t\t\t" + " | __/ _ \\ \r\n"
				+ "\t\t\t\t\t\t\t\t\t\t\t" + " | || (_) |\r\n" + "\t\t\t\t\t\t\t\t\t\t\t" + "  \\__\\___/ \r\n"
				+ "\t\t\t\t\t\t\t\t\t\t\t" + "           ";

		String on = "\t\t\t\t\t\t\t\t\t" + "   ____        _ _            \r\n" + "\t\t\t\t\t\t\t\t\t"
				+ "  / __ \\      | (_)           \r\n" + "\t\t\t\t\t\t\t\t\t" + " | |  | |_ __ | |_ _ __   ___ \r\n"
				+ "\t\t\t\t\t\t\t\t\t" + " | |  | | '_ \\| | | '_ \\ / _ \\\r\n" + "\t\t\t\t\t\t\t\t\t"
				+ " | |__| | | | | | | | | |  __/\r\n" + "\t\t\t\t\t\t\t\t\t" + "  \\____/|_| |_|_|_|_| |_|\\___|";

		String mv = "\t\t\t\t\t\t\t\t\t" + "  __  __            _      \r\n" + "\t\t\t\t\t\t\t\t\t"
				+ " |  \\/  |          (_)     \r\n" + "\t\t\t\t\t\t\t\t\t" + " | \\  / | _____   ___  ___ \r\n"
				+ "\t\t\t\t\t\t\t\t\t" + " | |\\/| |/ _ \\ \\ / / |/ _ \\\r\n" + "\t\t\t\t\t\t\t\t\t"
				+ " | |  | | (_) \\ V /| |  __/\r\n" + "\t\t\t\t\t\t\t\t\t" + " |_|  |_|\\___/ \\_/ |_|\\___|\r\n"
				+ "\t\t\t\t\t\t\t\t\t" + "                           ";

		String tkt = "\t\t\t\t\t\t\t\t\t" + "  _______ _      _        _   \r\n" + "\t\t\t\t\t\t\t\t\t"
				+ " |__   __(_)    | |      | |  \r\n" + "\t\t\t\t\t\t\t\t\t" + "    | |   _  ___| | _____| |_ \r\n"
				+ "\t\t\t\t\t\t\t\t\t" + "    | |  | |/ __| |/ / _ \\ __|\r\n" + "\t\t\t\t\t\t\t\t\t"
				+ "    | |  | | (__|   <  __/ |_ \r\n" + "\t\t\t\t\t\t\t\t\t" + "    |_|  |_|\\___|_|\\_\\___|\\__|";

		String bking = "\t\t\t\t\t\t\t\t" + "  ____              _    _             \r\n" + "\t\t\t\t\t\t\t\t"
				+ " |  _ \\            | |  (_)            \r\n" + "\t\t\t\t\t\t\t\t"
				+ " | |_) | ___   ___ | | ___ _ __   __ _ \r\n" + "\t\t\t\t\t\t\t\t"
				+ " |  _ < / _ \\ / _ \\| |/ / | '_ \\ / _` |\r\n" + "\t\t\t\t\t\t\t\t"
				+ " | |_) | (_) | (_) |   <| | | | | (_| |\r\n" + "\t\t\t\t\t\t\t\t"
				+ " |____/ \\___/ \\___/|_|\\_\\_|_| |_|\\__, |\r\n" + "\t\t\t\t\t\t\t\t"
				+ "                                  __/ |\r\n" + "\t\t\t\t\t\t\t\t"
				+ "                                 |___/ ";

		String sys = "\t\t\t\t\t\t\t\t\t" + "   _____           _                 \r\n" + "\t\t\t\t\t\t\t\t\t"
				+ "  / ____|         | |                \r\n" + "\t\t\t\t\t\t\t\t\t"
				+ " | (___  _   _ ___| |_ ___ _ __ ___  \r\n" + "\t\t\t\t\t\t\t\t\t"
				+ "  \\___ \\| | | / __| __/ _ \\ '_ ` _ \\ \r\n" + "\t\t\t\t\t\t\t\t\t"
				+ "  ____) | |_| \\__ \\ ||  __/ | | | | |\r\n" + "\t\t\t\t\t\t\t\t\t"
				+ " |_____/ \\__, |___/\\__\\___|_| |_| |_|\r\n" + "\t\t\t\t\t\t\t\t\t"
				+ "          __/ |                      \r\n" + "\t\t\t\t\t\t\t\t\t" + "         |___/   ";

		String str = wel + "\n\n" + to + "\n\n" + on + "\n\n" + mv + "\n\n" + tkt + "\n\n" + bking + "\n\n" + sys;
		return str;

	}

	public String register(@RequestBody Customer c) {

		List<Customer> ct = cust.findByEmail(c.getEmail());
		List<Customer> ctl = cust.findByPhone(c.getPhone());
		if (ct.isEmpty() && ctl.isEmpty()) {

			try {
				c.setBal(150);
				cust.save(c);
			} catch (Exception e) {
				guestlog.error(env.getProperty("acsr"));
				throw new BadRequestException(env.getProperty("acsr"));
			}
			guestlog.info(c.getUname() + " " + env.getProperty("rs"));
			return env.getProperty("rs");
		}

		else {
			guestlog.error(env.getProperty("apcs"));
			throw new BadRequestException(env.getProperty("apcs"));
		}

	}

	public List<Movie> showMovie() {
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);

		List<Movie> l = mv.findAllRunning(sqlDate);
		if (l.isEmpty()) {
			guestlog.error(env.getProperty("mvnf"));
			throw new NotFoundException(env.getProperty("mvnf"));
		}
		guestlog.info(env.getProperty("mvls"));
		return l;
	}

	public List<Movie> searchMovieByName(@PathVariable("id") String cid) {
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);

		List<Movie> obj = mv.findByNameRunning(cid, sqlDate);
		if (!obj.isEmpty()) {
			guestlog.info(env.getProperty("mvls"));
			return obj;
		}

		guestlog.error(env.getProperty("mvnf"));
		throw new NotFoundException(env.getProperty("mvnf"));
	}

	public List<Movie> searchMovieByCat(@PathVariable("id") String cid) {
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);

		List<Movie> obj = mv.findByCatRunning(cid, sqlDate);
		if (!obj.isEmpty()) {
			guestlog.info(env.getProperty("mvls"));
			return obj;
		}

		guestlog.error(env.getProperty("mvnf"));
		throw new NotFoundException(env.getProperty("mvnf"));
	}

	public List<Movie> searchMovieByGen(@PathVariable("id") String cid) {
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);
		List<Movie> obj = mv.findByGenRunning(cid, sqlDate);
		if (!obj.isEmpty()) {
			guestlog.info(env.getProperty("mvls"));
			return obj;
		}

		guestlog.error(env.getProperty("mvnf"));
		throw new NotFoundException(env.getProperty("mvnf"));
	}

	public List<Movie> searchMovieByLoc(@PathVariable("id") String cid) {
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);
		System.out.println(cid + "***********");
		City ctid = new City();
		ctid.setCid(ct.getCid(cid));
		System.out.println(ctid + "***********");
		List<Movie> mid = ts.getMid(ctid);
		System.out.println(mid + "***********");
		List<Movie> obj = new ArrayList<Movie>();
		for (Movie c : mid) {

			obj.add(mv.findByMid(c.getMid(), sqlDate));
		}
		if (!obj.isEmpty()) {
			guestlog.info(env.getProperty("mvls"));
			return obj;
		}

		guestlog.error(env.getProperty("mvnf"));
		throw new NotFoundException(env.getProperty("mvnf"));
	}

	public List<Theatre> searchTheatreByMvid(@PathVariable("id") Movie cid) {
		List<Theatre> obj = ts.findByMvid(cid);
		if (!obj.isEmpty()) {
			guestlog.info(env.getProperty("mvls"));
			return obj;
		}
		guestlog.error(env.getProperty("mvnf"));
		throw new NotFoundException(env.getProperty("mvnf"));
	}

	public String availability(@RequestBody Availability c) {

		try {

			Theatre tid = c.getTid();
			Date showdate = c.getShowdate();
			String showtime = c.getShowtime();
			Optional<Theatre> td = ts.findById(c.getTid().getTid());
			if (td.isEmpty()) {
				guestlog.error(env.getProperty("iti"));
				throw new NotFoundException(env.getProperty("iti"));
			}
			if (showtime.equals("Morning")) {
				return book.checkmornavail(tid, showdate)
						+ "\n\n\t\t\t\t\t\t\t\t\t\t\tPlease Login/Register to Proceed";
			}

			else if (showtime.equals("Matinee")) {
				return book.checkmatavail(tid, showdate) + "\n\n\t\t\t\t\t\t\t\t\t\t\tPlease Login/Register to Proceed";
			}

			else if (showtime.equals("SecondShow")) {
				return book.checksecavail(tid, showdate) + "\n\n\t\t\t\t\t\t\t\t\t\t\tPlease Login/Register to Proceed";
			}

			guestlog.error(env.getProperty("imd"));
			throw new BadRequestException(env.getProperty("imd"));
		} catch (Exception e) {
			throw new NotFoundException(e.getMessage());
		}

	}

}
