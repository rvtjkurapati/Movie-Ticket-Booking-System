package com.virtusa.mtms.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity(name="location")
@AllArgsConstructor
public class Location {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int lid;
	@Pattern(regexp = "^[A-Z].*$",message="Name Should Start with Capital letter")
    String lname;
    @ManyToOne
	@JoinColumn(name="cid")
    City cid;

}
