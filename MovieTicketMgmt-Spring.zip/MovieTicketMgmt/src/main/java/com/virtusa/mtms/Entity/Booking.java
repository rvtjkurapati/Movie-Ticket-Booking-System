package com.virtusa.mtms.Entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity(name="booking")
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Booking {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int bid;
	
	@Column(name="custId")
	int custId;
	
	String showtime;
	String seats;
	String phone;
	int screen;
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date showdate;
	
	@ManyToOne
	@JoinColumn(name="tid")
	Theatre tid;
	@ManyToOne
	@JoinColumn(name="mxid")
	Multiplex mxid;
	@ManyToOne
	@JoinColumn(name="mid")
	Movie mid; 
	

}
