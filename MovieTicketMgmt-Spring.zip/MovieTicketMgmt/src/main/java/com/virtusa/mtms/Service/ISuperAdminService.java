package com.virtusa.mtms.Service;

import java.util.List;
import java.util.Optional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import com.virtusa.mtms.Entity.Admin;
import com.virtusa.mtms.Entity.Booking;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.SuperAdmin;

public interface ISuperAdminService {

	public String superlogin(@RequestBody SuperAdmin c);

	public String logOut();

	public String changePwd(@RequestBody SuperAdmin c);

	public List<Admin> showAdmin();

	public String addAdmin(@RequestBody Admin c);

	public String updateAdmin(@RequestBody Admin c, @PathVariable int lid);

	public Optional<Admin> searchAdminById(@PathVariable("id") int cid);

	public List<Admin> searchAdminByName(@PathVariable("id") String cid);

	public String deleteAdmin(@PathVariable int cid);

	public List<Booking> showBooking();

	public Optional<Booking> searchBookingById(@PathVariable("id") int cid);

	public List<Booking> searchBookingByCid(@PathVariable("id") int cid);

	public List<Booking> searchBookingByMid(@PathVariable("id") Movie cid);

	public String deleteBooking(@PathVariable int cid);

}
