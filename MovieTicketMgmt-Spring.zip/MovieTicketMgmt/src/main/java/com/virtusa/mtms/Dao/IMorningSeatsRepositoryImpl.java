package com.virtusa.mtms.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.mtms.Entity.Morningseats;

public interface IMorningSeatsRepositoryImpl extends JpaRepository<Morningseats, Integer> {

}
