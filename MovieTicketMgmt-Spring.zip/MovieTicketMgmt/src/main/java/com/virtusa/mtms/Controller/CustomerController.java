package com.virtusa.mtms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.mtms.Email.ForgotPasswordService;
import com.virtusa.mtms.Entity.Admin;
import com.virtusa.mtms.Entity.Availability;
import com.virtusa.mtms.Entity.Book;
import com.virtusa.mtms.Entity.Booking;
import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Theatre;
import com.virtusa.mtms.Service.ICustomerServiceImpl;

@RestController
@RequestMapping("/cust")

public class CustomerController {
	
	@Autowired
	ICustomerServiceImpl custRepo;
	
	@Autowired
	ForgotPasswordService fpwd;
	
	@PostMapping("/login")
	public String login(@RequestBody Customer c)
	{
		return custRepo.custLogin(c);
	}
	
	@GetMapping("/info")
	public String info()
	{
		return custRepo.custInfo();
	}
	
	@GetMapping("/logOut")
	public String logOut()
	{
		return custRepo.logOut();
	}
	
	@PutMapping("/addMoney")         
	public String addMoney (@RequestBody Customer c) {
		return custRepo.addMoney(c);
	}
	
	@GetMapping("/getBookings")
	public List<Booking> getBookings()
	{
		return custRepo.getBooking();
	}
	
	@DeleteMapping("/cancelTicket/{id}")         
	public String cancelTicket (@PathVariable("id") int cid) {
		return custRepo.cancelTicket(cid);
	}
	
	@GetMapping("/showcity")
	public List<City> showCity()
	{
		return custRepo.showCity();
	}
	
	
	@GetMapping("/showmovie")
	public List<Movie> showMovies()
	{
		return custRepo.showMovie();
	}
	
	
	@GetMapping("/searchmoviebyName/{id}")
	public List<Movie> searchmoviebyName(@PathVariable("id") String id)
	{
		return custRepo.searchMovieByName(id);
	}
	
	@GetMapping("/searchmoviebyCat/{id}")
	public List<Movie> searchmoviebyCat(@PathVariable("id") String id)
	{
		return custRepo.searchMovieByCat(id);
	}
	
	@GetMapping("/searchmoviebyGen/{id}")
	public List<Movie> searchmoviebyGen(@PathVariable("id") String id)
	{
		return custRepo.searchMovieByGen(id);
	}
	
	@GetMapping("/searchmoviebyLocation/{id}")
	public List<Movie> searchmoviebyLoc(@PathVariable("id") String id)
	{
		return custRepo.searchMovieByLoc(id);
	}
	
	
	@GetMapping("/searchTheatrebyMid/{id}")
	public List<Theatre> searchtheatrebyMid(@PathVariable("id") Movie id)
	{
		return custRepo.searchTheatreByMvid(id);
	}
	
	@GetMapping("/checkavail")
	public String checkAvail(@RequestBody Availability c)
	{
		return custRepo.availability(c);
	}
	
	@PostMapping("/bookmovie")
	public String book(@RequestBody Book c)
	{
		return custRepo.booking(c);
	}
	
	@PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestParam("email") String email){
        this.fpwd.forgotPassword(email);
        return new ResponseEntity<>("OTP sent to the registered Email Id", HttpStatus.OK);
    }
    
    @PostMapping("/validate-otp")
    public ResponseEntity<String> validateOtp(@RequestParam("otp") String otp, @RequestParam("password") String password){
        this.fpwd.validateOtp(otp,password);
        return new ResponseEntity<>("Password changed successfully", HttpStatus.OK);
    }
    
    
    @PutMapping("/editProfile")         
	public String updateCust (@RequestBody Customer c) {
		return custRepo.updateCust(c);
	}
	

}
