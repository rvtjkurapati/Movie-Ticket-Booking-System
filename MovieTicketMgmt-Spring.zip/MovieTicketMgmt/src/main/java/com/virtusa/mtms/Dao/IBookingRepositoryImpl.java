package com.virtusa.mtms.Dao;

import java.sql.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.mtms.Entity.Booking;
import com.virtusa.mtms.Entity.Matineeseats;
import com.virtusa.mtms.Entity.Morningseats;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Multiplex;
import com.virtusa.mtms.Entity.Secondshowseats;
import com.virtusa.mtms.Entity.Theatre;
@Transactional
public interface IBookingRepositoryImpl extends JpaRepository<Booking, Integer> {
	
	
	@Query("select c from booking c where c.custId  =?1")
	public List<Booking> findByCid(int cid);
	
	@Query("select bid from booking c where c.custId  =?1")
	public List<Integer> getByCid(int cid);
	
	@Query("select c from booking c where c.mid  =?1")
	public List<Booking> findByMid(Movie mid);
	
	@Query("select a from morningseats a where a.tid=?1 and a.showdate=?2")
	public List<Morningseats> checkmornavail(Theatre tid,Date date);
	
	@Query("select a from matineeseats a where a.tid=?1 and a.showdate=?2")
	public List<Matineeseats> checkmatavail(Theatre tid,Date date);
	
	@Query("select a from secondshowseats a where a.tid=?1 and a.showdate=?2")
	public List<Secondshowseats> checksecavail(Theatre tid,Date date);
	
	
	@Modifying
	@Query(value="update morningseats  set A1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA1(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set A2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA2(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set A3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA3(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set A4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA4(@Param("tid") Theatre tid,@Param("date")Date date);	

	@Modifying
	@Query(value="update morningseats  set A5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA5(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set A6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA6(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set A7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA7(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set A8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA8(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set A9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA9(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set A10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA10(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set A11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA11(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set A12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornA12(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set B1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB1(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB2(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB3(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB4(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB5(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB6(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB7(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB8(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB9(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB10(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB11(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set B12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornB12(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC1(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC2(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC3(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC4(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC5(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC6(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC7(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC8(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC9(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC10(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC11(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set C12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornC12(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD1(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD2(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD3(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD4(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD5(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD6(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD7(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD8(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD9(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD10(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD11(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set D12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornD12(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set E1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE1(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE2(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE3(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE4(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE5(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE6(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE7(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE8(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE9(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE10(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE11(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set E12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornE12(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set F1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF1(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF2(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF3(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF4(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF5(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF6(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF7(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF8(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF9(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF10(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF11(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set F12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornF12(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG1(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG2(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG3(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG4(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG5(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG6(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG7(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG8(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG9(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG10(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG11(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set G12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornG12(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH1(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH2(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH3(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH4(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH5(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH6(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH7(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH8(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH9(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH10(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH11(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set H12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornH12(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI1(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI2(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI3(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI4(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI5(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI6(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI7(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI8(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI9(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI10(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI11(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set I12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornI12(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set J1=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ1(@Param("tid") Theatre tid,@Param("date")Date date);
	
	@Modifying
	@Query(value="update morningseats  set J2=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ2(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set J3=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ3(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set J4=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ4(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set J5=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ5(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set J6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ6(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set J7=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ7(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set J8=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ8(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set J9=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ9(@Param("tid") Theatre tid,@Param("date")Date date);
	

	@Modifying
	@Query(value="update morningseats  set J10=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ10(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set J11=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ11(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying
	@Query(value="update morningseats  set J12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int mornJ12(@Param("tid") Theatre tid,@Param("date")Date date);
	
	
	

	@Modifying 
	@Query(value="update matineeseats  set A1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set A2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set A3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set A4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA4(@Param("tid") Theatre tid,@Param("date")Date date);	 

	@Modifying 
	@Query(value="update matineeseats  set A5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set A6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set A7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set A8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set A9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA9(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying 
	@Query(value="update matineeseats  set A10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set A11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set A12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matA12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB2(@Param("tid") Theatre tid,@Param("date")Date date);
	 
	@Modifying 
	@Query(value="update matineeseats  set B3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB5(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying 
	@Query(value="update matineeseats  set B6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set B12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matB12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC3(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying 
	@Query(value="update matineeseats  set C4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set C12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matC12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD3(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying 
	@Query(value="update matineeseats  set D4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set D11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set D12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matD12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set E12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matE12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set F7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set F11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set F12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matF12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set G1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set G12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matG12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set H1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set H2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set H3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set H4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set H5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set H6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set H7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH7(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying 
	@Query(value="update matineeseats  set H8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set H9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set H10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set H11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set H12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matH12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI4(@Param("tid") Theatre tid,@Param("date")Date date); 
 
	@Modifying 
	@Query(value="update matineeseats  set I5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set I11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI11(@Param("tid") Theatre tid,@Param("date")Date date); 
 
	@Modifying 
	@Query(value="update matineeseats  set I12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matI12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ9(@Param("tid") Theatre tid,@Param("date")Date date); 
 
	@Modifying 
	@Query(value="update matineeseats  set J10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update matineeseats  set J12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int matJ12(@Param("tid") Theatre tid,@Param("date")Date date); 

	

	@Modifying 
	@Query(value="update secondshowseats  set A1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set A2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set A3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set A4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA4(@Param("tid") Theatre tid,@Param("date")Date date);	 

	@Modifying
	@Query(value="update secondshowseats  set A5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA5(@Param("tid") Theatre tid,@Param("date")Date date);
 
	@Modifying 
	@Query(value="update secondshowseats  set A6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set A7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set A8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set A9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set A10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update secondshowseats  set A11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set A12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secA12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B6=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int secB6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set B10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update secondshowseats  set B11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update secondshowseats  set B12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secB12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update secondshowseats  set C2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set C12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secC12(@Param("tid") Theatre tid,@Param("date")Date date); 


	@Modifying 
	@Query(value="update secondshowseats  set D1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD1(@Param("tid") Theatre tid,@Param("date")Date date); 


	@Modifying 
	@Query(value="update secondshowseats  set D2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set D3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set D4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set D5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set D6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set D7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set D8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set D9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update secondshowseats  set D10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set D11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set D12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secD12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set E12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secE12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update secondshowseats  set F1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set F12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secF12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set G12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secG12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set H12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secH12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set I12=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secI12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J1=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J2=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J3=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J4=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J5=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J6=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J7=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ7(@Param("tid") Theatre tid,@Param("date")Date date); 
 
	@Modifying 
	@Query(value="update secondshowseats  set J8=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J9=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J10=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J11=0 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int secJ11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update secondshowseats  set J12=0 where tid=:tid and showdate=:date", nativeQuery = true)
	public int secJ12(@Param("tid") Theatre tid,@Param("date")Date date); 

	
	
	
	@Modifying 
	@Query(value="update morningseats  set A1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA4(@Param("tid") Theatre tid,@Param("date")Date date);	 

	@Modifying 
	@Query(value="update morningseats  set A5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set A12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornA12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set B12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornB12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set C12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornC12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set D12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornD12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE4(@Param("tid") Theatre tid,@Param("date")Date date);

	@Modifying 
	@Query(value="update morningseats  set E5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set E12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornE12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set F1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF1(@Param("tid") Theatre tid,@Param("date")Date date); 
  
	@Modifying 
	@Query(value="update morningseats  set F2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set F3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set F4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set F5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set F6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set F7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set F8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set F9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set F10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying
	@Query(value="update morningseats  set F11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying
	@Query(value="update morningseats  set F12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornF12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set G12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornG12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set H12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornH12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying
	@Query(value="update morningseats  set I2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set I12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornI12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J1=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ1(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J2=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J3=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J4=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ4(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J5=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ6(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J7=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J8=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ8(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J9=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J10=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ10(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J11=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ11(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying 
	@Query(value="update morningseats  set J12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modmornJ12(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying  
	@Query(value="update matineeseats  set A1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set A2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set A3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set A4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA4(@Param("tid") Theatre tid,@Param("date")Date date);	  

	@Modifying  
	@Query(value="update matineeseats  set A5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set A6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set A7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set A8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set A9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA9(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying  
	@Query(value="update matineeseats  set A10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set A11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA11(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update matineeseats  set A12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatA12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB2(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying  
	@Query(value="update matineeseats  set B3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying  
	@Query(value="update matineeseats  set B6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set B12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatB12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying  
	@Query(value="update matineeseats  set C4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set C12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatC12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD3(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying  
	@Query(value="update matineeseats  set D4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set D11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD11(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update matineeseats  set D12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatD12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set E12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatE12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set F1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set F2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set F3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set F4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF4(@Param("tid") Theatre tid,@Param("date")Date date);  


	@Modifying  
	@Query(value="update matineeseats  set F5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF5(@Param("tid") Theatre tid,@Param("date")Date date);  


	@Modifying  
	@Query(value="update matineeseats  set F6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF6(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update matineeseats  set F7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set F8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set F9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set F10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set F11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF11(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update matineeseats  set F12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatF12(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update matineeseats  set G1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update matineeseats  set G2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set G12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatG12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set H1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH1(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update matineeseats  set H2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set H3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH3(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update matineeseats  set H4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set H5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set H6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set H7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH7(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying  
	@Query(value="update matineeseats  set H8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set H9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set H10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set H11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set H12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatH12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI7(@Param("tid") Theatre tid,@Param("date")Date date);  
	
	@Modifying  
	@Query(value="update matineeseats  set I8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set I12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatI12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update matineeseats  set J12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modmatJ12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set A1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set A2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set A3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set A4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA4(@Param("tid") Theatre tid,@Param("date")Date date);	  

	@Modifying 
	@Query(value="update secondshowseats  set A5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA5(@Param("tid") Theatre tid,@Param("date")Date date); 

	@Modifying  
	@Query(value="update secondshowseats  set A6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set A7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update secondshowseats  set A8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set A9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set A10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA10(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set A11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set A12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecA12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B6=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modsecB6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set B10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB10(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set B11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB11(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set B12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecB12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC1(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set C2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying 
	@Query(value="update secondshowseats  set C8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set C12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecC12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD3(@Param("tid") Theatre tid,@Param("date")Date date);  
  
	@Modifying  
	@Query(value="update secondshowseats  set D4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD9(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set D10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set D12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecD12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set E12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecE12(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set F1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF10(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set F12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecF12(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set G1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG1(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set G2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set G3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG3(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set G4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG4(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set G5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set G6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set G7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG7(@Param("tid") Theatre tid,@Param("date")Date date);  
 
	@Modifying  
	@Query(value="update secondshowseats  set G8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG8(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set G9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG9(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set G10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG10(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set G11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG11(@Param("tid") Theatre tid,@Param("date")Date date);  
  
	@Modifying  
	@Query(value="update secondshowseats  set G12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecG12(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set H1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH1(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set H2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH2(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set H3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH3(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set H4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH4(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set H5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH5(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set H6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH6(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set H7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH7(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set H8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH8(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set H9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH9(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set H10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH10(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set H11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set H12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecH12(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set I1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI1(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set I2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI2(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set I3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI3(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set I4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI4(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set I5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI5(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set I6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI6(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set I7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI7(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying
	@Query(value="update secondshowseats  set I8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI8(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set I9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI9(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set I10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI10(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set I11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI11(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set I12=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecI12(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set J1=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ1(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set J2=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ2(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set J3=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ3(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set J4=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ4(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set J5=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ5(@Param("tid") Theatre tid,@Param("date")Date date);   

	@Modifying  
	@Query(value="update secondshowseats  set J6=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ6(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set J7=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ7(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set J8=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ8(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set J9=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ9(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set J10=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ10(@Param("tid") Theatre tid,@Param("date")Date date);    

	@Modifying  
	@Query(value="update secondshowseats  set J11=1 where tid=:tid and showdate=:date", nativeQuery = true)  
	public int modsecJ11(@Param("tid") Theatre tid,@Param("date")Date date);  

	@Modifying  
	@Query(value="update secondshowseats  set J12=1 where tid=:tid and showdate=:date", nativeQuery = true) 
	public int modsecJ12(@Param("tid") Theatre tid,@Param("date")Date date); 

}
