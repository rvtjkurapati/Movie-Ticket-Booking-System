package com.virtusa.mtms.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.mtms.Dao.IBookingRepositoryImpl;
import com.virtusa.mtms.Dao.ICityRepositoryImpl;
import com.virtusa.mtms.Dao.ICustomerRepositoryImpl;
import com.virtusa.mtms.Dao.IMovieRepositoryImpl;
import com.virtusa.mtms.Dao.ITheatreRepositoryImpl;
import com.virtusa.mtms.Entity.Admin;
import com.virtusa.mtms.Entity.Availability;
import com.virtusa.mtms.Entity.Book;
import com.virtusa.mtms.Entity.Booking;
import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Theatre;
import com.virtusa.mtms.Exceptions.BadRequestException;
import com.virtusa.mtms.Exceptions.ForbiddenException;
import com.virtusa.mtms.Exceptions.NotFoundException;

@Component
public class ICustomerServiceImpl {

	@Autowired
	IMovieRepositoryImpl mv;

	@Autowired
	ICustomerRepositoryImpl cust;

	@Autowired
	ICityRepositoryImpl ct;

	@Autowired
	ITheatreRepositoryImpl ts;

	@Autowired
	IBookingRepositoryImpl book;

	@Autowired
	Environment env;

	private static final Logger custlog = LoggerFactory.getLogger(ICustomerServiceImpl.class);
	public static Customer cs = new Customer();

	public String custLogin(@RequestBody Customer c) {
		String mail = c.getEmail();
		String pwd = c.getPwd();
		List<Customer> cl = cust.findByEmail(mail);

		try {

			if ((cl.get(0).getPwd()).equals(pwd)) {
				cs = cl.get(0);

				custlog.info(cs.getCustId() + " " + env.getProperty("cli"));
				return env.getProperty("cli");
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new NotFoundException(env.getProperty("pli"));
		}
		custlog.error(env.getProperty("clf"));
		return env.getProperty("clf");
	}

	public String logOut() {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		cs = null;

		return "You Have Been Logged Out";

	}

	public String custInfo() {

		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		Optional<Customer> obj1 = cust.findById(cs.getCustId());
		cs = obj1.get();
		custlog.info(cs.getCustId() + " " + env.getProperty("cpd"));
		return "\t\t\t\t\t\t\t\t\tMy Profile\n\n" + "\t\tUsername: " + cs.getUname() + ",\t\tPassword: " + cs.getPwd()
				+ ",\t\tPhone: " + cs.getPhone() + ",\n\n\t\t\t\t\tEmail: " + cs.getEmail() + ",\t\tBalance: "
				+ cs.getBal();

	}

	public String addMoney(@RequestBody Customer c) {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		if (c.getBal() > 5000) {
			custlog.error(env.getProperty("be"));
			throw new BadRequestException(env.getProperty("be"));
		}
		int bal = cs.getBal();
		Optional<Customer> obj = cust.findById(cs.getCustId()).map(mcity -> {
			mcity.setBal(c.getBal() + bal);
			return cust.save(mcity);
		});

		if (obj.isEmpty()) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		custlog.info(c.getCustId() + " " + env.getProperty("awu"));
		return env.getProperty("awu");

	}

	public List<Booking> getBooking() {

		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		List<Booking> obj = book.findByCid(cs.getCustId());
		if (!obj.isEmpty()) {
			custlog.info(env.getProperty("abs"));
			return obj;
		}

		custlog.error(env.getProperty("bnf"));
		throw new NotFoundException(env.getProperty("bnf"));
	}

	public String updateCust(@RequestBody Customer c) {

		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		Optional<Customer> obj1 = cust.findById(cs.getCustId()).map(mcity -> {
			mcity.setUname(c.getUname());
			mcity.setPwd(c.getPwd());
			mcity.setPhone(c.getPhone());
			mcity.setEmail(c.getEmail());
			try {
				return cust.save(mcity);
			}

			catch (Exception e) {

				custlog.error(env.getProperty("apcs"));
				throw new BadRequestException(env.getProperty("apcs"));
			}

		});

		custlog.info(env.getProperty("csus"));
		return env.getProperty("csus");
	}

	public String cancelTicket(@PathVariable("id") int bid) {

		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		Optional<Booking> obj = book.findById(bid);

		if (!obj.isEmpty()) {
			String seats = obj.get().getSeats();
			String ss = seats;
			String[] str = ss.split("[,]");
			int count = str.length;
			Optional<Theatre> t = ts.findById(obj.get().getTid().getTid());
			double add1 = (t.get().getPrice()) * 0.7;
			int add = (int) add1;

			Optional<Customer> obj1 = cust.findById(cs.getCustId()).map(mcity -> {
				mcity.setBal(cs.getBal() + add * count); // validate
				return cust.save(mcity);
			});

			Theatre tid = obj.get().getTid();
			java.util.Date date = obj.get().getShowdate();

			java.sql.Date showdate = new java.sql.Date(date.getTime());

			String showtime = obj.get().getShowtime();

			if (showtime.equals("Morning")) {
				for (String a : str) {
					System.out.println(a);
					if (a.equals("A1")) {
						book.modmornA1(tid, showdate);
					}

					else if (a.equals("A2")) {
						book.modmornA2(tid, showdate);
					}

					else if (a.equals("A3")) {
						book.modmornA3(tid, showdate);
					}

					else if (a.equals("A4")) {
						book.modmornA4(tid, showdate);
					}

					else if (a.equals("A5")) {
						book.modmornA5(tid, showdate);
					}

					else if (a.equals("A6")) {
						book.modmornA6(tid, showdate);
					}

					else if (a.equals("A7")) {
						book.modmornA7(tid, showdate);
					}

					else if (a.equals("A8")) {
						book.modmornA8(tid, showdate);
					}

					else if (a.equals("A9")) {
						book.modmornA9(tid, showdate);
					}

					else if (a.equals("A10")) {
						book.modmornA10(tid, showdate);
					}

					else if (a.equals("A11")) {
						book.modmornA11(tid, showdate);
					}

					else if (a.equals("A12")) {
						book.modmornA12(tid, showdate);
					}

					else if (a.equals("B1")) {
						book.modmornB1(tid, showdate);
					}

					else if (a.equals("B2")) {
						book.modmornB2(tid, showdate);
					}

					else if (a.equals("B3")) {
						book.modmornB3(tid, showdate);
					}

					else if (a.equals("B4")) {
						book.modmornB4(tid, showdate);
					}

					else if (a.equals("B5")) {
						book.modmornB5(tid, showdate);
					}

					else if (a.equals("B6")) {
						book.modmornB6(tid, showdate);
					}

					else if (a.equals("B7")) {
						book.modmornB7(tid, showdate);
					}

					else if (a.equals("B8")) {
						book.modmornB8(tid, showdate);
					}

					else if (a.equals("B9")) {
						book.modmornB9(tid, showdate);
					}

					else if (a.equals("B10")) {
						book.modmornB10(tid, showdate);
					}

					else if (a.equals("B11")) {
						book.modmornB11(tid, showdate);
					}

					else if (a.equals("B12")) {
						book.modmornB12(tid, showdate);
					}

					else if (a.equals("C1")) {
						book.modmornC1(tid, showdate);
					}

					else if (a.equals("C2")) {
						book.modmornC2(tid, showdate);
					}

					else if (a.equals("C3")) {
						book.modmornC3(tid, showdate);
					}

					else if (a.equals("C4")) {
						book.modmornC4(tid, showdate);
					}

					else if (a.equals("C5")) {
						book.modmornC5(tid, showdate);
					}

					else if (a.equals("C6")) {
						book.modmornC6(tid, showdate);
					}

					else if (a.equals("C7")) {
						book.modmornC7(tid, showdate);
					}

					else if (a.equals("C8")) {
						book.modmornC8(tid, showdate);
					}

					else if (a.equals("C9")) {
						book.modmornC9(tid, showdate);
					}

					else if (a.equals("C10")) {
						book.modmornC10(tid, showdate);
					}

					else if (a.equals("C11")) {
						book.modmornC11(tid, showdate);
					}

					else if (a.equals("C12")) {
						book.modmornC12(tid, showdate);
					}

					else if (a.equals("D1")) {
						book.modmornD1(tid, showdate);
					}

					else if (a.equals("D2")) {
						book.modmornD2(tid, showdate);
					}

					else if (a.equals("D3")) {
						book.modmornD3(tid, showdate);
					}

					else if (a.equals("D4")) {
						book.modmornD4(tid, showdate);
					}

					else if (a.equals("D5")) {
						book.modmornD5(tid, showdate);
					}

					else if (a.equals("D6")) {
						book.modmornD6(tid, showdate);
					}

					else if (a.equals("D7")) {
						book.modmornD7(tid, showdate);
					}

					else if (a.equals("D8")) {
						book.modmornD8(tid, showdate);
					}

					else if (a.equals("D9")) {
						book.modmornD9(tid, showdate);
					}

					else if (a.equals("D10")) {
						book.modmornD10(tid, showdate);
					}

					else if (a.equals("D11")) {
						book.modmornD11(tid, showdate);
					}

					else if (a.equals("D12")) {
						book.modmornD12(tid, showdate);
					}

					else if (a.equals("E1")) {
						book.modmornE1(tid, showdate);
					}

					else if (a.equals("E2")) {
						book.modmornE2(tid, showdate);
					}

					else if (a.equals("E3")) {
						book.modmornE3(tid, showdate);
					}

					else if (a.equals("E4")) {
						book.modmornE4(tid, showdate);
					}

					else if (a.equals("E5")) {
						book.modmornE5(tid, showdate);
					}

					else if (a.equals("E6")) {
						book.modmornE6(tid, showdate);
					}

					else if (a.equals("E7")) {
						book.modmornE7(tid, showdate);
					}

					else if (a.equals("E8")) {
						book.modmornE8(tid, showdate);
					}

					else if (a.equals("E9")) {
						book.modmornE9(tid, showdate);
					}

					else if (a.equals("E10")) {
						book.modmornE10(tid, showdate);
					}

					else if (a.equals("E11")) {
						book.modmornE11(tid, showdate);
					}

					else if (a.equals("E12")) {
						book.modmornE12(tid, showdate);
					}

					else if (a.equals("F1")) {
						book.modmornF1(tid, showdate);
					}

					else if (a.equals("F2")) {
						book.modmornF2(tid, showdate);
					}

					else if (a.equals("F3")) {
						book.modmornF3(tid, showdate);
					}

					else if (a.equals("F4")) {
						book.modmornF4(tid, showdate);
					}

					else if (a.equals("F5")) {
						book.modmornF5(tid, showdate);
					}

					else if (a.equals("F6")) {
						book.modmornF6(tid, showdate);
					}

					else if (a.equals("F7")) {
						book.modmornF7(tid, showdate);
					}

					else if (a.equals("F8")) {
						book.modmornF8(tid, showdate);
					}

					else if (a.equals("F9")) {
						book.modmornF9(tid, showdate);
					}

					else if (a.equals("F10")) {
						book.modmornF10(tid, showdate);
					}

					else if (a.equals("F11")) {
						book.modmornF11(tid, showdate);
					}

					else if (a.equals("F12")) {
						book.modmornF12(tid, showdate);
					}

					else if (a.equals("G1")) {
						book.modmornG1(tid, showdate);
					}

					else if (a.equals("G2")) {
						book.modmornG2(tid, showdate);
					}

					else if (a.equals("G3")) {
						book.modmornG3(tid, showdate);
					}

					else if (a.equals("G4")) {
						book.modmornG4(tid, showdate);
					}

					else if (a.equals("G5")) {
						book.modmornG5(tid, showdate);
					}

					else if (a.equals("G6")) {
						book.modmornG6(tid, showdate);
					}

					else if (a.equals("G7")) {
						book.modmornG7(tid, showdate);
					}

					else if (a.equals("G8")) {
						book.modmornG8(tid, showdate);
					}

					else if (a.equals("G9")) {
						book.modmornG9(tid, showdate);
					}

					else if (a.equals("G10")) {
						book.modmornG10(tid, showdate);
					}

					else if (a.equals("G11")) {
						book.modmornG11(tid, showdate);
					}

					else if (a.equals("G12")) {
						book.modmornG12(tid, showdate);
					}

					else if (a.equals("H1")) {
						book.modmornH1(tid, showdate);
					}

					else if (a.equals("H2")) {
						book.modmornH2(tid, showdate);
					}

					else if (a.equals("H3")) {
						book.modmornH3(tid, showdate);
					}

					else if (a.equals("H4")) {
						book.modmornH4(tid, showdate);
					}

					else if (a.equals("H5")) {
						book.modmornH5(tid, showdate);
					}

					else if (a.equals("H6")) {
						book.modmornH6(tid, showdate);
					}

					else if (a.equals("H7")) {
						book.modmornH7(tid, showdate);
					}

					else if (a.equals("H8")) {
						book.modmornH8(tid, showdate);
					}

					else if (a.equals("H9")) {
						book.modmornH9(tid, showdate);
					}

					else if (a.equals("H10")) {
						book.modmornH10(tid, showdate);
					}

					else if (a.equals("H11")) {
						book.modmornH11(tid, showdate);
					}

					else if (a.equals("H12")) {
						book.modmornH12(tid, showdate);
					}

					else if (a.equals("I1")) {
						book.modmornI1(tid, showdate);
					}

					else if (a.equals("I2")) {
						book.modmornI2(tid, showdate);
					}

					else if (a.equals("I3")) {
						book.modmornI3(tid, showdate);
					}

					else if (a.equals("I4")) {
						book.modmornI4(tid, showdate);
					}

					else if (a.equals("I5")) {
						book.modmornI5(tid, showdate);
					}

					else if (a.equals("I6")) {
						book.modmornI6(tid, showdate);
					}

					else if (a.equals("I7")) {
						book.modmornI7(tid, showdate);
					}

					else if (a.equals("I8")) {
						book.modmornI8(tid, showdate);
					}

					else if (a.equals("I9")) {
						book.modmornI9(tid, showdate);
					}

					else if (a.equals("I10")) {
						book.modmornI10(tid, showdate);
					}

					else if (a.equals("I11")) {
						book.modmornI11(tid, showdate);
					}

					else if (a.equals("I12")) {
						book.modmornI12(tid, showdate);
					}

					else if (a.equals("J1")) {
						book.modmornJ1(tid, showdate);
					}

					else if (a.equals("J2")) {
						book.modmornJ2(tid, showdate);
					}

					else if (a.equals("J3")) {
						book.modmornJ3(tid, showdate);
					}

					else if (a.equals("J4")) {
						book.modmornJ4(tid, showdate);
					}

					else if (a.equals("J5")) {
						book.modmornJ5(tid, showdate);
					}

					else if (a.equals("J6")) {
						book.modmornJ6(tid, showdate);
					}

					else if (a.equals("J7")) {
						book.modmornJ7(tid, showdate);
					}

					else if (a.equals("J8")) {
						book.modmornJ8(tid, showdate);
					}

					else if (a.equals("J9")) {
						book.modmornJ9(tid, showdate);
					}

					else if (a.equals("J10")) {
						book.modmornJ10(tid, showdate);
					}

					else if (a.equals("J11")) {
						book.modmornJ11(tid, showdate);
					}

					else if (a.equals("J12")) {
						book.modmornJ12(tid, showdate);
					}
				}
			}

			else if (showtime.equals("Matinee")) {
				for (String a : str) {
					System.out.println(a);
					if (a.equals("A1")) {
						book.modmatA1(tid, showdate);
					}

					else if (a.equals("A2")) {
						book.modmatA2(tid, showdate);
					}

					else if (a.equals("A3")) {
						book.modmatA3(tid, showdate);
					}

					else if (a.equals("A4")) {
						book.modmatA4(tid, showdate);
					}

					else if (a.equals("A5")) {
						book.modmatA5(tid, showdate);
					}

					else if (a.equals("A6")) {
						book.modmatA6(tid, showdate);
					}

					else if (a.equals("A7")) {
						book.modmatA7(tid, showdate);
					}

					else if (a.equals("A8")) {
						book.modmatA8(tid, showdate);
					}

					else if (a.equals("A9")) {
						book.modmatA9(tid, showdate);
					}

					else if (a.equals("A10")) {
						book.modmatA10(tid, showdate);
					}

					else if (a.equals("A11")) {
						book.modmatA11(tid, showdate);
					}

					else if (a.equals("A12")) {
						book.modmatA12(tid, showdate);
					}

					else if (a.equals("B1")) {
						book.modmatB1(tid, showdate);
					}

					else if (a.equals("B2")) {
						book.modmatB2(tid, showdate);
					}

					else if (a.equals("B3")) {
						book.modmatB3(tid, showdate);
					}

					else if (a.equals("B4")) {
						book.modmatB4(tid, showdate);
					}

					else if (a.equals("B5")) {
						book.modmatB5(tid, showdate);
					}

					else if (a.equals("B6")) {
						book.modmatB6(tid, showdate);
					}

					else if (a.equals("B7")) {
						book.modmatB7(tid, showdate);
					}

					else if (a.equals("B8")) {
						book.modmatB8(tid, showdate);
					}

					else if (a.equals("B9")) {
						book.modmatB9(tid, showdate);
					}

					else if (a.equals("B10")) {
						book.modmatB10(tid, showdate);
					}

					else if (a.equals("B11")) {
						book.modmatB11(tid, showdate);
					}

					else if (a.equals("B12")) {
						book.modmatB12(tid, showdate);
					}

					else if (a.equals("C1")) {
						book.modmatC1(tid, showdate);
					}

					else if (a.equals("C2")) {
						book.modmatC2(tid, showdate);
					}

					else if (a.equals("C3")) {
						book.modmatC3(tid, showdate);
					}

					else if (a.equals("C4")) {
						book.modmatC4(tid, showdate);
					}

					else if (a.equals("C5")) {
						book.modmatC5(tid, showdate);
					}

					else if (a.equals("C6")) {
						book.modmatC6(tid, showdate);
					}

					else if (a.equals("C7")) {
						book.modmatC7(tid, showdate);
					}

					else if (a.equals("C8")) {
						book.modmatC8(tid, showdate);
					}

					else if (a.equals("C9")) {
						book.modmatC9(tid, showdate);
					}

					else if (a.equals("C10")) {
						book.modmatC10(tid, showdate);
					}

					else if (a.equals("C11")) {
						book.modmatC11(tid, showdate);
					}

					else if (a.equals("C12")) {
						book.modmatC12(tid, showdate);
					}

					else if (a.equals("D1")) {
						book.modmatD1(tid, showdate);
					}

					else if (a.equals("D2")) {
						book.modmatD2(tid, showdate);
					}

					else if (a.equals("D3")) {
						book.modmatD3(tid, showdate);
					}

					else if (a.equals("D4")) {
						book.modmatD4(tid, showdate);
					}

					else if (a.equals("D5")) {
						book.modmatD5(tid, showdate);
					}

					else if (a.equals("D6")) {
						book.modmatD6(tid, showdate);
					}

					else if (a.equals("D7")) {
						book.modmatD7(tid, showdate);
					}

					else if (a.equals("D8")) {
						book.modmatD8(tid, showdate);
					}

					else if (a.equals("D9")) {
						book.modmatD9(tid, showdate);
					}

					else if (a.equals("D10")) {
						book.modmatD10(tid, showdate);
					}

					else if (a.equals("D11")) {
						book.modmatD11(tid, showdate);
					}

					else if (a.equals("D12")) {
						book.modmatD12(tid, showdate);
					}

					else if (a.equals("E1")) {
						book.modmatE1(tid, showdate);
					}

					else if (a.equals("E2")) {
						book.modmatE2(tid, showdate);
					}

					else if (a.equals("E3")) {
						book.modmatE3(tid, showdate);
					}

					else if (a.equals("E4")) {
						book.modmatE4(tid, showdate);
					}

					else if (a.equals("E5")) {
						book.modmatE5(tid, showdate);
					}

					else if (a.equals("E6")) {
						book.modmatE6(tid, showdate);
					}

					else if (a.equals("E7")) {
						book.modmatE7(tid, showdate);
					}

					else if (a.equals("E8")) {
						book.modmatE8(tid, showdate);
					}

					else if (a.equals("E9")) {
						book.modmatE9(tid, showdate);
					}

					else if (a.equals("E10")) {
						book.modmatE10(tid, showdate);
					}

					else if (a.equals("E11")) {
						book.modmatE11(tid, showdate);
					}

					else if (a.equals("E12")) {
						book.modmatE12(tid, showdate);
					}

					else if (a.equals("F1")) {
						book.modmatF1(tid, showdate);
					}

					else if (a.equals("F2")) {
						book.modmatF2(tid, showdate);
					}

					else if (a.equals("F3")) {
						book.modmatF3(tid, showdate);
					}

					else if (a.equals("F4")) {
						book.modmatF4(tid, showdate);
					}

					else if (a.equals("F5")) {
						book.modmatF5(tid, showdate);
					}

					else if (a.equals("F6")) {
						book.modmatF6(tid, showdate);
					}

					else if (a.equals("F7")) {
						book.modmatF7(tid, showdate);
					}

					else if (a.equals("F8")) {
						book.modmatF8(tid, showdate);
					}

					else if (a.equals("F9")) {
						book.modmatF9(tid, showdate);
					}

					else if (a.equals("F10")) {
						book.modmatF10(tid, showdate);
					}

					else if (a.equals("F11")) {
						book.modmatF11(tid, showdate);
					}

					else if (a.equals("F12")) {
						book.modmatF12(tid, showdate);
					}

					else if (a.equals("G1")) {
						book.modmatG1(tid, showdate);
					}

					else if (a.equals("G2")) {
						book.modmatG2(tid, showdate);
					}

					else if (a.equals("G3")) {
						book.modmatG3(tid, showdate);
					}

					else if (a.equals("G4")) {
						book.modmatG4(tid, showdate);
					}

					else if (a.equals("G5")) {
						book.modmatG5(tid, showdate);
					}

					else if (a.equals("G6")) {
						book.modmatG6(tid, showdate);
					}

					else if (a.equals("G7")) {
						book.modmatG7(tid, showdate);
					}

					else if (a.equals("G8")) {
						book.modmatG8(tid, showdate);
					}

					else if (a.equals("G9")) {
						book.modmatG9(tid, showdate);
					}

					else if (a.equals("G10")) {
						book.modmatG10(tid, showdate);
					}

					else if (a.equals("G11")) {
						book.modmatG11(tid, showdate);
					}

					else if (a.equals("G12")) {
						book.modmatG12(tid, showdate);
					}

					else if (a.equals("H1")) {
						book.modmatH1(tid, showdate);
					}

					else if (a.equals("H2")) {
						book.modmatH2(tid, showdate);
					}

					else if (a.equals("H3")) {
						book.modmatH3(tid, showdate);
					}

					else if (a.equals("H4")) {
						book.modmatH4(tid, showdate);
					}

					else if (a.equals("H5")) {
						book.modmatH5(tid, showdate);
					}

					else if (a.equals("H6")) {
						book.modmatH6(tid, showdate);
					}

					else if (a.equals("H7")) {
						book.modmatH7(tid, showdate);
					}

					else if (a.equals("H8")) {
						book.modmatH8(tid, showdate);
					}

					else if (a.equals("H9")) {
						book.modmatH9(tid, showdate);
					}

					else if (a.equals("H10")) {
						book.modmatH10(tid, showdate);
					}

					else if (a.equals("H11")) {
						book.modmatH11(tid, showdate);
					}

					else if (a.equals("H12")) {
						book.modmatH12(tid, showdate);
					}

					else if (a.equals("I1")) {
						book.modmatI1(tid, showdate);
					}

					else if (a.equals("I2")) {
						book.modmatI2(tid, showdate);
					}

					else if (a.equals("I3")) {
						book.modmatI3(tid, showdate);
					}

					else if (a.equals("I4")) {
						book.modmatI4(tid, showdate);
					}

					else if (a.equals("I5")) {
						book.modmatI5(tid, showdate);
					}

					else if (a.equals("I6")) {
						book.modmatI6(tid, showdate);
					}

					else if (a.equals("I7")) {
						book.modmatI7(tid, showdate);
					}

					else if (a.equals("I8")) {
						book.modmatI8(tid, showdate);
					}

					else if (a.equals("I9")) {
						book.modmatI9(tid, showdate);
					}

					else if (a.equals("I10")) {
						book.modmatI10(tid, showdate);
					}

					else if (a.equals("I11")) {
						book.modmatI11(tid, showdate);
					}

					else if (a.equals("I12")) {
						book.modmatI12(tid, showdate);
					}

					else if (a.equals("J1")) {
						book.modmatJ1(tid, showdate);
					}

					else if (a.equals("J2")) {
						book.modmatJ2(tid, showdate);
					}

					else if (a.equals("J3")) {
						book.modmatJ3(tid, showdate);
					}

					else if (a.equals("J4")) {
						book.modmatJ4(tid, showdate);
					}

					else if (a.equals("J5")) {
						book.modmatJ5(tid, showdate);
					}

					else if (a.equals("J6")) {
						book.modmatJ6(tid, showdate);
					}

					else if (a.equals("J7")) {
						book.modmatJ7(tid, showdate);
					}

					else if (a.equals("J8")) {
						book.modmatJ8(tid, showdate);
					}

					else if (a.equals("J9")) {
						book.modmatJ9(tid, showdate);
					}

					else if (a.equals("J10")) {
						book.modmatJ10(tid, showdate);
					}

					else if (a.equals("J11")) {
						book.modmatJ11(tid, showdate);
					}

					else if (a.equals("J12")) {
						book.modmatJ12(tid, showdate);
					}
				}
			}

			else if (showtime.equals("SecondShow")) {
				for (String a : str) {
					System.out.println(a);

					if (a.equals("A1")) {
						book.modsecA1(tid, showdate);
					}

					else if (a.equals("A2")) {
						book.modsecA2(tid, showdate);
					}

					else if (a.equals("A3")) {
						book.modsecA3(tid, showdate);
					}

					else if (a.equals("A4")) {
						book.modsecA4(tid, showdate);
					}

					else if (a.equals("A5")) {
						book.modsecA5(tid, showdate);
					}

					else if (a.equals("A6")) {
						book.modsecA6(tid, showdate);
					}

					else if (a.equals("A7")) {
						book.modsecA7(tid, showdate);
					}

					else if (a.equals("A8")) {
						book.modsecA8(tid, showdate);
					}

					else if (a.equals("A9")) {
						book.modsecA9(tid, showdate);
					}

					else if (a.equals("A10")) {
						book.modsecA10(tid, showdate);
					}

					else if (a.equals("A11")) {
						book.modsecA11(tid, showdate);
					}

					else if (a.equals("A12")) {
						book.modsecA12(tid, showdate);
					}

					else if (a.equals("B1")) {
						book.modsecB1(tid, showdate);
					}

					else if (a.equals("B2")) {
						book.modsecB2(tid, showdate);
					}

					else if (a.equals("B3")) {
						book.modsecB3(tid, showdate);
					}

					else if (a.equals("B4")) {
						book.modsecB4(tid, showdate);
					}

					else if (a.equals("B5")) {
						book.modsecB5(tid, showdate);
					}

					else if (a.equals("B6")) {
						book.modsecB6(tid, showdate);
					}

					else if (a.equals("B7")) {
						book.modsecB7(tid, showdate);
					}

					else if (a.equals("B8")) {
						book.modsecB8(tid, showdate);
					}

					else if (a.equals("B9")) {
						book.modsecB9(tid, showdate);
					}

					else if (a.equals("B10")) {
						book.modsecB10(tid, showdate);
					}

					else if (a.equals("B11")) {
						book.modsecB11(tid, showdate);
					}

					else if (a.equals("B12")) {
						book.modsecB12(tid, showdate);
					}

					else if (a.equals("C1")) {
						book.modsecC1(tid, showdate);
					}

					else if (a.equals("C2")) {
						book.modsecC2(tid, showdate);
					}

					else if (a.equals("C3")) {
						book.modsecC3(tid, showdate);
					}

					else if (a.equals("C4")) {
						book.modsecC4(tid, showdate);
					}

					else if (a.equals("C5")) {
						book.modsecC5(tid, showdate);
					}

					else if (a.equals("C6")) {
						book.modsecC6(tid, showdate);
					}

					else if (a.equals("C7")) {
						book.modsecC7(tid, showdate);
					}

					else if (a.equals("C8")) {
						book.modsecC8(tid, showdate);
					}

					else if (a.equals("C9")) {
						book.modsecC9(tid, showdate);
					}

					else if (a.equals("C10")) {
						book.modsecC10(tid, showdate);
					}

					else if (a.equals("C11")) {
						book.modsecC11(tid, showdate);
					}

					else if (a.equals("C12")) {
						book.modsecC12(tid, showdate);
					}

					else if (a.equals("D1")) {
						book.modsecD1(tid, showdate);
					}

					else if (a.equals("D2")) {
						book.modsecD2(tid, showdate);
					}

					else if (a.equals("D3")) {
						book.modsecD3(tid, showdate);
					}

					else if (a.equals("D4")) {
						book.modsecD4(tid, showdate);
					}

					else if (a.equals("D5")) {
						book.modsecD5(tid, showdate);
					}

					else if (a.equals("D6")) {
						book.modsecD6(tid, showdate);
					}

					else if (a.equals("D7")) {
						book.modsecD7(tid, showdate);
					}

					else if (a.equals("D8")) {
						book.modsecD8(tid, showdate);
					}

					else if (a.equals("D9")) {
						book.modsecD9(tid, showdate);
					}

					else if (a.equals("D10")) {
						book.modsecD10(tid, showdate);
					}

					else if (a.equals("D11")) {
						book.modsecD11(tid, showdate);
					}

					else if (a.equals("D12")) {
						book.modsecD12(tid, showdate);
					}

					else if (a.equals("E1")) {
						book.modsecE1(tid, showdate);
					}

					else if (a.equals("E2")) {
						book.modsecE2(tid, showdate);
					}

					else if (a.equals("E3")) {
						book.modsecE3(tid, showdate);
					}

					else if (a.equals("E4")) {
						book.modsecE4(tid, showdate);
					}

					else if (a.equals("E5")) {
						book.modsecE5(tid, showdate);
					}

					else if (a.equals("E6")) {
						book.modsecE6(tid, showdate);
					}

					else if (a.equals("E7")) {
						book.modsecE7(tid, showdate);
					}

					else if (a.equals("E8")) {
						book.modsecE8(tid, showdate);
					}

					else if (a.equals("E9")) {
						book.modsecE9(tid, showdate);
					}

					else if (a.equals("E10")) {
						book.modsecE10(tid, showdate);
					}

					else if (a.equals("E11")) {
						book.modsecE11(tid, showdate);
					}

					else if (a.equals("E12")) {
						book.modsecE12(tid, showdate);
					}

					else if (a.equals("F1")) {
						book.modsecF1(tid, showdate);
					}

					else if (a.equals("F2")) {
						book.modsecF2(tid, showdate);
					}

					else if (a.equals("F3")) {
						book.modsecF3(tid, showdate);
					}

					else if (a.equals("F4")) {
						book.modsecF4(tid, showdate);
					}

					else if (a.equals("F5")) {
						book.modsecF5(tid, showdate);
					}

					else if (a.equals("F6")) {
						book.modsecF6(tid, showdate);
					}

					else if (a.equals("F7")) {
						book.modsecF7(tid, showdate);
					}

					else if (a.equals("F8")) {
						book.modsecF8(tid, showdate);
					}

					else if (a.equals("F9")) {
						book.modsecF9(tid, showdate);
					}

					else if (a.equals("F10")) {
						book.modsecF10(tid, showdate);
					}

					else if (a.equals("F11")) {
						book.modsecF11(tid, showdate);
					}

					else if (a.equals("F12")) {
						book.modsecF12(tid, showdate);
					}

					else if (a.equals("G1")) {
						book.modsecG1(tid, showdate);
					}

					else if (a.equals("G2")) {
						book.modsecG2(tid, showdate);
					}

					else if (a.equals("G3")) {
						book.modsecG3(tid, showdate);
					}

					else if (a.equals("G4")) {
						book.modsecG4(tid, showdate);
					}

					else if (a.equals("G5")) {
						book.modsecG5(tid, showdate);
					}

					else if (a.equals("G6")) {
						book.modsecG6(tid, showdate);
					}

					else if (a.equals("G7")) {
						book.modsecG7(tid, showdate);
					}

					else if (a.equals("G8")) {
						book.modsecG8(tid, showdate);
					}

					else if (a.equals("G9")) {
						book.modsecG9(tid, showdate);
					}

					else if (a.equals("G10")) {
						book.modsecG10(tid, showdate);
					}

					else if (a.equals("G11")) {
						book.modsecG11(tid, showdate);
					}

					else if (a.equals("G12")) {
						book.modsecG12(tid, showdate);
					}

					else if (a.equals("H1")) {
						book.modsecH1(tid, showdate);
					}

					else if (a.equals("H2")) {
						book.modsecH2(tid, showdate);
					}

					else if (a.equals("H3")) {
						book.modsecH3(tid, showdate);
					}

					else if (a.equals("H4")) {
						book.modsecH4(tid, showdate);
					}

					else if (a.equals("H5")) {
						book.modsecH5(tid, showdate);
					}

					else if (a.equals("H6")) {
						book.modsecH6(tid, showdate);
					}

					else if (a.equals("H7")) {
						book.modsecH7(tid, showdate);
					}

					else if (a.equals("H8")) {
						book.modsecH8(tid, showdate);
					}

					else if (a.equals("H9")) {
						book.modsecH9(tid, showdate);
					}

					else if (a.equals("H10")) {
						book.modsecH10(tid, showdate);
					}

					else if (a.equals("H11")) {
						book.modsecH11(tid, showdate);
					}

					else if (a.equals("H12")) {
						book.modsecH12(tid, showdate);
					}

					else if (a.equals("I1")) {
						book.modsecI1(tid, showdate);
					}

					else if (a.equals("I2")) {
						book.modsecI2(tid, showdate);
					}

					else if (a.equals("I3")) {
						book.modsecI3(tid, showdate);
					}

					else if (a.equals("I4")) {
						book.modsecI4(tid, showdate);
					}

					else if (a.equals("I5")) {
						book.modsecI5(tid, showdate);
					}

					else if (a.equals("I6")) {
						book.modsecI6(tid, showdate);
					}

					else if (a.equals("I7")) {
						book.modsecI7(tid, showdate);
					}

					else if (a.equals("I8")) {
						book.modsecI8(tid, showdate);
					}

					else if (a.equals("I9")) {
						book.modsecI9(tid, showdate);
					}

					else if (a.equals("I10")) {
						book.modsecI10(tid, showdate);
					}

					else if (a.equals("I11")) {
						book.modsecI11(tid, showdate);
					}

					else if (a.equals("I12")) {
						book.modsecI12(tid, showdate);
					}

					else if (a.equals("J1")) {
						book.modsecJ1(tid, showdate);
					}

					else if (a.equals("J2")) {
						book.modsecJ2(tid, showdate);
					}

					else if (a.equals("J3")) {
						book.modsecJ3(tid, showdate);
					}

					else if (a.equals("J4")) {
						book.modsecJ4(tid, showdate);
					}

					else if (a.equals("J5")) {
						book.modsecJ5(tid, showdate);
					}

					else if (a.equals("J6")) {
						book.modsecJ6(tid, showdate);
					}

					else if (a.equals("J7")) {
						book.modsecJ7(tid, showdate);
					}

					else if (a.equals("J8")) {
						book.modsecJ8(tid, showdate);
					}

					else if (a.equals("J9")) {
						book.modsecJ9(tid, showdate);
					}

					else if (a.equals("J10")) {
						book.modsecJ10(tid, showdate);
					}

					else if (a.equals("J11")) {
						book.modsecJ11(tid, showdate);
					}

					else if (a.equals("J12")) {
						book.modsecJ12(tid, showdate);
					}
				}
			}

			book.deleteById(bid);
			custlog.info(env.getProperty("ctc") + " " + bid);
			return env.getProperty("ctc");

		} else {
			custlog.error(env.getProperty("ibi"));
			throw new BadRequestException(env.getProperty("ibi"));
		}
	}

	public List<City> showCity() {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		List<City> cl = ct.findAll();
		if (cl.isEmpty()) {
			custlog.error(env.getProperty("cnf"));
			throw new NotFoundException(env.getProperty("cnf"));
		}
		custlog.info(env.getProperty("cls"));
		return cl;
	}

	public List<Movie> showMovie() {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);

		List<Movie> l = mv.findAllRunning(sqlDate);
		if (l.isEmpty()) {
			custlog.error(env.getProperty("mvnf"));
			throw new NotFoundException(env.getProperty("mvnf"));
		}
		custlog.info(env.getProperty("mvls"));
		return l;
	}

	public List<Movie> searchMovieByName(@PathVariable("id") String cid) {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);

		List<Movie> obj = mv.findByNameRunning(cid, sqlDate);
		if (!obj.isEmpty()) {
			custlog.info(env.getProperty("mvls"));
			return obj;
		}

		custlog.error(env.getProperty("mvnf"));
		throw new NotFoundException(env.getProperty("mvnf"));
	}

	public List<Movie> searchMovieByCat(@PathVariable("id") String cid) {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);

		List<Movie> obj = mv.findByCatRunning(cid, sqlDate);
		if (!obj.isEmpty()) {
			custlog.info(env.getProperty("mvls"));
			return obj;
		}

		custlog.error(env.getProperty("mvnf"));
		throw new NotFoundException(env.getProperty("mvnf"));
	}

	public List<Movie> searchMovieByGen(@PathVariable("id") String cid) {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);
		List<Movie> obj = mv.findByGenRunning(cid, sqlDate);
		if (!obj.isEmpty()) {
			custlog.info(env.getProperty("mvls"));
			return obj;
		}

		custlog.error(env.getProperty("mvnf"));
		throw new NotFoundException(env.getProperty("mvnf"));
	}

	public List<Movie> searchMovieByLoc(@PathVariable("id") String cid) {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(date.getTime());
		System.out.println(sqlDate);
		City ctid = new City();
		ctid.setCid(ct.getCid(cid));
		List<Movie> mid = ts.getMid(ctid);
		List<Movie> obj = new ArrayList<Movie>();
		for (Movie c : mid) {

			obj.add(mv.findByMid(c.getMid(), sqlDate));
		}
		if (!obj.isEmpty()) {
			custlog.info(env.getProperty("mvls"));
			return obj;
		}

		custlog.error(env.getProperty("mvnf"));
		throw new NotFoundException(env.getProperty("mvnf"));
	}

	public List<Theatre> searchTheatreByMvid(@PathVariable("id") Movie cid) {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		List<Theatre> obj = ts.findByMvid(cid);
		if (!obj.isEmpty()) {
			custlog.info(env.getProperty("tls"));
			return obj;
		}
		custlog.error(env.getProperty("tnf"));
		throw new NotFoundException(env.getProperty("tnf"));
	}

	public String availability(@RequestBody Availability c) {
		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		try {

			Theatre tid = c.getTid();
			Date showdate = c.getShowdate();
			String showtime = c.getShowtime();
			Optional<Theatre> td = ts.findById(c.getTid().getTid());
			if (td.isEmpty()) {
				custlog.error(env.getProperty("iti"));
				throw new NotFoundException(env.getProperty("iti"));
			}
			if (showtime.equals("Morning")) {
				return book.checkmornavail(tid, showdate) + "";
			}

			else if (showtime.equals("Matinee")) {
				return book.checkmatavail(tid, showdate) + "";
			}

			else if (showtime.equals("SecondShow")) {
				return book.checksecavail(tid, showdate) + "";
			}

			custlog.error(env.getProperty("imd"));
			throw new BadRequestException(env.getProperty("imd"));
		} catch (Exception e) {
			throw new NotFoundException(e.getMessage());
		}

	}

	public String booking(@RequestBody Book c) {

		try {
			Optional<Customer> obj = cust.findById(cs.getCustId());

			if (obj.isEmpty()) {
				custlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			custlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		try {
			Theatre tid = c.getTid();
			Date showdate = c.getShowdate();
			String pay = c.getPayment();
			String seats = c.getSeats();
			String showtime = c.getShowtime();
			String s = seats;
			String[] str = s.split("[,]");
			int count = str.length;
			Optional<Theatre> t = ts.findById(tid.getTid());
			double add1 = (t.get().getPrice());
			int add = (int) add1;
			if (!pay.equals("Wallet") && !pay.equals("Card")) {
				return "Invalid Payment Method";
			}

			if (pay.equals("Wallet")) {

				if (cs.getBal() < add * count) {
					return "Wallet Balance insufficient";
				}

				Optional<Customer> obj1 = cust.findById(cs.getCustId()).map(mcity -> {
					mcity.setBal(cs.getBal() - add * count);
					return cust.save(mcity);
				});
			}
			if (showtime.equals("Morning")) {

				for (String a : str) {
					System.out.println(a);
					if (a.equals("A1")) {
						book.mornA1(tid, showdate);
					}

					else if (a.equals("A2")) {
						book.mornA2(tid, showdate);
					}

					else if (a.equals("A3")) {
						book.mornA3(tid, showdate);
					}

					else if (a.equals("A4")) {
						book.mornA4(tid, showdate);
					}

					else if (a.equals("A5")) {
						book.mornA5(tid, showdate);
					}

					else if (a.equals("A6")) {
						book.mornA6(tid, showdate);
					}

					else if (a.equals("A7")) {
						book.mornA7(tid, showdate);
					}

					else if (a.equals("A8")) {
						book.mornA8(tid, showdate);
					}

					else if (a.equals("A9")) {
						book.mornA9(tid, showdate);
					}

					else if (a.equals("A10")) {
						book.mornA10(tid, showdate);
					}

					else if (a.equals("A11")) {
						book.mornA11(tid, showdate);
					}

					else if (a.equals("A12")) {
						book.mornA12(tid, showdate);
					}

					else if (a.equals("B1")) {
						book.mornB1(tid, showdate);
					}

					else if (a.equals("B2")) {
						book.mornB2(tid, showdate);
					}

					else if (a.equals("B3")) {
						book.mornB3(tid, showdate);
					}

					else if (a.equals("B4")) {
						book.mornB4(tid, showdate);
					}

					else if (a.equals("B5")) {
						book.mornB5(tid, showdate);
					}

					else if (a.equals("B6")) {
						book.mornB6(tid, showdate);
					}

					else if (a.equals("B7")) {
						book.mornB7(tid, showdate);
					}

					else if (a.equals("B8")) {
						book.mornB8(tid, showdate);
					}

					else if (a.equals("B9")) {
						book.mornB9(tid, showdate);
					}

					else if (a.equals("B10")) {
						book.mornB10(tid, showdate);
					}

					else if (a.equals("B11")) {
						book.mornB11(tid, showdate);
					}

					else if (a.equals("B12")) {
						book.mornB12(tid, showdate);
					}

					else if (a.equals("C1")) {
						book.mornC1(tid, showdate);
					}

					else if (a.equals("C2")) {
						book.mornC2(tid, showdate);
					}

					else if (a.equals("C3")) {
						book.mornC3(tid, showdate);
					}

					else if (a.equals("C4")) {
						book.mornC4(tid, showdate);
					}

					else if (a.equals("C5")) {
						book.mornC5(tid, showdate);
					}

					else if (a.equals("C6")) {
						book.mornC6(tid, showdate);
					}

					else if (a.equals("C7")) {
						book.mornC7(tid, showdate);
					}

					else if (a.equals("C8")) {
						book.mornC8(tid, showdate);
					}

					else if (a.equals("C9")) {
						book.mornC9(tid, showdate);
					}

					else if (a.equals("C10")) {
						book.mornC10(tid, showdate);
					}

					else if (a.equals("C11")) {
						book.mornC11(tid, showdate);
					}

					else if (a.equals("C12")) {
						book.mornC12(tid, showdate);
					}

					else if (a.equals("D1")) {
						book.mornD1(tid, showdate);
					}

					else if (a.equals("D2")) {
						book.mornD2(tid, showdate);
					}

					else if (a.equals("D3")) {
						book.mornD3(tid, showdate);
					}

					else if (a.equals("D4")) {
						book.mornD4(tid, showdate);
					}

					else if (a.equals("D5")) {
						book.mornD5(tid, showdate);
					}

					else if (a.equals("D6")) {
						book.mornD6(tid, showdate);
					}

					else if (a.equals("D7")) {
						book.mornD7(tid, showdate);
					}

					else if (a.equals("D8")) {
						book.mornD8(tid, showdate);
					}

					else if (a.equals("D9")) {
						book.mornD9(tid, showdate);
					}

					else if (a.equals("D10")) {
						book.mornD10(tid, showdate);
					}

					else if (a.equals("D11")) {
						book.mornD11(tid, showdate);
					}

					else if (a.equals("D12")) {
						book.mornD12(tid, showdate);
					}

					else if (a.equals("E1"))

					{
						book.mornE1(tid, showdate);
					}

					else if (a.equals("E2")) {
						book.mornE2(tid, showdate);
					}

					else if (a.equals("E3")) {
						book.mornE3(tid, showdate);
					}

					else if (a.equals("E4")) {
						book.mornE4(tid, showdate);
					}

					else if (a.equals("E5")) {
						book.mornE5(tid, showdate);
					}

					else if (a.equals("E6")) {
						book.mornE6(tid, showdate);
					}

					else if (a.equals("E7")) {
						book.mornE7(tid, showdate);
					}

					else if (a.equals("E8")) {
						book.mornE8(tid, showdate);
					}

					else if (a.equals("E9")) {
						book.mornE9(tid, showdate);
					}

					else if (a.equals("E10")) {
						book.mornE10(tid, showdate);
					}

					else if (a.equals("E11")) {
						book.mornE11(tid, showdate);
					}

					else if (a.equals("E12")) {
						book.mornE12(tid, showdate);
					}

					else if (a.equals("F1")) {
						book.mornF1(tid, showdate);
					}

					else if (a.equals("F2")) {
						book.mornF2(tid, showdate);
					}

					else if (a.equals("F3")) {
						book.mornF3(tid, showdate);
					}

					else if (a.equals("F4")) {
						book.mornF4(tid, showdate);
					}

					else if (a.equals("F5")) {
						book.mornF5(tid, showdate);
					}

					else if (a.equals("F6")) {
						book.mornF6(tid, showdate);
					}

					else if (a.equals("F7")) {
						book.mornF7(tid, showdate);
					}

					else if (a.equals("F8")) {
						book.mornF8(tid, showdate);
					}

					else if (a.equals("F9")) {
						book.mornF9(tid, showdate);
					}

					else if (a.equals("F10")) {
						book.mornF10(tid, showdate);
					}

					else if (a.equals("F11")) {
						book.mornF11(tid, showdate);
					}

					else if (a.equals("F12")) {
						book.mornF12(tid, showdate);
					}

					else if (a.equals("G1")) {
						book.mornG1(tid, showdate);
					}

					else if (a.equals("G2")) {
						book.mornG2(tid, showdate);
					}

					else if (a.equals("G3")) {
						book.mornG3(tid, showdate);
					}

					else if (a.equals("G4")) {
						book.mornG4(tid, showdate);
					}

					else if (a.equals("G5")) {
						book.mornG5(tid, showdate);
					}

					else if (a.equals("G6")) {
						book.mornG6(tid, showdate);
					}

					else if (a.equals("G7")) {
						book.mornG7(tid, showdate);
					}

					else if (a.equals("G8")) {
						book.mornG8(tid, showdate);
					}

					else if (a.equals("G9")) {
						book.mornG9(tid, showdate);
					}

					else if (a.equals("G10")) {
						book.mornG10(tid, showdate);
					}

					else if (a.equals("G11")) {
						book.mornG11(tid, showdate);
					}

					else if (a.equals("G12")) {
						book.mornG12(tid, showdate);
					}

					else if (a.equals("H1")) {
						book.mornH1(tid, showdate);
					}

					else if (a.equals("H2")) {
						book.mornH2(tid, showdate);
					}

					else if (a.equals("H3")) {
						book.mornH3(tid, showdate);
					}

					else if (a.equals("H4")) {
						book.mornH4(tid, showdate);
					}

					else if (a.equals("H5")) {
						book.mornH5(tid, showdate);
					}

					else if (a.equals("H6")) {
						book.mornH6(tid, showdate);
					}

					else if (a.equals("H7")) {
						book.mornH7(tid, showdate);
					}

					else if (a.equals("H8")) {
						book.mornH8(tid, showdate);
					}

					else if (a.equals("H9")) {
						book.mornH9(tid, showdate);
					}

					else if (a.equals("H10")) {
						book.mornH10(tid, showdate);
					}

					else if (a.equals("H11")) {
						book.mornH11(tid, showdate);
					}

					else if (a.equals("H12")) {
						book.mornH12(tid, showdate);
					}

					else if (a.equals("I1")) {
						book.mornI1(tid, showdate);
					}

					else if (a.equals("I2")) {
						book.mornI2(tid, showdate);
					}

					else if (a.equals("I3")) {
						book.mornI3(tid, showdate);
					}

					else if (a.equals("I4")) {
						book.mornI4(tid, showdate);
					}

					else if (a.equals("I5")) {
						book.mornI5(tid, showdate);
					}

					else if (a.equals("I6")) {
						book.mornI6(tid, showdate);
					}

					else if (a.equals("I7")) {
						book.mornI7(tid, showdate);
					}

					else if (a.equals("I8")) {
						book.mornI8(tid, showdate);
					}

					else if (a.equals("I9")) {
						book.mornI9(tid, showdate);
					}

					else if (a.equals("I10")) {
						book.mornI10(tid, showdate);
					}

					else if (a.equals("I11")) {
						book.mornI11(tid, showdate);
					}

					else if (a.equals("I12")) {
						book.mornI12(tid, showdate);
					}

					else if (a.equals("J1")) {
						book.mornJ1(tid, showdate);
					}

					else if (a.equals("J2")) {
						book.mornJ2(tid, showdate);
					}

					else if (a.equals("J3")) {
						book.mornJ3(tid, showdate);
					}

					else if (a.equals("J4")) {
						book.mornJ4(tid, showdate);
					}

					else if (a.equals("J5")) {
						book.mornJ5(tid, showdate);
					}

					else if (a.equals("J6")) {
						book.mornJ6(tid, showdate);
					}

					else if (a.equals("J7")) {
						book.mornJ7(tid, showdate);
					}

					else if (a.equals("J8")) {
						book.mornJ8(tid, showdate);
					}

					else if (a.equals("J9")) {
						book.mornJ9(tid, showdate);
					}

					else if (a.equals("J10")) {
						book.mornJ10(tid, showdate);
					}

					else if (a.equals("J11")) {
						book.mornJ11(tid, showdate);
					}

					else if (a.equals("J12")) {
						book.mornJ12(tid, showdate);
					}
				}

			}

			else if (showtime.equals("Matinee")) {

				for (String a : str)

				{

					System.out.println(a);

					if (a.equals("A1")) {
						book.matA1(tid, showdate);
					}

					else if (a.equals("A2")) {
						book.matA2(tid, showdate);
					}

					else if (a.equals("A3")) {
						book.matA3(tid, showdate);
					}

					else if (a.equals("A4")) {
						book.matA4(tid, showdate);
					}

					else if (a.equals("A5")) {
						book.matA5(tid, showdate);
					}

					else if (a.equals("A6")) {
						book.matA6(tid, showdate);
					}

					else if (a.equals("A7")) {
						book.matA7(tid, showdate);
					}

					else if (a.equals("A8")) {
						book.matA8(tid, showdate);
					}

					else if (a.equals("A9")) {
						book.matA9(tid, showdate);
					}

					else if (a.equals("A10")) {
						book.matA10(tid, showdate);
					}

					else if (a.equals("A11")) {
						book.matA11(tid, showdate);
					}

					else if (a.equals("A12")) {
						book.matA12(tid, showdate);
					}

					else if (a.equals("B1")) {
						book.matB1(tid, showdate);
					}

					else if (a.equals("B2")) {
						book.matB2(tid, showdate);
					}

					else if (a.equals("B3")) {
						book.matB3(tid, showdate);
					}

					else if (a.equals("B4")) {
						book.matB4(tid, showdate);
					}

					else if (a.equals("B5")) {
						book.matB5(tid, showdate);
					}

					else if (a.equals("B6")) {
						book.matB6(tid, showdate);
					}

					else if (a.equals("B7")) {
						book.matB7(tid, showdate);
					}

					else if (a.equals("B8")) {
						book.matB8(tid, showdate);
					}

					else if (a.equals("B9")) {
						book.matB9(tid, showdate);
					}

					else if (a.equals("B10")) {
						book.matB10(tid, showdate);
					}

					else if (a.equals("B11")) {
						book.matB11(tid, showdate);
					}

					else if (a.equals("B12")) {
						book.matB12(tid, showdate);
					}

					else if (a.equals("C1")) {
						book.matC1(tid, showdate);
					}

					else if (a.equals("C2")) {
						book.matC2(tid, showdate);
					}

					else if (a.equals("C3")) {
						book.matC3(tid, showdate);
					}

					else if (a.equals("C4")) {
						book.matC4(tid, showdate);
					}

					else if (a.equals("C5")) {
						book.matC5(tid, showdate);
					}

					else if (a.equals("C6")) {
						book.matC6(tid, showdate);
					}

					else if (a.equals("C7")) {
						book.matC7(tid, showdate);
					}

					else if (a.equals("C8")) {
						book.matC8(tid, showdate);
					}

					else if (a.equals("C9")) {
						book.matC9(tid, showdate);
					}

					else if (a.equals("C10")) {
						book.matC10(tid, showdate);
					}

					else if (a.equals("C11")) {
						book.matC11(tid, showdate);
					}

					else if (a.equals("C12")) {
						book.matC12(tid, showdate);
					}

					else if (a.equals("D1")) {
						book.matD1(tid, showdate);
					}

					else if (a.equals("D2")) {
						book.matD2(tid, showdate);
					}

					else if (a.equals("D3")) {
						book.matD3(tid, showdate);
					}

					else if (a.equals("D4")) {
						book.matD4(tid, showdate);
					}

					else if (a.equals("D5")) {
						book.matD5(tid, showdate);
					}

					else if (a.equals("D6")) {
						book.matD6(tid, showdate);
					}

					else if (a.equals("D7")) {
						book.matD7(tid, showdate);
					}

					else if (a.equals("D8")) {
						book.matD8(tid, showdate);
					}

					else if (a.equals("D9")) {
						book.matD9(tid, showdate);
					}

					else if (a.equals("D10")) {
						book.matD10(tid, showdate);
					}

					else if (a.equals("D11")) {
						book.matD11(tid, showdate);
					}

					else if (a.equals("D12")) {
						book.matD12(tid, showdate);
					}

					else if (a.equals("E1")) {
						book.matE1(tid, showdate);
					}

					else if (a.equals("E2")) {
						book.matE2(tid, showdate);
					}

					else if (a.equals("E3")) {
						book.matE3(tid, showdate);
					}

					else if (a.equals("E4")) {
						book.matE4(tid, showdate);
					}

					else if (a.equals("E5")) {
						book.matE5(tid, showdate);
					}

					else if (a.equals("E6")) {
						book.matE6(tid, showdate);
					}

					else if (a.equals("E7")) {
						book.matE7(tid, showdate);
					}

					else if (a.equals("E8")) {
						book.matE8(tid, showdate);
					}

					else if (a.equals("E9")) {
						book.matE9(tid, showdate);
					}

					else if (a.equals("E10")) {
						book.matE10(tid, showdate);
					}

					else if (a.equals("E11")) {
						book.matE11(tid, showdate);
					}

					else if (a.equals("E12")) {
						book.matE12(tid, showdate);
					}

					else if (a.equals("F1")) {
						book.matF1(tid, showdate);
					}

					else if (a.equals("F2")) {
						book.matF2(tid, showdate);
					}

					else if (a.equals("F3")) {
						book.matF3(tid, showdate);
					}

					else if (a.equals("F4")) {
						book.matF4(tid, showdate);
					}

					else if (a.equals("F5")) {
						book.matF5(tid, showdate);
					}

					else if (a.equals("F6")) {
						book.matF6(tid, showdate);
					}

					else if (a.equals("F7")) {
						book.matF7(tid, showdate);
					}

					else if (a.equals("F8")) {
						book.matF8(tid, showdate);
					}

					else if (a.equals("F9")) {
						book.matF9(tid, showdate);
					}

					else if (a.equals("F10")) {
						book.matF10(tid, showdate);
					}

					else if (a.equals("F11")) {
						book.matF11(tid, showdate);
					}

					else if (a.equals("F12")) {
						book.matF12(tid, showdate);
					}

					else if (a.equals("G1")) {
						book.matG1(tid, showdate);
					}

					else if (a.equals("G2")) {
						book.matG2(tid, showdate);
					}

					else if (a.equals("G3")) {
						book.matG3(tid, showdate);
					}

					else if (a.equals("G4")) {
						book.matG4(tid, showdate);
					}

					else if (a.equals("G5")) {
						book.matG5(tid, showdate);
					}

					else if (a.equals("G6")) {
						book.matG6(tid, showdate);
					}

					else if (a.equals("G7")) {
						book.matG7(tid, showdate);
					}

					else if (a.equals("G8")) {
						book.matG8(tid, showdate);
					}

					else if (a.equals("G9")) {
						book.matG9(tid, showdate);
					}

					else if (a.equals("G10")) {
						book.matG10(tid, showdate);
					}

					else if (a.equals("G11")) {
						book.matG11(tid, showdate);
					}

					else if (a.equals("G12")) {
						book.matG12(tid, showdate);
					}

					else if (a.equals("H1")) {
						book.matH1(tid, showdate);
					}

					else if (a.equals("H2")) {
						book.matH2(tid, showdate);
					}

					else if (a.equals("H3")) {
						book.matH3(tid, showdate);
					}

					else if (a.equals("H4")) {
						book.matH4(tid, showdate);
					}

					else if (a.equals("H5")) {
						book.matH5(tid, showdate);
					}

					else if (a.equals("H6")) {
						book.matH6(tid, showdate);
					}

					else if (a.equals("H7")) {
						book.matH7(tid, showdate);
					}

					else if (a.equals("H8")) {
						book.matH8(tid, showdate);
					}

					else if (a.equals("H9")) {
						book.matH9(tid, showdate);
					}

					else if (a.equals("H10")) {
						book.matH10(tid, showdate);
					}

					else if (a.equals("H11")) {
						book.matH11(tid, showdate);
					}

					else if (a.equals("H12")) {
						book.matH12(tid, showdate);
					}

					else if (a.equals("I1")) {
						book.matI1(tid, showdate);
					}

					else if (a.equals("I2")) {
						book.matI2(tid, showdate);
					}

					else if (a.equals("I3")) {
						book.matI3(tid, showdate);
					}

					else if (a.equals("I4")) {
						book.matI4(tid, showdate);
					}

					else if (a.equals("I5")) {
						book.matI5(tid, showdate);
					}

					else if (a.equals("I6")) {
						book.matI6(tid, showdate);
					}

					else if (a.equals("I7")) {
						book.matI7(tid, showdate);
					}

					else if (a.equals("I8")) {
						book.matI8(tid, showdate);
					}

					else if (a.equals("I9")) {
						book.matI9(tid, showdate);
					}

					else if (a.equals("I10")) {
						book.matI10(tid, showdate);
					}

					else if (a.equals("I11")) {
						book.matI11(tid, showdate);
					}

					else if (a.equals("I12")) {
						book.matI12(tid, showdate);
					}

					else if (a.equals("J1")) {
						book.matJ1(tid, showdate);
					}

					else if (a.equals("J2")) {
						book.matJ2(tid, showdate);
					}

					else if (a.equals("J3")) {
						book.matJ3(tid, showdate);
					}

					else if (a.equals("J4")) {
						book.matJ4(tid, showdate);
					}

					else if (a.equals("J5")) {
						book.matJ5(tid, showdate);
					}

					else if (a.equals("J6")) {
						book.matJ6(tid, showdate);
					}

					else if (a.equals("J7")) {
						book.matJ7(tid, showdate);
					}

					else if (a.equals("J8")) {
						book.matJ8(tid, showdate);
					}

					else if (a.equals("J9")) {
						book.matJ9(tid, showdate);
					}

					else if (a.equals("J10")) {
						book.matJ10(tid, showdate);
					}

					else if (a.equals("J11")) {
						book.matJ11(tid, showdate);
					}

					else if (a.equals("J12")) {
						book.matJ12(tid, showdate);
					}

				}
			}

			else if (showtime.equals("SecondShow")) {

				for (String a : str)

				{

					System.out.println(a);

					if (a.equals("A1")) {
						book.secA1(tid, showdate);
					}

					else if (a.equals("A2")) {
						book.secA2(tid, showdate);
					}

					else if (a.equals("A3")) {
						book.secA3(tid, showdate);
					}

					else if (a.equals("A4")) {
						book.secA4(tid, showdate);
					}

					else if (a.equals("A5")) {
						book.secA5(tid, showdate);
					}

					else if (a.equals("A6")) {
						book.secA6(tid, showdate);
					}

					else if (a.equals("A7")) {
						book.secA7(tid, showdate);
					}

					else if (a.equals("A8")) {
						book.secA8(tid, showdate);
					}

					else if (a.equals("A9")) {
						book.secA9(tid, showdate);
					}

					else if (a.equals("A10")) {
						book.secA10(tid, showdate);
					}

					else if (a.equals("A11")) {
						book.secA11(tid, showdate);
					}

					else if (a.equals("A12")) {
						book.secA12(tid, showdate);
					}

					else if (a.equals("B1")) {
						book.secB1(tid, showdate);
					}

					else if (a.equals("B2")) {
						book.secB2(tid, showdate);
					}

					else if (a.equals("B3")) {
						book.secB3(tid, showdate);
					}

					else if (a.equals("B4")) {
						book.secB4(tid, showdate);
					}

					else if (a.equals("B5")) {
						book.secB5(tid, showdate);
					}

					else if (a.equals("B6")) {
						book.secB6(tid, showdate);
					}

					else if (a.equals("B7")) {
						book.secB7(tid, showdate);
					}

					else if (a.equals("B8")) {
						book.secB8(tid, showdate);
					}

					else if (a.equals("B9")) {
						book.secB9(tid, showdate);
					}

					else if (a.equals("B10")) {
						book.secB10(tid, showdate);
					}

					else if (a.equals("B11")) {
						book.secB11(tid, showdate);
					}

					else if (a.equals("B12")) {
						book.secB12(tid, showdate);
					}

					else if (a.equals("C1")) {
						book.secC1(tid, showdate);
					}

					else if (a.equals("C2")) {
						book.secC2(tid, showdate);
					}

					else if (a.equals("C3")) {
						book.secC3(tid, showdate);
					}

					else if (a.equals("C4")) {
						book.secC4(tid, showdate);
					}

					else if (a.equals("C5")) {
						book.secC5(tid, showdate);
					}

					else if (a.equals("C6")) {
						book.secC6(tid, showdate);
					}

					else if (a.equals("C7")) {
						book.secC7(tid, showdate);
					}

					else if (a.equals("C8")) {
						book.secC8(tid, showdate);
					}

					else if (a.equals("C9")) {
						book.secC9(tid, showdate);
					}

					else if (a.equals("C10")) {
						book.secC10(tid, showdate);
					}

					else if (a.equals("C11")) {
						book.secC11(tid, showdate);
					}

					else if (a.equals("C12")) {
						book.secC12(tid, showdate);
					}

					else if (a.equals("D1")) {
						book.secD1(tid, showdate);
					}

					else if (a.equals("D2")) {
						book.secD2(tid, showdate);
					}

					else if (a.equals("D3")) {
						book.secD3(tid, showdate);
					}

					else if (a.equals("D4")) {
						book.secD4(tid, showdate);
					}

					else if (a.equals("D5")) {
						book.secD5(tid, showdate);
					}

					else if (a.equals("D6")) {
						book.secD6(tid, showdate);
					}

					else if (a.equals("D7")) {
						book.secD7(tid, showdate);
					}

					else if (a.equals("D8")) {
						book.secD8(tid, showdate);
					}

					else if (a.equals("D9")) {
						book.secD9(tid, showdate);
					}

					else if (a.equals("D10")) {
						book.secD10(tid, showdate);
					}

					else if (a.equals("D11")) {
						book.secD11(tid, showdate);
					}

					else if (a.equals("D12")) {
						book.secD12(tid, showdate);
					}

					else if (a.equals("E1")) {
						book.secE1(tid, showdate);
					}

					else if (a.equals("E2")) {
						book.secE2(tid, showdate);
					}

					else if (a.equals("E3")) {
						book.secE3(tid, showdate);
					}

					else if (a.equals("E4")) {
						book.secE4(tid, showdate);
					}

					else if (a.equals("E5")) {
						book.secE5(tid, showdate);
					}

					else if (a.equals("E6")) {
						book.secE6(tid, showdate);
					}

					else if (a.equals("E7")) {
						book.secE7(tid, showdate);
					}

					else if (a.equals("E8")) {
						book.secE8(tid, showdate);
					}

					else if (a.equals("E9")) {
						book.secE9(tid, showdate);
					}

					else if (a.equals("E10")) {
						book.secE10(tid, showdate);
					}

					else if (a.equals("E11")) {
						book.secE11(tid, showdate);
					}

					else if (a.equals("E12")) {
						book.secE12(tid, showdate);
					}

					else if (a.equals("F1")) {
						book.secF1(tid, showdate);
					}

					else if (a.equals("F2")) {
						book.secF2(tid, showdate);
					}

					else if (a.equals("F3")) {
						book.secF3(tid, showdate);
					}

					else if (a.equals("F4")) {
						book.secF4(tid, showdate);
					}

					else if (a.equals("F5")) {
						book.secF5(tid, showdate);
					}

					else if (a.equals("F6")) {
						book.secF6(tid, showdate);
					}

					else if (a.equals("F7")) {
						book.secF7(tid, showdate);
					}

					else if (a.equals("F8")) {
						book.secF8(tid, showdate);
					}

					else if (a.equals("F9")) {
						book.secF9(tid, showdate);
					}

					else if (a.equals("F10")) {
						book.secF10(tid, showdate);
					}

					else if (a.equals("F11")) {
						book.secF11(tid, showdate);
					}

					else if (a.equals("F12")) {
						book.secF12(tid, showdate);
					}

					else if (a.equals("G1")) {
						book.secG1(tid, showdate);
					}

					else if (a.equals("G2")) {
						book.secG2(tid, showdate);
					}

					else if (a.equals("G3")) {
						book.secG3(tid, showdate);
					}

					else if (a.equals("G4")) {
						book.secG4(tid, showdate);
					}

					else if (a.equals("G5")) {
						book.secG5(tid, showdate);
					}

					else if (a.equals("G6")) {
						book.secG6(tid, showdate);
					}

					else if (a.equals("G7")) {
						book.secG7(tid, showdate);
					}

					else if (a.equals("G8")) {
						book.secG8(tid, showdate);
					}

					else if (a.equals("G9")) {
						book.secG9(tid, showdate);
					}

					else if (a.equals("G10")) {
						book.secG10(tid, showdate);
					}

					else if (a.equals("G11")) {
						book.secG11(tid, showdate);
					}

					else if (a.equals("G12")) {
						book.secG12(tid, showdate);
					}

					else if (a.equals("H1")) {
						book.secH1(tid, showdate);
					}

					else if (a.equals("H2")) {
						book.secH2(tid, showdate);
					}

					else if (a.equals("H3")) {
						book.secH3(tid, showdate);
					}

					else if (a.equals("H4")) {
						book.secH4(tid, showdate);
					}

					else if (a.equals("H5")) {
						book.secH5(tid, showdate);
					}

					else if (a.equals("H6")) {
						book.secH6(tid, showdate);
					}

					else if (a.equals("H7")) {
						book.secH7(tid, showdate);
					}

					else if (a.equals("H8")) {
						book.secH8(tid, showdate);
					}

					else if (a.equals("H9")) {
						book.secH9(tid, showdate);
					}

					else if (a.equals("H10")) {
						book.secH10(tid, showdate);
					}

					else if (a.equals("H11")) {
						book.secH11(tid, showdate);
					}

					else if (a.equals("H12")) {
						book.secH12(tid, showdate);
					}

					else if (a.equals("I1")) {
						book.secI1(tid, showdate);
					}

					else if (a.equals("I2")) {
						book.secI2(tid, showdate);
					}

					else if (a.equals("I3")) {
						book.secI3(tid, showdate);
					}

					else if (a.equals("I4")) {
						book.secI4(tid, showdate);
					}

					else if (a.equals("I5")) {
						book.secI5(tid, showdate);
					}

					else if (a.equals("I6")) {
						book.secI6(tid, showdate);
					}

					else if (a.equals("I7")) {
						book.secI7(tid, showdate);
					}

					else if (a.equals("I8")) {
						book.secI8(tid, showdate);
					}

					else if (a.equals("I9")) {
						book.secI9(tid, showdate);
					}

					else if (a.equals("I10")) {
						book.secI10(tid, showdate);
					}

					else if (a.equals("I11")) {
						book.secI11(tid, showdate);
					}

					else if (a.equals("I12")) {
						book.secI12(tid, showdate);
					}

					else if (a.equals("J1")) {
						book.secJ1(tid, showdate);
					}

					else if (a.equals("J2")) {
						book.secJ2(tid, showdate);
					}

					else if (a.equals("J3")) {
						book.secJ3(tid, showdate);
					}

					else if (a.equals("J4")) {
						book.secJ4(tid, showdate);
					}

					else if (a.equals("J5")) {
						book.secJ5(tid, showdate);
					}

					else if (a.equals("J6")) {
						book.secJ6(tid, showdate);
					}

					else if (a.equals("J7")) {
						book.secJ7(tid, showdate);
					}

					else if (a.equals("J8")) {
						book.secJ8(tid, showdate);
					}

					else if (a.equals("J9")) {
						book.secJ9(tid, showdate);
					}

					else if (a.equals("J10")) {
						book.secJ10(tid, showdate);
					}

					else if (a.equals("J11")) {
						book.secJ11(tid, showdate);
					}

					else if (a.equals("J12")) {
						book.secJ12(tid, showdate);
					}

				}
			}
			Booking b = new Booking();
			b.setCustId(cs.getCustId());
			b.setPhone(cs.getPhone());
			b.setScreen(t.get().getScreen());
			b.setShowdate(c.getShowdate());
			b.setShowtime(c.getShowtime());
			b.setMid(t.get().getMid());
			b.setMxid(t.get().getMxid());
			b.setSeats(c.getSeats());
			b.setTid(c.getTid());
			book.save(b);
			custlog.info(env.getProperty("sb"));
			return env.getProperty("sb");
		} catch (Exception e) {
			custlog.error(env.getProperty("id"));
			throw new BadRequestException(env.getProperty("id"));
		}

	}
}
