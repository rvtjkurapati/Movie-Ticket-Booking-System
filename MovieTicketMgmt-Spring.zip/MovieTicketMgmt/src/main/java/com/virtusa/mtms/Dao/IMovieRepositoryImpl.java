package com.virtusa.mtms.Dao;

import java.sql.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Multiplex;
import com.virtusa.mtms.Entity.Theatre;
@Repository
@Transactional
public interface IMovieRepositoryImpl extends JpaRepository<Movie, Integer> {
	
	@Query("select c from movie c where c.mvname like ?1%")
	public List<Movie> findByName(String name);
	
	@Query("select c from movie c where c.mvname like ?1% and c.mid!=?2")
	public List<Movie> findByMName(String name,int mid);
	
	@Query("select c from movie c where c.category like ?1%")
	public List<Movie> findByCat(String name);
	
	@Query("select c from movie c where c.genre like ?1%")
	public List<Movie> findByGen(String name);
	
	
	@Query("select c from movie c where c.relDate < ?1")
	public List<Movie> findAllRunning(Date reldate);
	
	@Query("select c from movie c where c.mvname like ?1% and c.relDate<?2")
	public List<Movie> findByNameRunning(String name,Date reldate);
	
	@Query("select c from movie c where c.category like ?1% and c.relDate<?2")
	public List<Movie> findByCatRunning(String name,Date reldate);
	
	@Query("select c from movie c where c.genre like ?1% and c.relDate<?2")
	public List<Movie> findByGenRunning(String name,Date reldate);
	
	@Query("select c from movie c where c.mid=?1 and c.relDate < ?2")
	public Movie findByMid(int id,Date reldate);
	
	@Query("select mornid from morningseats where mid=?1")
	public List<Integer> getMornId(Movie mid);
	
	@Query("select matid from matineeseats  where mid=?1")
	public List<Integer> getMatId(Movie mid);
	
	@Query("select secid from secondshowseats where  mid=?1")
	public List<Integer> getSecId(Movie mid);
	
	@Query("select bid from booking  where mid=?1")
	public List<Integer> getBId(Movie mid);
	
	@Query("select tid from theatre where  mid=?1")
	public List<Integer> getTId(Movie mid);

}
