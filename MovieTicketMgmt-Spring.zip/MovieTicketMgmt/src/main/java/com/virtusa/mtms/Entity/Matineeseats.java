package com.virtusa.mtms.Entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Data
@Getter
@Setter
@NoArgsConstructor
@Entity(name="matineeseats")
@AllArgsConstructor
public class Matineeseats implements Serializable{
	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int matid;
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	@Column(name="showdate")
	Date showdate;
	String showtime;
	
	@Column(name="A1") 
	int A1; 
	
	@Column(name="A2") 
	int A2; 
	
	@Column(name="A3") 
	int A3; 
	
	@Column(name="A4") 
	int A4; 
	
	@Column(name="A5") 
	int A5; 

	@Column(name="A6") 
	int A6; 

	@Column(name="A7") 
	int A7; 

	@Column(name="A8") 
	int A8; 

	@Column(name="A9") 
	int A9; 

	@Column(name="A10") 
	int A10; 

	@Column(name="A11") 
	int A11; 

	@Column(name="A12") 
	int A12; 

	@Column(name="B1") 
	int B1; 

	@Column(name="B2")
	int B2; 

	@Column(name="B3")
	int B3; 

	@Column(name="B4")
	int B4; 

	@Column(name="B5")
	int B5; 

	@Column(name="B6")
	int B6; 

	@Column(name="B7")
	int B7; 

	@Column(name="B8")
	int B8; 

	@Column(name="B9")
	int B9; 

	@Column(name="B10")
	int B10; 

	@Column(name="B11")
	int B11; 

	@Column(name="B12")
	int B12; 

	@Column(name="C1")
	int C1; 

	@Column(name="C2")
	int C2; 

	@Column(name="C3")
	int C3; 

	@Column(name="C4")
	int C4; 

	@Column(name="C5")
	int C5; 

	@Column(name="C6")
	int C6; 

	@Column(name="C7")
	int C7; 

	@Column(name="C8")
	int C8; 

	@Column(name="C9")
	int C9; 

	@Column(name="C10")
	int C10; 

	@Column(name="C11")
	int C11; 

	@Column(name="C12")
	int C12; 

	@Column(name="D1")
	int D1; 

	@Column(name="D2")
	int D2; 

	@Column(name="D3")
	int D3; 

	@Column(name="D4")
	int D4; 

	@Column(name="D5")
	int D5; 

	@Column(name="D6")
	int D6; 

	@Column(name="D7")
	int D7; 

	@Column(name="D8")
	int D8; 

	@Column(name="D9")
	int D9; 

	@Column(name="D10")
	int D10; 

	@Column(name="D11")
	int D11; 

	@Column(name="D12")
	int D12; 

	@Column(name="E1")
	int E1; 

	@Column(name="E2")
	int E2; 

	@Column(name="E3")
	int E3; 

	@Column(name="E4")
	int E4; 

	@Column(name="E5")
	int E5; 

	@Column(name="E6")
	int E6; 

	@Column(name="E7")
	int E7; 

	@Column(name="E8")
	int E8; 

	@Column(name="E9")
	int E9; 

	@Column(name="E10")
	int E10; 

	@Column(name="E11")
	int E11; 

	@Column(name="E12")
	int E12; 

	@Column(name="F1")
	int F1; 

	@Column(name="F2")
	int F2; 

	@Column(name="F3")
	int F3; 

	@Column(name="F4")
	int F4; 

	@Column(name="F5")
	int F5; 

	@Column(name="F6")
	int F6; 

	@Column(name="F7")
	int F7; 

	@Column(name="F8")
	int F8; 

	@Column(name="F9")
	int F9; 

	@Column(name="F10")
	int F10; 

	@Column(name="F11")
	int F11; 

	@Column(name="F12")
	int F12; 

	@Column(name="G1")
	int G1; 

	@Column(name="G2")
	int G2; 

	@Column(name="G3")
	int G3; 

	@Column(name="G4")
	int G4; 

	@Column(name="G5")
	int G5; 

	@Column(name="G6")
	int G6; 

	@Column(name="G7")
	int G7; 

	@Column(name="G8")
	int G8; 

	@Column(name="G9")
	int G9; 

	@Column(name="G10")
	int G10; 

	@Column(name="G11")
	int G11; 

	@Column(name="G12")
	int G12; 

	@Column(name="H1")
	int H1; 

	@Column(name="H2")
	int H2; 

	@Column(name="H3")
	int H3; 

	@Column(name="H4")
	int H4; 

	@Column(name="H5")
	int H5; 

	@Column(name="H6")
	int H6; 

	@Column(name="H7")
	int H7; 

	@Column(name="H8")
	int H8; 

	@Column(name="H9")
	int H9; 

	@Column(name="H10")
	int H10; 

	@Column(name="H11")
	int H11; 

	@Column(name="H12")
	int H12; 

	@Column(name="I1")
	int I1; 

	@Column(name="I2")
	int I2; 

	@Column(name="I3")
	int I3; 

	@Column(name="I4")
	int I4; 

	@Column(name="I5")
	int I5; 

	@Column(name="I6")
	int I6; 

	@Column(name="I7")
	int I7; 

	@Column(name="I8")
	int I8; 

	@Column(name="I9")
	int I9; 

	@Column(name="I10")
	int I10; 

	@Column(name="I11")
	int I11; 

	@Column(name="I12")
	int I12; 

	@Column(name="J1")
	int J1; 

	@Column(name="J2")
	int J2; 

	@Column(name="J3")
	int J3; 

	@Column(name="J4")
	int J4; 

	@Column(name="J5")
	int J5; 

	@Column(name="J6")
	int J6; 

	@Column(name="J7")
	int J7; 

	@Column(name="J8")
	int J8; 

	@Column(name="J9")
	int J9; 

	@Column(name="J10")
	int J10; 

	@Column(name="J11")
	int J11; 
	
	@Column(name="J12")
	int J12; 
	
	
	@ManyToOne
	@JoinColumn(name="tid")
	Theatre tid;
	@ManyToOne
	@JoinColumn(name="mid")
	Movie mid ;
	@ManyToOne
	@JoinColumn(name="mxid")
	Multiplex mxid;
	@Override
	public String toString() {
		return "\n\n\t\t\t\t\t\t\t\t\t\tShowdate=" + showdate + ", Showtime=" + showtime + " \n\n\n\t\t\tA1=" + A1
				+ ", A2=" + A2 + ", A3=" + A3 + "\t\t\t A4=" + A4 + ", A5=" + A5 + ", A6=" + A6 + ", A7=" + A7 + ", A8=" + A8
				+ ", A9=" + A9 + "\t\t\t A10=" + A10 + ", A11=" + A11 + ", A12=" + A12 + "\n\n\t\t    B1=" + B1 + ", B2=" + B2
				+ ", B3=" + B3 + "\t\t\t B4=" + B4 + ", B5=" + B5 + ", B6=" + B6 + ", B7=" + B7 + ", B8=" + B8 + ", B9=" + B9
				+ "\t\t\t B10=" + B10 + ", B11=" + B11 + ", B12=" + B12 + "\n\n\t\t    C1=" + C1 + ", C2=" + C2 + ", C3=" + C3
				+ "\t\t\t C4=" + C4 + ", C5=" + C5 + ", C6=" + C6 + ", C7=" + C7 + ", C8=" + C8 + ", C9=" + C9 + "\t\t\t C10="
				+ C10 + ", C11=" + C11 + ", C12=" + C12 + "\n\n\t\t    D1=" + D1 + ", D2=" + D2 + ", D3=" + D3 + "\t\t\t D4=" + D4
				+ ", D5=" + D5 + ", D6=" + D6 + ", D7=" + D7 + ", D8=" + D8 + ", D9=" + D9 + "\t\t\t D10=" + D10 + ", D11="
				+ D11 + ", D12=" + D12 + "\n\n\t\t    E1=" + E1 + ", E2=" + E2 + ", E3=" + E3 + "\t\t\t E4=" + E4 + ", E5=" + E5
				+ ", E6=" + E6 + ", E7=" + E7 + ", E8=" + E8 + ", E9=" + E9 + "\t\t\t E10=" + E10 + ", E11=" + E11 + ", E12="
				+ E12 + "\n\n\t\t    F1=" + F1 + ", F2=" + F2 + ", F3=" + F3 + "\t\t\t F4=" + F4 + ", F5=" + F5 + ", F6=" + F6
				+ ", F7=" + F7 + ", F8=" + F8 + ", F9=" + F9 + "\t\t\t F10=" + F10 + ", F11=" + F11 + ", F12=" + F12
				+ "\n\n\t\t    G1=" + G1 + ", G2=" + G2 + ", G3=" + G3 + "\t\t\t G4=" + G4 + ", G5=" + G5 + ", G6=" + G6 + ", G7=" + G7
				+ ", G8=" + G8 + ", G9=" + G9 + "\t\t\t G10=" + G10 + ", G11=" + G11 + ", G12=" + G12 + "\n\n\t\t    H1=" + H1
				+ ", H2=" + H2 + ", H3=" + H3 + "\t\t\t H4=" + H4 + ", H5=" + H5 + ", H6=" + H6 + ", H7=" + H7 + ", H8=" + H8
				+ ", H9=" + H9 + "\t\t\t H10=" + H10 + ", H11=" + H11 + ", H12=" + H12 +"\n\n\t\t    I1=" + I1 + ", I2=" + I2
				+ ", I3=" + I3 + "\t\t\t I4=" + I4 + ", I5=" + I5 + ", I6=" + I6 + ", I7=" + I7 + ", I8=" + I8 + ", I9=" + I9
				+ "\t\t\t I10=" + I10 + ", I11=" + I11 + ", I12=" + I12 + "\n\n\t\t    J1=" + J1 + ", J2=" + J2 + ", J3=" + J3
				+ "\t\t\t J4=" + J4 + ", J5=" + J5 + ", J6=" + J6 + ", J7=" + J7 + ", J8=" + J8 + ", J9=" + J9 + "\t\t\t J10="
				+ J10 + ", J11=" + J11 + ", J12=" + J12 +"\n\n\n";
	}
	
	

}
