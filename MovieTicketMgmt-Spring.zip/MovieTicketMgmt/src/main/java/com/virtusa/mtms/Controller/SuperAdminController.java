package com.virtusa.mtms.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.mtms.Dao.IAdminRepositoryImpl;
import com.virtusa.mtms.Dao.IBookingRepositoryImpl;
import com.virtusa.mtms.Entity.Admin;
import com.virtusa.mtms.Entity.Booking;
import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.SuperAdmin;
import com.virtusa.mtms.Service.ISuperAdminServiceImpl;

@RestController
@RequestMapping("/superadmin")
public class SuperAdminController {
	
	@Autowired
	ISuperAdminServiceImpl superRepo;
	
	@Autowired
	IAdminRepositoryImpl adminRepo;
	
	
	@GetMapping("/showadmin")
	public List<Admin> showAdmin()
	{
		return superRepo.showAdmin();
	}
	
	@PostMapping("/addadmin")
	public String addAdmin(@RequestBody Admin c)
	{
		return superRepo.addAdmin(c);
	}
	
	
	@GetMapping("/searchadminbyId/{id}")
	public Optional<Admin> searchadminbyId(@PathVariable("id") int id)
	{
		return superRepo.searchAdminById(id);
	}
	
	@GetMapping("/searchadminbyName/{id}")
	public List<Admin> searchadminbyName(@PathVariable("id") String id)
	{
		return superRepo.searchAdminByName(id);
	}
	
	@PutMapping("/updateadmin/{id}")         
	public String updateAdmin (@RequestBody Admin c, @PathVariable("id") int cid) {
		return superRepo.updateAdmin(c,cid);
	}
	
	@DeleteMapping("/deleteAdmin/{id}")         
	public String deleteCust(@PathVariable("id") int cid) {
		return superRepo.deleteAdmin(cid);
	}
	
	@GetMapping("/showbooking")
	public List<Booking> showBooking()
	{
		return superRepo.showBooking();
	}
	
	
	@GetMapping("/searchbookingbyId/{id}")
	public Optional<Booking> searchbookingbyId(@PathVariable("id") int id)
	{
		return superRepo.searchBookingById(id);
	}
	
	
	@GetMapping("/searchbookingbyCid/{id}")
	public List<Booking> searchbookingbyCid(@PathVariable("id") int id)
	{
		return superRepo.searchBookingByCid(id);
	}
	
	@GetMapping("/searchbookingbyMid/{id}")
	public List<Booking> searchbookingbyMid(@PathVariable("id") Movie id)
	{
		return superRepo.searchBookingByMid(id);
	}
	
	@DeleteMapping("/deleteBooking/{id}")         
	public String deleteBooking(@PathVariable("id") int cid) {
		return superRepo.deleteBooking(cid);
	}
	
	@PostMapping("/login")
	public String login(@RequestBody SuperAdmin c)
	{
		return superRepo.superlogin(c);
	}
	
	@GetMapping("/logOut")
	public String logOut()
	{
		return superRepo.logOut();
	}
	
	@PutMapping("/change-password")         
	public String changePwd (@RequestBody SuperAdmin c) {
		return superRepo.changePwd(c);
	}

}
