package com.virtusa.mtms.Entity;

import java.sql.Date;

public class Book {
	
	Theatre tid;
	Date showdate;
	String seats;
	String showtime;
	String phone;
	String payment;
	public Book() {
		super();
	}
	public Book(Theatre tid, Date showdate, String seats, String showtime, String phone, String payment) {
		super();
		this.tid = tid;
		this.showdate = showdate;
		this.seats = seats;
		this.showtime = showtime;
		this.phone = phone;
		this.payment = payment;
	}
	public Theatre getTid() {
		return tid;
	}
	public void setTid(Theatre tid) {
		this.tid = tid;
	}
	public Date getShowdate() {
		return showdate;
	}
	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}
	public String getSeats() {
		return seats;
	}
	public void setSeats(String seats) {
		this.seats = seats;
	}
	public String getShowtime() {
		return showtime;
	}
	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	@Override
	public String toString() {
		return "Book [tid=" + tid + ", showdate=" + showdate + ", seats=" + seats + ", showtime=" + showtime
				+ ", phone=" + phone + ", payment=" + payment + "]";
	}
	

}
