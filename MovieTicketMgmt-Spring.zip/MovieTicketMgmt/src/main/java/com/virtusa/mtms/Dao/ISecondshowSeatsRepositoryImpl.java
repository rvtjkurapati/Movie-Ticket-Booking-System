package com.virtusa.mtms.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.mtms.Entity.Secondshowseats;

public interface ISecondshowSeatsRepositoryImpl extends JpaRepository<Secondshowseats, Integer> {

}
