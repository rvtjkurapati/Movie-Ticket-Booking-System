package com.virtusa.mtms.Entity;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity(name = "movie")
@AllArgsConstructor
public class Movie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int mid;
	@Column(unique = true)
	@NotNull
	@Pattern(regexp = "^[A-Z].*$", message = "Movie name Should Start with Capital letter")
	String mvname;
	@NotNull
	String category;
	@NotNull
	@Pattern(regexp = "^[A-Z].*$", message = "Language Should Start with Capital letter")
	String lang;
	@NotNull
	String duration;
	@NotNull
	@Pattern(regexp = "^[A-Z].*$", message = "Genre Should Start with Capital letter")
	String genre;
	@NotNull
	@Pattern(regexp = "^[A-Z].*$", message = "Censor Should Start with Capital letter")
	String censor;
	@NotNull
	@Pattern(regexp = "^[A-Z].*$", message = "Director Should Start with Capital letter")
	String director;
	@NotNull
	@Pattern(regexp = "^[A-Z].*$", message = "Cast Should Start with Capital letter")
	String cast;
	@NotNull
	@Pattern(regexp = "^[A-Z].*$", message = "Synopsis Should Start with Capital letter")
	String synopsis;
	@NotNull
	String img;
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	@Column(name = "relDate")
	@NotNull
	private Date relDate;
}
