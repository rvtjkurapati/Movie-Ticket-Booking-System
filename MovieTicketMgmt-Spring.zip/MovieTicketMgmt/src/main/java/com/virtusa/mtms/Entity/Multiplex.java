package com.virtusa.mtms.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity(name="multiplex")
@AllArgsConstructor
public class Multiplex {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int mxid;
	@Column(unique=true)
	@Pattern(regexp = "^[A-Z].*$",message="Name Should Start with Capital letter")
	String mxname;
	@Pattern(regexp = "^[A-Z].*$",message="Name Should Start with Capital letter")
	String address;
	@OneToOne
	@JoinColumn(name="lid")
	Location lid;
	@ManyToOne
	@JoinColumn(name="cid")
	City cid;

}
