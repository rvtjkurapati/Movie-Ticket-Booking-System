package com.virtusa.mtms.Dao;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.virtusa.mtms.Entity.Customer;
@Repository
@Transactional
public interface ICustomerRepositoryImpl extends JpaRepository<Customer, Integer> {
	
	@Query("select c from customer c where c.uname like ?1%")
	public List<Customer> findByName(String name);
	
	
	@Query("select c from customer c where c.email=?1")
	public List<Customer> findByEmail(String name);
	
	@Query("select c from customer c where c.phone=?1")
	public List<Customer> findByPhone(String name);
	
	
//	@Query("select c from customer c where c.email = ?1 and c.custId! = ?2")
//	public List<Customer> findByThisEmail(String email,int cid);
//	
//	@Query("select c from customer c where c.phone = ?1 and c.custId! = ?2")
//	public List<Customer> findByThisPhone(String email,int cid);
	
	@Modifying
	@Query(value="insert into customer (bal,email,phone,pwd,uname) values(:bal,:email,:phone,:pwd,:uname)", nativeQuery = true)
	public int register(@Param("bal") int bal,@Param("email") String email,@Param("phone") String phone,@Param("pwd") String pwd,@Param("uname") String uname);

	
	
	
}
