package com.virtusa.mtms.Dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Location;
import com.virtusa.mtms.Entity.Theatre;

	@Repository
	@Transactional
	public interface ICityRepositoryImpl extends JpaRepository<City, Integer> {
	
		@Query("select c from city c where c.cname like ?1%")
		public List<City> findByName(String name);
		
		@Query("select cid from city  where cname =?1")
		public int getCid(String name);
		
		@Query("select c  from theatre c where cid =?1")
		public List<Theatre> getTid(City cid);
		
		@Query("select mornid  from morningseats  where tid =?1")
		public List<Integer> getMornid(Theatre tid);
		
		@Query("select matid  from matineeseats  where tid =?1")
		public List<Integer> getMatid(Theatre tid);
		
		@Query("select secid  from secondshowseats  where tid =?1")
		public List<Integer> getSecid(Theatre tid);
		
		@Query("select bid  from booking  where tid =?1")
		public List<Integer> getBid(Theatre tid);
		
		@Query("select mxid  from multiplex  where cid =?1")
		public List<Integer> getMxid(City cid);
		
		@Query("select lid  from location  where cid =?1")
		public List<Integer> getLid(City cid);

	}
	
	