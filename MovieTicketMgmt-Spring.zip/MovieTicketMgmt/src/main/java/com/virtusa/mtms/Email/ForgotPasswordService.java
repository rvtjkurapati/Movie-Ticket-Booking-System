package com.virtusa.mtms.Email;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.virtusa.mtms.Dao.ICustomerRepositoryImpl;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Exceptions.InvalidOtpException;
import com.virtusa.mtms.Exceptions.ResourseNotFoundException;
import com.virtusa.mtms.Service.ICustomerService;
import com.virtusa.mtms.Service.ICustomerServiceImpl;

@Service
public class ForgotPasswordService {
	
	@Autowired
	private ICustomerRepositoryImpl cust;
	
	@Autowired
	private EmailService emailService;
	
	
	
	int otp=0;
	Customer c=null;

	public void forgotPassword(String email) {
		List<Customer> cl=this.cust.findByEmail(email);
		if(cl.isEmpty())
		{
			throw new ResourseNotFoundException("Customer","Email-Id",email);
		}
		c=cl.get(0);
		
		//generating random 6-digit number
		otp=ThreadLocalRandom.current().nextInt(100000, 999999);
		emailService.email(String.format("The OTP is : %s", String.valueOf(otp)), "OTP - Forgot Password", email);
	}
	
	public void validateOtp(String enteredOtp, String newPassword) {
		if(enteredOtp.equals(String.valueOf(otp))) {
			c.setPwd(newPassword);		
			this.cust.save(c);
			this.emailService.email(String.format("Password against email : %s changed successfully", c.getEmail()), "Alert!! Password Changed", c.getEmail());
		}
		else {
			throw new InvalidOtpException();
		}
	}
}

