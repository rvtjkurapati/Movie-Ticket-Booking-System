package com.virtusa.mtms.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Location;
import com.virtusa.mtms.Entity.Multiplex;
import com.virtusa.mtms.Entity.Theatre;

@Repository
public interface ILocationRepositoryImpl extends JpaRepository<Location, Integer> {

	@Query("select c from location c where c.lname like ?1%")
	public List<Location> findByName(String name);

	@Query("select c from location c where c.lname like ?1% and c.lid!=?2")
	public List<Location> findByLName(String name, int lid);

	@Query("select c from location c where c.cid = ?1")
	public List<Location> findByCId(City cid);

	@Query("select c  from multiplex c where c.lid =?1")
	public List<Multiplex> getMxid(Location cid);

	@Query("select tid from theatre  where mxid =?1")
	public List<Integer> getTid(Multiplex tid);

	@Query("select mornid  from morningseats  where mxid =?1")
	public List<Integer> getMornid(Multiplex tid);

	@Query("select matid  from matineeseats  where mxid =?1")
	public List<Integer> getMatid(Multiplex tid);

	@Query("select secid  from secondshowseats  where mxid =?1")
	public List<Integer> getSecid(Multiplex tid);

	@Query("select bid  from booking  where mxid =?1")
	public List<Integer> getBid(Multiplex tid);
}
