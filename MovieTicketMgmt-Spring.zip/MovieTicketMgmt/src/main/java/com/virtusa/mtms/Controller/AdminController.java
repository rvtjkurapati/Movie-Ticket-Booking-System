package com.virtusa.mtms.Controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.mtms.Dao.IAdminRepositoryImpl;
import com.virtusa.mtms.Dao.ICityRepositoryImpl;
import com.virtusa.mtms.Dao.ICustomerRepositoryImpl;
import com.virtusa.mtms.Entity.Admin;
import com.virtusa.mtms.Entity.Availability;
import com.virtusa.mtms.Entity.Book;
import com.virtusa.mtms.Entity.Booking;
import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Entity.Location;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Multiplex;
import com.virtusa.mtms.Entity.Theatre;
import com.virtusa.mtms.Security.AdminJwtService;
import com.virtusa.mtms.Security.AuthenticationRequest;
import com.virtusa.mtms.Security.AuthenticationResponse;
import com.virtusa.mtms.Security.IAdminDetails;
import com.virtusa.mtms.Security.JwtToken;
import com.virtusa.mtms.Service.IAdminServiceImpl;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	IAdminServiceImpl adminRepo;

	@Autowired
	IAdminRepositoryImpl admin;

	@Autowired
	ICityRepositoryImpl cs;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	JwtToken jwtTokenUtil;

	@Autowired
	AdminJwtService adminService;

	@PostMapping(value = "/login")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest)
			throws Exception {

		return adminRepo.createAuthentication(authenticationRequest);

	}

	@GetMapping("/info")
	public String info() {
		return adminRepo.adminInfo();
	}

	@PostMapping("/addMoney")
	public String addMoney(@RequestBody Admin c) {
		return adminRepo.addMoney(c);
	}

	@GetMapping("/getBookings")
	public List<Booking> getBookings() {
		return adminRepo.getBooking();
	}

	@DeleteMapping("/cancelTicket/{id}")
	public String cancelTicket(@PathVariable("id") int cid) {
		return adminRepo.cancelTicket(cid);
	}

	@GetMapping("/checkAvail")
	public String checkAvail(@RequestBody Availability c) {
		return adminRepo.availability(c);
	}

	@PostMapping("/bookMovie")
	public String book(@RequestBody Book c) {
		return adminRepo.booking(c);
	}

	@PutMapping("/changePassword")
	public String changePassword(@RequestBody Admin c) {
		return adminRepo.changePassword(c);
	}

	@GetMapping("/logOut")
	public String logOut() {
		return adminRepo.logOut();
	}

	@GetMapping("/showCities")
	public List<City> showCity() {
		return adminRepo.showCity();
	}

	@PostMapping("/addCity")
	public String addCity(@RequestBody City c) {
		return adminRepo.addCity(c);
	}

	@GetMapping("/searchCitybyId/{id}")
	public Optional<City> searchcitybyId(@PathVariable("id") int id) {
		return adminRepo.searchCityById(id);
	}

	@GetMapping("/searchCitybyName/{id}")
	public List<City> searchcitybyName(@PathVariable("id") String id) {
		return adminRepo.searchCityByName(id);
	}

	@PutMapping("/updateCity/{id}")
	public String updateCity(@RequestBody City c, @PathVariable("id") int cid) {
		return adminRepo.updateCity(c, cid);
	}

	@DeleteMapping("/deleteCity/{id}")
	public String deleteCity(@PathVariable("id") int cid) {
		return adminRepo.deleteCity(cid);
	}

	@GetMapping("/showLocations")
	public List<Location> showLocation() {
		return adminRepo.showLocation();
	}

	@PostMapping("/addLocation")
	public String addLocation(@RequestBody Location c) {
		return adminRepo.addLocation(c);
	}

	@PutMapping("/updateLocation/{id}")
	public String updateLocation(@RequestBody Location c, @PathVariable("id") int cid) {
		return adminRepo.updateLocation(c, cid);
	}

	@DeleteMapping("/deleteLocation/{id}")
	public String deleteLocation(@PathVariable("id") int cid) {
		return adminRepo.deleteLocation(cid);
	}

	@GetMapping("/searchLocationbyId/{id}")
	public Optional<Location> searchlocationId(@PathVariable("id") int id) {
		return adminRepo.searchLocationById(id);
	}

	@GetMapping("/searchLocationbyCId/{id}")
	public List<Location> searchlocationCId(@PathVariable("id") int id) {
		return adminRepo.searchLocationByCId(id);
	}

	@GetMapping("/searchLocationbyName/{id}")
	public List<Location> searchlocationbyName(@PathVariable("id") String id) {
		return adminRepo.searchLocationByName(id);
	}

	@GetMapping("/showMovies")
	public List<Movie> showMovies() {
		return adminRepo.showMovie();
	}

	@PostMapping("/addMovie")
	public String addMovie(@RequestBody Movie c) {
		return adminRepo.addMovie(c);
	}

	@GetMapping("/searchMoviebyId/{id}")
	public Optional<Movie> searchmovieId(@PathVariable("id") int id) {
		return adminRepo.searchMovieById(id);
	}

	@GetMapping("/searchMoviebyName/{id}")
	public List<Movie> searchmoviebyName(@PathVariable("id") String id) {
		return adminRepo.searchMovieByName(id);
	}

	@GetMapping("/searchMoviebyCat/{id}")
	public List<Movie> searchmoviebyCat(@PathVariable("id") String id) {
		return adminRepo.searchMovieByCat(id);
	}

	@GetMapping("/searchMoviebyGen/{id}")
	public List<Movie> searchmoviebyGen(@PathVariable("id") String id) {
		return adminRepo.searchMovieByGen(id);
	}

	@PutMapping("/updateMovie/{id}")
	public String updateMovie(@RequestBody Movie c, @PathVariable("id") int cid) {
		return adminRepo.updateMovie(c, cid);
	}

	@DeleteMapping("/deleteMovie/{id}")
	public String deleteMovie(@PathVariable("id") int cid) {
		return adminRepo.deleteMovie(cid);
	}

	@GetMapping("/showMultiplex")
	public List<Multiplex> showMultiplexs() {
		return adminRepo.showMultiplex();
	}

	@PostMapping("/addMultiplex")
	public String addMultiplex(@RequestBody Multiplex c) {
		return adminRepo.addMultiplex(c);
	}

	@GetMapping("/searchMultiplexbyId/{id}")
	public Optional<Multiplex> searchmultiplexId(@PathVariable("id") int id) {
		return adminRepo.searchMultiplexById(id);
	}

	@GetMapping("/searchMultiplexbyName/{id}")
	public List<Multiplex> searchmultiplexbyName(@PathVariable("id") String id) {
		return adminRepo.searchMultiplexByName(id);
	}

	@GetMapping("/searchMultiplexbyCId/{id}")
	public List<Multiplex> searchmultiplexbyCId(@PathVariable("id") int id) {
		return adminRepo.searchMultiplexByCId(id);
	}

	@PutMapping("/updateMultiplex/{id}")
	public String updateMultiplex(@RequestBody Multiplex c, @PathVariable("id") int cid) {
		return adminRepo.updateMultiplex(c, cid);
	}

	@DeleteMapping("/deleteMultiplex/{id}")
	public String deleteMultiplex(@PathVariable("id") int cid) {
		return adminRepo.deleteMultiplex(cid);
	}

	@GetMapping("/showtheatre")
	public List<Theatre> showTheatres() {
		return adminRepo.showTheatre();
	}

	@PostMapping("/addTheatre")
	public String addTheatre(@RequestBody Theatre c) {
		return adminRepo.addTheatre(c);
	}

	@PutMapping("/updateTheatre/{id}")
	public String updateTheatre(@RequestBody Theatre c, @PathVariable("id") int cid) {
		return adminRepo.updateTheatre(c, cid);
	}

	@DeleteMapping("/deleteTheatre/{id}")
	public String deleteTheatre(@PathVariable("id") int cid) {
		return adminRepo.deleteTheatre(cid);
	}

	@GetMapping("/searchTheatrebyTid/{id}")
	public Optional<Theatre> searchtheatrebyMid(@PathVariable("id") int id) {
		return adminRepo.searchTheatreById(id);
	}

	@GetMapping("/searchTheatrebyMid/{id}")
	public List<Theatre> searchtheatrebyMid(@PathVariable("id") Movie id) {
		return adminRepo.searchTheatreByMvid(id);
	}

	@GetMapping("/searchTheatrebyMxid/{id}")
	public List<Theatre> searchtheatrebyMid(@PathVariable("id") Multiplex id) {
		return adminRepo.searchTheatreByMxid(id);
	}

	@GetMapping("/showbooking")
	public List<Booking> showBooking() {
		return adminRepo.showBooking();
	}

	@PutMapping("/updatebooking/{id}")
	public String updateBooking(@Valid @RequestBody Booking c, @PathVariable("id") int cid) {
		return adminRepo.updateBooking(c, cid);
	}

	@GetMapping("/searchbookingbyId/{id}")
	public Optional<Booking> searchbookingbyId(@PathVariable("id") int id) {
		return adminRepo.searchBookingById(id);
	}

	@GetMapping("/searchbookingbyCid/{id}")
	public List<Booking> searchbookingbyCid(@PathVariable("id") int id) {
		return adminRepo.searchBookingByCid(id);
	}

	@GetMapping("/searchbookingbyMid/{id}")
	public List<Booking> searchbookingbyMid(@PathVariable("id") Movie id) {
		return adminRepo.searchBookingByMid(id);
	}

	@DeleteMapping("/deleteBooking/{id}")
	public String deleteBooking(@PathVariable("id") int cid) {
		return adminRepo.deleteBooking(cid);
	}

	@GetMapping("/showCust")
	public List<Customer> showCust() {
		return adminRepo.showCust();
	}

	@PostMapping("/addCust")
	public String addCust(@RequestBody Customer c) {
		return adminRepo.addCust(c);
	}

	@GetMapping("/searchCustbyId/{id}")
	public Optional<Customer> searchcustbyId(@PathVariable("id") int id) {
		return adminRepo.searchCustById(id);
	}

	@GetMapping("/searchCustbyName/{id}")
	public List<Customer> searchcustbyName(@PathVariable("id") String id) {
		return adminRepo.searchCustByName(id);
	}

	@PutMapping("/updateCust/{id}")
	public String updateCust(@RequestBody Customer c, @PathVariable("id") int cid) {
		return adminRepo.updateCust(c, cid);
	}

	@DeleteMapping("/deleteCust/{id}")
	public String deleteCust(@PathVariable("id") int cid) {
		return adminRepo.deleteCust(cid);
	}

}
