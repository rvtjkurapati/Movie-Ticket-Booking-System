package com.virtusa.mtms.Dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.mtms.Entity.Admin;

@Repository
@Transactional
public interface IAdminRepositoryImpl extends JpaRepository<Admin, Integer> {

	@Query("select c from admin c where c.uname like ?1%")
	public List<Admin> findByName(String name);

	@Query("select c from admin c where c.uname = ?1 and c.pwd = ?2")
	public Optional<Admin> login(String uname, String pwd);

	Admin findByUname(String uname);

}
