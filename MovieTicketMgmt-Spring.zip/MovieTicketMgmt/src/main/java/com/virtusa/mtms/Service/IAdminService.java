package com.virtusa.mtms.Service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;


import com.virtusa.mtms.Entity.Admin;
import com.virtusa.mtms.Entity.Availability;
import com.virtusa.mtms.Entity.Book;
import com.virtusa.mtms.Entity.Booking;
import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Entity.Location;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Multiplex;
import com.virtusa.mtms.Entity.Theatre;
import com.virtusa.mtms.Security.AuthenticationRequest;
public interface IAdminService {

	public ResponseEntity<?> createAuthentication(@RequestBody AuthenticationRequest authenticationRequest);

	public String logOut();

	public String adminInfo();

	public String addMoney(@RequestBody Admin c);

	public List<Booking> getBooking();

	public String changePassword(@RequestBody Admin c);

	public String cancelTicket(@PathVariable("id") int bid);

	public String availability(@RequestBody Availability c);

	public String booking(@RequestBody Book c);

	public List<City> showCity();

	public String addCity(@RequestBody City c);

	public String updateCity(@Valid @RequestBody City c, @PathVariable int cid);

	public Optional<City> searchCityById(@PathVariable("id") int cid);

	public List<City> searchCityByName(@PathVariable("name") String cid);

	public String deleteCity(@PathVariable int cid);

	public List<Location> showLocation();

	public String addLocation(@RequestBody Location c);

	public String updateLocation(@RequestBody Location c, @PathVariable int lid);

	public Optional<Location> searchLocationById(@PathVariable("id") int cid);

	public List<Location> searchLocationByCId(@PathVariable("id") int cid);

	public List<Location> searchLocationByName(@PathVariable("id") String cid);

	public String deleteLocation(@PathVariable int cid);

	public List<Movie> showMovie();

	public String addMovie(@RequestBody Movie c);

	public String updateMovie(@RequestBody Movie c, @PathVariable int cid);

	public Optional<Movie> searchMovieById(@PathVariable("id") int cid);

	public List<Movie> searchMovieByName(@PathVariable("id") String cid);

	public List<Movie> searchMovieByCat(@PathVariable("id") String cid);

	public List<Movie> searchMovieByGen(@PathVariable("id") String cid);

	public String deleteMovie(@PathVariable int cid);

	public List<Multiplex> showMultiplex();

	public String addMultiplex(@RequestBody Multiplex c);

	public String updateMultiplex(@RequestBody Multiplex c, @PathVariable int lid);

	public Optional<Multiplex> searchMultiplexById(@PathVariable("id") int cid);

	public List<Multiplex> searchMultiplexByCId(@PathVariable("id") int cid);

	public List<Multiplex> searchMultiplexByName(@PathVariable("id") String cid);

	public String deleteMultiplex(@PathVariable int cid);

	public List<Theatre> showTheatre();

	public String addTheatre(@RequestBody Theatre c);

	public String updateTheatre(@RequestBody Theatre c, @PathVariable int cid);

	public Optional<Theatre> searchTheatreById(@PathVariable("id") int cid);

	public List<Theatre> searchTheatreByMvid(@PathVariable("id") Movie cid);

	public List<Theatre> searchTheatreByMxid(@PathVariable("id") Multiplex cid);

	public String deleteTheatre(@PathVariable int cid);

	public List<Booking> showBooking();

	public String updateBooking(@Valid @RequestBody Booking c, @PathVariable int bid);

	public Optional<Booking> searchBookingById(@PathVariable("id") int cid);

	public List<Booking> searchBookingByCid(@PathVariable("id") int cid);

	public List<Booking> searchBookingByMid(@PathVariable("id") Movie cid);

	public String deleteBooking(@PathVariable int cid);

	public List<Customer> showCust();

	public String addCust(@RequestBody Customer c);

	public String updateCust(@RequestBody Customer c, @PathVariable int cid);

	public Optional<Customer> searchCustById(@PathVariable("id") int cid);

	public List<Customer> searchCustByName(@PathVariable("name") String cid);

	public String deleteCust(@PathVariable int cid);

}
