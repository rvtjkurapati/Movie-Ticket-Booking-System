package com.virtusa.mtms.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity(name="customer")
public class Customer {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int custId;
	@Pattern(regexp = "^[A-Z].*$",message="Name Should Start with Capital letter")
	String uname;
	@Pattern(regexp = "^(?=.*[0-9])"+ "(?=.*[a-z])(?=.*[A-Z])"+ "(?=.*[@#$%^!&+=])"+ "(?=\\S+$).{8,20}$",message="Invalid Password")
	String pwd;
	@Column(unique=true)
	@Pattern(regexp = "^(0|91)?[6-9][0-9]{9}$",message="Invalid Phone Number")
	String phone;
	@Column(unique=true)
	@Pattern(regexp = "^(?=.{1,64}@)[A-Za-z0-9-]+(\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$",message="Invalid Email")
	String email;
	int bal;
	
	
}
