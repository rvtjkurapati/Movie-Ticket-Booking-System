package com.virtusa.mtms.Email;

public class Email {
	
	private String message;
	private String subject;
	private String receipient;
	
	public Email(String message, String subject, String receipient) {
		
		this.message = message;
		this.subject = subject;
		this.receipient = receipient;
	}

	public Email() {
		super();
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getReceipient() {
		return receipient;
	}

	public void setReceipient(String receipient) {
		this.receipient = receipient;
	}

	@Override
	public String toString() {
		return "Email [message=" + message + ", subject=" + subject + ", receipient=" + receipient + "]";
	}
	
	

}
