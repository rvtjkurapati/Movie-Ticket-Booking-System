package com.virtusa.mtms.Entity;

import java.sql.Date;

public class Availability {
	
	
	Theatre tid;
	Date showdate;
	String showtime;
	public Availability() {
		super();
	}
	public Availability(Theatre tid, Date showdate, String showtime) {
		super();
		this.tid = tid;
		this.showdate = showdate;
		this.showtime = showtime;
	}
	public Theatre getTid() {
		return tid;
	}
	public void setTid(Theatre tid) {
		this.tid = tid;
	}
	public Date getShowdate() {
		return showdate;
	}
	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}
	public String getShowtime() {
		return showtime;
	}
	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}
	@Override
	public String toString() {
		return "Availability [tid=" + tid + ", showdate=" + showdate + ", showtime=" + showtime + "]";
	}
	

}
