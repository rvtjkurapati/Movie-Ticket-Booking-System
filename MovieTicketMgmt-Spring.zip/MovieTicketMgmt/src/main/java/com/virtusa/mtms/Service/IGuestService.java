package com.virtusa.mtms.Service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.mtms.Entity.Availability;
import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Theatre;

public interface IGuestService {

	public List<City> showCity();

	public String welcome();

	public String register(@RequestBody Customer c);

	public List<Movie> showMovie();

	public List<Movie> searchMovieByName(@PathVariable("id") String cid);

	public List<Movie> searchMovieByCat(@PathVariable("id") String cid);

	public List<Movie> searchMovieByGen(@PathVariable("id") String cid);

	public List<Movie> searchMovieByLoc(@PathVariable("id") String cid);

	public List<Theatre> searchTheatreByMvid(@PathVariable("id") Movie cid);

	public String availability(@RequestBody Availability c);

}
