package com.virtusa.mtms.Service;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.mtms.Dao.IAdminRepositoryImpl;
import com.virtusa.mtms.Dao.IBookingRepositoryImpl;
import com.virtusa.mtms.Dao.ICustomerRepositoryImpl;
import com.virtusa.mtms.Dao.IMatineeSeatsRepositoryImpl;
import com.virtusa.mtms.Dao.IMorningSeatsRepositoryImpl;
import com.virtusa.mtms.Dao.ISecondshowSeatsRepositoryImpl;
import com.virtusa.mtms.Dao.ISuperAdminRepositoryImpl;
import com.virtusa.mtms.Dao.ITheatreRepositoryImpl;
import com.virtusa.mtms.Entity.Admin;
import com.virtusa.mtms.Entity.Booking;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.SuperAdmin;
import com.virtusa.mtms.Entity.Theatre;
import com.virtusa.mtms.Exceptions.BadRequestException;
import com.virtusa.mtms.Exceptions.ForbiddenException;
import com.virtusa.mtms.Exceptions.NotFoundException;

@Component
public class ISuperAdminServiceImpl {

	@Autowired
	IAdminRepositoryImpl admin;

	@Autowired
	ISuperAdminRepositoryImpl sa;

	@Autowired
	IBookingRepositoryImpl book;

	@Autowired
	ITheatreRepositoryImpl ts;

	@Autowired
	ICustomerRepositoryImpl cust;

	@Autowired
	Environment env;

	private static final Logger superlog = LoggerFactory.getLogger(ISuperAdminServiceImpl.class);

	public static SuperAdmin cs = new SuperAdmin();

	public String superlogin(@RequestBody SuperAdmin c) {
		
		if(c.getUname()==null && c.getPwd()==null) {
			throw new NotFoundException("uname and pwd should not be Empty");
			
		}
		
		else if(c.getUname()==null) {
			throw new NotFoundException("uname should not be Empty");
			
		}
		
		else if(c.getPwd()==null) {
			throw new NotFoundException("pwd should not be Empty");
			
		}
		String uname = c.getUname();
		String pwd = c.getPwd();
		List<SuperAdmin> cl = sa.findByName(uname);

		try {

			if ((cl.get(0).getPwd()).equals(pwd)) {
				cs = cl.get(0);

				superlog.info(cs.getSid() + " " + env.getProperty("sl"));
				return env.getProperty("sl");
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new NotFoundException(env.getProperty("pli"));
		}
		superlog.error(env.getProperty("lf"));
		return env.getProperty("lf");
	}

	public String logOut() {
		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		cs = null;

		return "You Have Been Logged Out";

	}

	public String changePwd(@RequestBody SuperAdmin c) {
		
		if(c.getPwd()==null)
		{
			throw new BadRequestException("pwd should not be Empty");
		}
		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		List<SuperAdmin> obj1 = sa.findByName(cs.getUname());
		SuperAdmin sp = obj1.get(0);

		sp.setPwd(c.getPwd());
		try {
			sa.save(sp);
		} catch (Exception e) {
			superlog.error(env.getProperty("iuc"));
			throw new BadRequestException(env.getProperty("iuc"));
		}

		superlog.info(env.getProperty("sadpc"));
		return env.getProperty("sadpc");
	}

	public List<Admin> showAdmin() {

		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		List<Admin> cl = admin.findAll();
		if (cl.isEmpty()) {
			superlog.error(env.getProperty("adnf"));
			throw new NotFoundException(env.getProperty("adnf"));
		}
		superlog.info(env.getProperty("adls"));
		return cl;
	}

	public String addAdmin(@RequestBody Admin c) {
		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		try {
			c.setBal(500);
			admin.save(c);
		} catch (DataIntegrityViolationException e) {
			superlog.error(env.getProperty("apad"));
			throw new BadRequestException(env.getProperty("apad"));
		}

		superlog.info(c.getUname() + " " + env.getProperty("aads"));
		return env.getProperty("aads");
	}

	public String updateAdmin(@RequestBody Admin c, @PathVariable int lid) {

		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		Optional<Admin> obj1 = admin.findById(lid).map(mcity -> {
			mcity.setPwd(c.getPwd());
			mcity.setUname(c.getUname());
			try {
				return admin.save(mcity);
			} catch (DataIntegrityViolationException e) {

				superlog.error(env.getProperty("apad"));
				throw new BadRequestException(env.getProperty("apad"));
			}
		});
		if (obj1.isEmpty()) {
			superlog.error(env.getProperty("iadi"));
			throw new BadRequestException(env.getProperty("iadi"));
		}
		superlog.info(env.getProperty("adus"));
		return env.getProperty("adus");
	}

	public Optional<Admin> searchAdminById(@PathVariable("id") int cid) {

		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}
		Optional<Admin> obj = admin.findById(cid);
		if (obj.isPresent()) {
			superlog.info(env.getProperty("adls"));
			return obj;
		}
		superlog.error(env.getProperty("adnf"));
		throw new NotFoundException(env.getProperty("adnf"));
	}

	public List<Admin> searchAdminByName(@PathVariable("id") String cid) {
		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		List<Admin> obj = admin.findByName(cid);
		if (!obj.isEmpty()) {
			superlog.info(env.getProperty("adls"));
			return obj;
		}

		superlog.error(env.getProperty("adnf"));
		throw new NotFoundException(env.getProperty("adnf"));
	}

	public String deleteAdmin(@PathVariable int cid) {

		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		Optional<Admin> obj = admin.findById(cid);
		if (!obj.isEmpty()) {
			List<Integer> bk = book.getByCid(cid);
			book.deleteAllById(bk);
			admin.deleteById(cid);
			superlog.info(cid + " " + env.getProperty("adds"));
			return env.getProperty("adds");

		} else {
			superlog.error(env.getProperty("iadi"));
			throw new NotFoundException(env.getProperty("iadi"));
		}
	}

	public List<Booking> showBooking() {
		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		List<Booking> cl = book.findAll();
		if (cl.isEmpty()) {
			superlog.error(env.getProperty("bnf"));
			throw new NotFoundException(env.getProperty("bnf"));
		}
		superlog.info(env.getProperty("bls"));
		return cl;
	}

	public Optional<Booking> searchBookingById(@PathVariable("id") int cid) {
		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		Optional<Booking> obj = book.findById(cid);
		if (obj.isPresent()) {
			superlog.info(env.getProperty("bls"));
			return obj;
		}
		superlog.error(env.getProperty("bnf"));
		throw new NotFoundException(env.getProperty("bnf"));
	}

	public List<Booking> searchBookingByCid(@PathVariable("id") int cid) {
		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		List<Booking> obj = book.findByCid(cid);
		if (!obj.isEmpty()) {
			superlog.info(env.getProperty("bls"));
			return obj;
		}

		superlog.error(env.getProperty("bnf"));
		throw new NotFoundException(env.getProperty("bnf"));
	}

	public List<Booking> searchBookingByMid(@PathVariable("id") Movie cid) {
		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		List<Booking> obj = book.findByMid(cid);
		if (!obj.isEmpty()) {
			superlog.info(env.getProperty("bls"));
			return obj;
		}

		superlog.error(env.getProperty("bnf"));
		throw new NotFoundException(env.getProperty("bnf"));
	}

	public String deleteBooking(@PathVariable int cid) {

		try {
			List<SuperAdmin> obj = sa.findByName(cs.getUname());

			if (obj.isEmpty()) {
				superlog.error(env.getProperty("pli"));
				throw new ForbiddenException(env.getProperty("pli"));
			}
		} catch (Exception e) {
			superlog.error(env.getProperty("pli"));
			throw new ForbiddenException(env.getProperty("pli"));
		}

		Optional<Booking> obj = book.findById(cid);

		if (obj.isEmpty()) {
			superlog.error(env.getProperty("ibi"));
			throw new NotFoundException(env.getProperty("ibi"));
		}
		String seats = obj.get().getSeats();
		String s = seats;
		String[] str = s.split("[,]");
		int count = str.length;
		Optional<Theatre> t;
		if (!obj.isEmpty()) {
			t = ts.findById(obj.get().getTid().getTid());

			double add1 = (t.get().getPrice()) * 0.7;
			int add = (int) add1 * count;
			int custid = obj.get().getCustId();
			Optional<Customer> cs = cust.findById(custid);
			if (!cs.isEmpty()) {
				int bal = cs.get().getBal();
				Optional<Customer> obj1 = cust.findById(custid).map(mcity -> {
					mcity.setBal(bal + add);
					return cust.save(mcity);
				});
			} else {
				Optional<Admin> ad = admin.findById(custid);
				int bal = ad.get().getBal();
				Optional<Admin> obj2 = admin.findById(custid).map(mcity -> {
					mcity.setBal(bal + add);
					return admin.save(mcity);
				});
			}
			Theatre tid = obj.get().getTid();
			Date date = obj.get().getShowdate();

			java.sql.Date showdate = new java.sql.Date(date.getTime());
			String showtime = obj.get().getShowtime();

			if (showtime.equals("Morning")) {
				for (String a : str) {
					System.out.println(a);
					if (a.equals("A1")) {
						book.modmornA1(tid, showdate);
					}

					else if (a.equals("A2")) {
						book.modmornA2(tid, showdate);
					}

					else if (a.equals("A3")) {
						book.modmornA3(tid, showdate);
					}

					else if (a.equals("A4")) {
						book.modmornA4(tid, showdate);
					}

					else if (a.equals("A5")) {
						book.modmornA5(tid, showdate);
					}

					else if (a.equals("A6")) {
						book.modmornA6(tid, showdate);
					}

					else if (a.equals("A7")) {
						book.modmornA7(tid, showdate);
					}

					else if (a.equals("A8")) {
						book.modmornA8(tid, showdate);
					}

					else if (a.equals("A9")) {
						book.modmornA9(tid, showdate);
					}

					else if (a.equals("A10")) {
						book.modmornA10(tid, showdate);
					}

					else if (a.equals("A11")) {
						book.modmornA11(tid, showdate);
					}

					else if (a.equals("A12")) {
						book.modmornA12(tid, showdate);
					}

					else if (a.equals("B1")) {
						book.modmornB1(tid, showdate);
					}

					else if (a.equals("B2")) {
						book.modmornB2(tid, showdate);
					}

					else if (a.equals("B3")) {
						book.modmornB3(tid, showdate);
					}

					else if (a.equals("B4")) {
						book.modmornB4(tid, showdate);
					}

					else if (a.equals("B5")) {
						book.modmornB5(tid, showdate);
					}

					else if (a.equals("B6")) {
						book.modmornB6(tid, showdate);
					}

					else if (a.equals("B7")) {
						book.modmornB7(tid, showdate);
					}

					else if (a.equals("B8")) {
						book.modmornB8(tid, showdate);
					}

					else if (a.equals("B9")) {
						book.modmornB9(tid, showdate);
					}

					else if (a.equals("B10")) {
						book.modmornB10(tid, showdate);
					}

					else if (a.equals("B11")) {
						book.modmornB11(tid, showdate);
					}

					else if (a.equals("B12")) {
						book.modmornB12(tid, showdate);
					}

					else if (a.equals("C1")) {
						book.modmornC1(tid, showdate);
					}

					else if (a.equals("C2")) {
						book.modmornC2(tid, showdate);
					}

					else if (a.equals("C3")) {
						book.modmornC3(tid, showdate);
					}

					else if (a.equals("C4")) {
						book.modmornC4(tid, showdate);
					}

					else if (a.equals("C5")) {
						book.modmornC5(tid, showdate);
					}

					else if (a.equals("C6")) {
						book.modmornC6(tid, showdate);
					}

					else if (a.equals("C7")) {
						book.modmornC7(tid, showdate);
					}

					else if (a.equals("C8")) {
						book.modmornC8(tid, showdate);
					}

					else if (a.equals("C9")) {
						book.modmornC9(tid, showdate);
					}

					else if (a.equals("C10")) {
						book.modmornC10(tid, showdate);
					}

					else if (a.equals("C11")) {
						book.modmornC11(tid, showdate);
					}

					else if (a.equals("C12")) {
						book.modmornC12(tid, showdate);
					}

					else if (a.equals("D1")) {
						book.modmornD1(tid, showdate);
					}

					else if (a.equals("D2")) {
						book.modmornD2(tid, showdate);
					}

					else if (a.equals("D3")) {
						book.modmornD3(tid, showdate);
					}

					else if (a.equals("D4")) {
						book.modmornD4(tid, showdate);
					}

					else if (a.equals("D5")) {
						book.modmornD5(tid, showdate);
					}

					else if (a.equals("D6")) {
						book.modmornD6(tid, showdate);
					}

					else if (a.equals("D7")) {
						book.modmornD7(tid, showdate);
					}

					else if (a.equals("D8")) {
						book.modmornD8(tid, showdate);
					}

					else if (a.equals("D9")) {
						book.modmornD9(tid, showdate);
					}

					else if (a.equals("D10")) {
						book.modmornD10(tid, showdate);
					}

					else if (a.equals("D11")) {
						book.modmornD11(tid, showdate);
					}

					else if (a.equals("D12")) {
						book.modmornD12(tid, showdate);
					}

					else if (a.equals("E1")) {
						book.modmornE1(tid, showdate);
					}

					else if (a.equals("E2")) {
						book.modmornE2(tid, showdate);
					}

					else if (a.equals("E3")) {
						book.modmornE3(tid, showdate);
					}

					else if (a.equals("E4")) {
						book.modmornE4(tid, showdate);
					}

					else if (a.equals("E5")) {
						book.modmornE5(tid, showdate);
					}

					else if (a.equals("E6")) {
						book.modmornE6(tid, showdate);
					}

					else if (a.equals("E7")) {
						book.modmornE7(tid, showdate);
					}

					else if (a.equals("E8")) {
						book.modmornE8(tid, showdate);
					}

					else if (a.equals("E9")) {
						book.modmornE9(tid, showdate);
					}

					else if (a.equals("E10")) {
						book.modmornE10(tid, showdate);
					}

					else if (a.equals("E11")) {
						book.modmornE11(tid, showdate);
					}

					else if (a.equals("E12")) {
						book.modmornE12(tid, showdate);
					}

					else if (a.equals("F1")) {
						book.modmornF1(tid, showdate);
					}

					else if (a.equals("F2")) {
						book.modmornF2(tid, showdate);
					}

					else if (a.equals("F3")) {
						book.modmornF3(tid, showdate);
					}

					else if (a.equals("F4")) {
						book.modmornF4(tid, showdate);
					}

					else if (a.equals("F5")) {
						book.modmornF5(tid, showdate);
					}

					else if (a.equals("F6")) {
						book.modmornF6(tid, showdate);
					}

					else if (a.equals("F7")) {
						book.modmornF7(tid, showdate);
					}

					else if (a.equals("F8")) {
						book.modmornF8(tid, showdate);
					}

					else if (a.equals("F9")) {
						book.modmornF9(tid, showdate);
					}

					else if (a.equals("F10")) {
						book.modmornF10(tid, showdate);
					}

					else if (a.equals("F11")) {
						book.modmornF11(tid, showdate);
					}

					else if (a.equals("F12")) {
						book.modmornF12(tid, showdate);
					}

					else if (a.equals("G1")) {
						book.modmornG1(tid, showdate);
					}

					else if (a.equals("G2")) {
						book.modmornG2(tid, showdate);
					}

					else if (a.equals("G3")) {
						book.modmornG3(tid, showdate);
					}

					else if (a.equals("G4")) {
						book.modmornG4(tid, showdate);
					}

					else if (a.equals("G5")) {
						book.modmornG5(tid, showdate);
					}

					else if (a.equals("G6")) {
						book.modmornG6(tid, showdate);
					}

					else if (a.equals("G7")) {
						book.modmornG7(tid, showdate);
					}

					else if (a.equals("G8")) {
						book.modmornG8(tid, showdate);
					}

					else if (a.equals("G9")) {
						book.modmornG9(tid, showdate);
					}

					else if (a.equals("G10")) {
						book.modmornG10(tid, showdate);
					}

					else if (a.equals("G11")) {
						book.modmornG11(tid, showdate);
					}

					else if (a.equals("G12")) {
						book.modmornG12(tid, showdate);
					}

					else if (a.equals("H1")) {
						book.modmornH1(tid, showdate);
					}

					else if (a.equals("H2")) {
						book.modmornH2(tid, showdate);
					}

					else if (a.equals("H3")) {
						book.modmornH3(tid, showdate);
					}

					else if (a.equals("H4")) {
						book.modmornH4(tid, showdate);
					}

					else if (a.equals("H5")) {
						book.modmornH5(tid, showdate);
					}

					else if (a.equals("H6")) {
						book.modmornH6(tid, showdate);
					}

					else if (a.equals("H7")) {
						book.modmornH7(tid, showdate);
					}

					else if (a.equals("H8")) {
						book.modmornH8(tid, showdate);
					}

					else if (a.equals("H9")) {
						book.modmornH9(tid, showdate);
					}

					else if (a.equals("H10")) {
						book.modmornH10(tid, showdate);
					}

					else if (a.equals("H11")) {
						book.modmornH11(tid, showdate);
					}

					else if (a.equals("H12")) {
						book.modmornH12(tid, showdate);
					}

					else if (a.equals("I1")) {
						book.modmornI1(tid, showdate);
					}

					else if (a.equals("I2")) {
						book.modmornI2(tid, showdate);
					}

					else if (a.equals("I3")) {
						book.modmornI3(tid, showdate);
					}

					else if (a.equals("I4")) {
						book.modmornI4(tid, showdate);
					}

					else if (a.equals("I5")) {
						book.modmornI5(tid, showdate);
					}

					else if (a.equals("I6")) {
						book.modmornI6(tid, showdate);
					}

					else if (a.equals("I7")) {
						book.modmornI7(tid, showdate);
					}

					else if (a.equals("I8")) {
						book.modmornI8(tid, showdate);
					}

					else if (a.equals("I9")) {
						book.modmornI9(tid, showdate);
					}

					else if (a.equals("I10")) {
						book.modmornI10(tid, showdate);
					}

					else if (a.equals("I11")) {
						book.modmornI11(tid, showdate);
					}

					else if (a.equals("I12")) {
						book.modmornI12(tid, showdate);
					}

					else if (a.equals("J1")) {
						book.modmornJ1(tid, showdate);
					}

					else if (a.equals("J2")) {
						book.modmornJ2(tid, showdate);
					}

					else if (a.equals("J3")) {
						book.modmornJ3(tid, showdate);
					}

					else if (a.equals("J4")) {
						book.modmornJ4(tid, showdate);
					}

					else if (a.equals("J5")) {
						book.modmornJ5(tid, showdate);
					}

					else if (a.equals("J6")) {
						book.modmornJ6(tid, showdate);
					}

					else if (a.equals("J7")) {
						book.modmornJ7(tid, showdate);
					}

					else if (a.equals("J8")) {
						book.modmornJ8(tid, showdate);
					}

					else if (a.equals("J9")) {
						book.modmornJ9(tid, showdate);
					}

					else if (a.equals("J10")) {
						book.modmornJ10(tid, showdate);
					}

					else if (a.equals("J11")) {
						book.modmornJ11(tid, showdate);
					}

					else if (a.equals("J12")) {
						book.modmornJ12(tid, showdate);
					}
				}
			}

			else if (showtime.equals("Matinee")) {
				for (String a : str) {
					System.out.println(a);
					if (a.equals("A1")) {
						book.modmatA1(tid, showdate);
					}

					else if (a.equals("A2")) {
						book.modmatA2(tid, showdate);
					}

					else if (a.equals("A3")) {
						book.modmatA3(tid, showdate);
					}

					else if (a.equals("A4")) {
						book.modmatA4(tid, showdate);
					}

					else if (a.equals("A5")) {
						book.modmatA5(tid, showdate);
					}

					else if (a.equals("A6")) {
						book.modmatA6(tid, showdate);
					}

					else if (a.equals("A7")) {
						book.modmatA7(tid, showdate);
					}

					else if (a.equals("A8")) {
						book.modmatA8(tid, showdate);
					}

					else if (a.equals("A9")) {
						book.modmatA9(tid, showdate);
					}

					else if (a.equals("A10")) {
						book.modmatA10(tid, showdate);
					}

					else if (a.equals("A11")) {
						book.modmatA11(tid, showdate);
					}

					else if (a.equals("A12")) {
						book.modmatA12(tid, showdate);
					}

					else if (a.equals("B1")) {
						book.modmatB1(tid, showdate);
					}

					else if (a.equals("B2")) {
						book.modmatB2(tid, showdate);
					}

					else if (a.equals("B3")) {
						book.modmatB3(tid, showdate);
					}

					else if (a.equals("B4")) {
						book.modmatB4(tid, showdate);
					}

					else if (a.equals("B5")) {
						book.modmatB5(tid, showdate);
					}

					else if (a.equals("B6")) {
						book.modmatB6(tid, showdate);
					}

					else if (a.equals("B7")) {
						book.modmatB7(tid, showdate);
					}

					else if (a.equals("B8")) {
						book.modmatB8(tid, showdate);
					}

					else if (a.equals("B9")) {
						book.modmatB9(tid, showdate);
					}

					else if (a.equals("B10")) {
						book.modmatB10(tid, showdate);
					}

					else if (a.equals("B11")) {
						book.modmatB11(tid, showdate);
					}

					else if (a.equals("B12")) {
						book.modmatB12(tid, showdate);
					}

					else if (a.equals("C1")) {
						book.modmatC1(tid, showdate);
					}

					else if (a.equals("C2")) {
						book.modmatC2(tid, showdate);
					}

					else if (a.equals("C3")) {
						book.modmatC3(tid, showdate);
					}

					else if (a.equals("C4")) {
						book.modmatC4(tid, showdate);
					}

					else if (a.equals("C5")) {
						book.modmatC5(tid, showdate);
					}

					else if (a.equals("C6")) {
						book.modmatC6(tid, showdate);
					}

					else if (a.equals("C7")) {
						book.modmatC7(tid, showdate);
					}

					else if (a.equals("C8")) {
						book.modmatC8(tid, showdate);
					}

					else if (a.equals("C9")) {
						book.modmatC9(tid, showdate);
					}

					else if (a.equals("C10")) {
						book.modmatC10(tid, showdate);
					}

					else if (a.equals("C11")) {
						book.modmatC11(tid, showdate);
					}

					else if (a.equals("C12")) {
						book.modmatC12(tid, showdate);
					}

					else if (a.equals("D1")) {
						book.modmatD1(tid, showdate);
					}

					else if (a.equals("D2")) {
						book.modmatD2(tid, showdate);
					}

					else if (a.equals("D3")) {
						book.modmatD3(tid, showdate);
					}

					else if (a.equals("D4")) {
						book.modmatD4(tid, showdate);
					}

					else if (a.equals("D5")) {
						book.modmatD5(tid, showdate);
					}

					else if (a.equals("D6")) {
						book.modmatD6(tid, showdate);
					}

					else if (a.equals("D7")) {
						book.modmatD7(tid, showdate);
					}

					else if (a.equals("D8")) {
						book.modmatD8(tid, showdate);
					}

					else if (a.equals("D9")) {
						book.modmatD9(tid, showdate);
					}

					else if (a.equals("D10")) {
						book.modmatD10(tid, showdate);
					}

					else if (a.equals("D11")) {
						book.modmatD11(tid, showdate);
					}

					else if (a.equals("D12")) {
						book.modmatD12(tid, showdate);
					}

					else if (a.equals("E1")) {
						book.modmatE1(tid, showdate);
					}

					else if (a.equals("E2")) {
						book.modmatE2(tid, showdate);
					}

					else if (a.equals("E3")) {
						book.modmatE3(tid, showdate);
					}

					else if (a.equals("E4")) {
						book.modmatE4(tid, showdate);
					}

					else if (a.equals("E5")) {
						book.modmatE5(tid, showdate);
					}

					else if (a.equals("E6")) {
						book.modmatE6(tid, showdate);
					}

					else if (a.equals("E7")) {
						book.modmatE7(tid, showdate);
					}

					else if (a.equals("E8")) {
						book.modmatE8(tid, showdate);
					}

					else if (a.equals("E9")) {
						book.modmatE9(tid, showdate);
					}

					else if (a.equals("E10")) {
						book.modmatE10(tid, showdate);
					}

					else if (a.equals("E11")) {
						book.modmatE11(tid, showdate);
					}

					else if (a.equals("E12")) {
						book.modmatE12(tid, showdate);
					}

					else if (a.equals("F1")) {
						book.modmatF1(tid, showdate);
					}

					else if (a.equals("F2")) {
						book.modmatF2(tid, showdate);
					}

					else if (a.equals("F3")) {
						book.modmatF3(tid, showdate);
					}

					else if (a.equals("F4")) {
						book.modmatF4(tid, showdate);
					}

					else if (a.equals("F5")) {
						book.modmatF5(tid, showdate);
					}

					else if (a.equals("F6")) {
						book.modmatF6(tid, showdate);
					}

					else if (a.equals("F7")) {
						book.modmatF7(tid, showdate);
					}

					else if (a.equals("F8")) {
						book.modmatF8(tid, showdate);
					}

					else if (a.equals("F9")) {
						book.modmatF9(tid, showdate);
					}

					else if (a.equals("F10")) {
						book.modmatF10(tid, showdate);
					}

					else if (a.equals("F11")) {
						book.modmatF11(tid, showdate);
					}

					else if (a.equals("F12")) {
						book.modmatF12(tid, showdate);
					}

					else if (a.equals("G1")) {
						book.modmatG1(tid, showdate);
					}

					else if (a.equals("G2")) {
						book.modmatG2(tid, showdate);
					}

					else if (a.equals("G3")) {
						book.modmatG3(tid, showdate);
					}

					else if (a.equals("G4")) {
						book.modmatG4(tid, showdate);
					}

					else if (a.equals("G5")) {
						book.modmatG5(tid, showdate);
					}

					else if (a.equals("G6")) {
						book.modmatG6(tid, showdate);
					}

					else if (a.equals("G7")) {
						book.modmatG7(tid, showdate);
					}

					else if (a.equals("G8")) {
						book.modmatG8(tid, showdate);
					}

					else if (a.equals("G9")) {
						book.modmatG9(tid, showdate);
					}

					else if (a.equals("G10")) {
						book.modmatG10(tid, showdate);
					}

					else if (a.equals("G11")) {
						book.modmatG11(tid, showdate);
					}

					else if (a.equals("G12")) {
						book.modmatG12(tid, showdate);
					}

					else if (a.equals("H1")) {
						book.modmatH1(tid, showdate);
					}

					else if (a.equals("H2")) {
						book.modmatH2(tid, showdate);
					}

					else if (a.equals("H3")) {
						book.modmatH3(tid, showdate);
					}

					else if (a.equals("H4")) {
						book.modmatH4(tid, showdate);
					}

					else if (a.equals("H5")) {
						book.modmatH5(tid, showdate);
					}

					else if (a.equals("H6")) {
						book.modmatH6(tid, showdate);
					}

					else if (a.equals("H7")) {
						book.modmatH7(tid, showdate);
					}

					else if (a.equals("H8")) {
						book.modmatH8(tid, showdate);
					}

					else if (a.equals("H9")) {
						book.modmatH9(tid, showdate);
					}

					else if (a.equals("H10")) {
						book.modmatH10(tid, showdate);
					}

					else if (a.equals("H11")) {
						book.modmatH11(tid, showdate);
					}

					else if (a.equals("H12")) {
						book.modmatH12(tid, showdate);
					}

					else if (a.equals("I1")) {
						book.modmatI1(tid, showdate);
					}

					else if (a.equals("I2")) {
						book.modmatI2(tid, showdate);
					}

					else if (a.equals("I3")) {
						book.modmatI3(tid, showdate);
					}

					else if (a.equals("I4")) {
						book.modmatI4(tid, showdate);
					}

					else if (a.equals("I5")) {
						book.modmatI5(tid, showdate);
					}

					else if (a.equals("I6")) {
						book.modmatI6(tid, showdate);
					}

					else if (a.equals("I7")) {
						book.modmatI7(tid, showdate);
					}

					else if (a.equals("I8")) {
						book.modmatI8(tid, showdate);
					}

					else if (a.equals("I9")) {
						book.modmatI9(tid, showdate);
					}

					else if (a.equals("I10")) {
						book.modmatI10(tid, showdate);
					}

					else if (a.equals("I11")) {
						book.modmatI11(tid, showdate);
					}

					else if (a.equals("I12")) {
						book.modmatI12(tid, showdate);
					}

					else if (a.equals("J1")) {
						book.modmatJ1(tid, showdate);
					}

					else if (a.equals("J2")) {
						book.modmatJ2(tid, showdate);
					}

					else if (a.equals("J3")) {
						book.modmatJ3(tid, showdate);
					}

					else if (a.equals("J4")) {
						book.modmatJ4(tid, showdate);
					}

					else if (a.equals("J5")) {
						book.modmatJ5(tid, showdate);
					}

					else if (a.equals("J6")) {
						book.modmatJ6(tid, showdate);
					}

					else if (a.equals("J7")) {
						book.modmatJ7(tid, showdate);
					}

					else if (a.equals("J8")) {
						book.modmatJ8(tid, showdate);
					}

					else if (a.equals("J9")) {
						book.modmatJ9(tid, showdate);
					}

					else if (a.equals("J10")) {
						book.modmatJ10(tid, showdate);
					}

					else if (a.equals("J11")) {
						book.modmatJ11(tid, showdate);
					}

					else if (a.equals("J12")) {
						book.modmatJ12(tid, showdate);
					}
				}
			}

			else if (showtime.equals("SecondShow")) {
				for (String a : str) {
					System.out.println(a);

					if (a.equals("A1")) {
						book.modsecA1(tid, showdate);
					}

					else if (a.equals("A2")) {
						book.modsecA2(tid, showdate);
					}

					else if (a.equals("A3")) {
						book.modsecA3(tid, showdate);
					}

					else if (a.equals("A4")) {
						book.modsecA4(tid, showdate);
					}

					else if (a.equals("A5")) {
						book.modsecA5(tid, showdate);
					}

					else if (a.equals("A6")) {
						book.modsecA6(tid, showdate);
					}

					else if (a.equals("A7")) {
						book.modsecA7(tid, showdate);
					}

					else if (a.equals("A8")) {
						book.modsecA8(tid, showdate);
					}

					else if (a.equals("A9")) {
						book.modsecA9(tid, showdate);
					}

					else if (a.equals("A10")) {
						book.modsecA10(tid, showdate);
					}

					else if (a.equals("A11")) {
						book.modsecA11(tid, showdate);
					}

					else if (a.equals("A12")) {
						book.modsecA12(tid, showdate);
					}

					else if (a.equals("B1")) {
						book.modsecB1(tid, showdate);
					}

					else if (a.equals("B2")) {
						book.modsecB2(tid, showdate);
					}

					else if (a.equals("B3")) {
						book.modsecB3(tid, showdate);
					}

					else if (a.equals("B4")) {
						book.modsecB4(tid, showdate);
					}

					else if (a.equals("B5")) {
						book.modsecB5(tid, showdate);
					}

					else if (a.equals("B6")) {
						book.modsecB6(tid, showdate);
					}

					else if (a.equals("B7")) {
						book.modsecB7(tid, showdate);
					}

					else if (a.equals("B8")) {
						book.modsecB8(tid, showdate);
					}

					else if (a.equals("B9")) {
						book.modsecB9(tid, showdate);
					}

					else if (a.equals("B10")) {
						book.modsecB10(tid, showdate);
					}

					else if (a.equals("B11")) {
						book.modsecB11(tid, showdate);
					}

					else if (a.equals("B12")) {
						book.modsecB12(tid, showdate);
					}

					else if (a.equals("C1")) {
						book.modsecC1(tid, showdate);
					}

					else if (a.equals("C2")) {
						book.modsecC2(tid, showdate);
					}

					else if (a.equals("C3")) {
						book.modsecC3(tid, showdate);
					}

					else if (a.equals("C4")) {
						book.modsecC4(tid, showdate);
					}

					else if (a.equals("C5")) {
						book.modsecC5(tid, showdate);
					}

					else if (a.equals("C6")) {
						book.modsecC6(tid, showdate);
					}

					else if (a.equals("C7")) {
						book.modsecC7(tid, showdate);
					}

					else if (a.equals("C8")) {
						book.modsecC8(tid, showdate);
					}

					else if (a.equals("C9")) {
						book.modsecC9(tid, showdate);
					}

					else if (a.equals("C10")) {
						book.modsecC10(tid, showdate);
					}

					else if (a.equals("C11")) {
						book.modsecC11(tid, showdate);
					}

					else if (a.equals("C12")) {
						book.modsecC12(tid, showdate);
					}

					else if (a.equals("D1")) {
						book.modsecD1(tid, showdate);
					}

					else if (a.equals("D2")) {
						book.modsecD2(tid, showdate);
					}

					else if (a.equals("D3")) {
						book.modsecD3(tid, showdate);
					}

					else if (a.equals("D4")) {
						book.modsecD4(tid, showdate);
					}

					else if (a.equals("D5")) {
						book.modsecD5(tid, showdate);
					}

					else if (a.equals("D6")) {
						book.modsecD6(tid, showdate);
					}

					else if (a.equals("D7")) {
						book.modsecD7(tid, showdate);
					}

					else if (a.equals("D8")) {
						book.modsecD8(tid, showdate);
					}

					else if (a.equals("D9")) {
						book.modsecD9(tid, showdate);
					}

					else if (a.equals("D10")) {
						book.modsecD10(tid, showdate);
					}

					else if (a.equals("D11")) {
						book.modsecD11(tid, showdate);
					}

					else if (a.equals("D12")) {
						book.modsecD12(tid, showdate);
					}

					else if (a.equals("E1")) {
						book.modsecE1(tid, showdate);
					}

					else if (a.equals("E2")) {
						book.modsecE2(tid, showdate);
					}

					else if (a.equals("E3")) {
						book.modsecE3(tid, showdate);
					}

					else if (a.equals("E4")) {
						book.modsecE4(tid, showdate);
					}

					else if (a.equals("E5")) {
						book.modsecE5(tid, showdate);
					}

					else if (a.equals("E6")) {
						book.modsecE6(tid, showdate);
					}

					else if (a.equals("E7")) {
						book.modsecE7(tid, showdate);
					}

					else if (a.equals("E8")) {
						book.modsecE8(tid, showdate);
					}

					else if (a.equals("E9")) {
						book.modsecE9(tid, showdate);
					}

					else if (a.equals("E10")) {
						book.modsecE10(tid, showdate);
					}

					else if (a.equals("E11")) {
						book.modsecE11(tid, showdate);
					}

					else if (a.equals("E12")) {
						book.modsecE12(tid, showdate);
					}

					else if (a.equals("F1")) {
						book.modsecF1(tid, showdate);
					}

					else if (a.equals("F2")) {
						book.modsecF2(tid, showdate);
					}

					else if (a.equals("F3")) {
						book.modsecF3(tid, showdate);
					}

					else if (a.equals("F4")) {
						book.modsecF4(tid, showdate);
					}

					else if (a.equals("F5")) {
						book.modsecF5(tid, showdate);
					}

					else if (a.equals("F6")) {
						book.modsecF6(tid, showdate);
					}

					else if (a.equals("F7")) {
						book.modsecF7(tid, showdate);
					}

					else if (a.equals("F8")) {
						book.modsecF8(tid, showdate);
					}

					else if (a.equals("F9")) {
						book.modsecF9(tid, showdate);
					}

					else if (a.equals("F10")) {
						book.modsecF10(tid, showdate);
					}

					else if (a.equals("F11")) {
						book.modsecF11(tid, showdate);
					}

					else if (a.equals("F12")) {
						book.modsecF12(tid, showdate);
					}

					else if (a.equals("G1")) {
						book.modsecG1(tid, showdate);
					}

					else if (a.equals("G2")) {
						book.modsecG2(tid, showdate);
					}

					else if (a.equals("G3")) {
						book.modsecG3(tid, showdate);
					}

					else if (a.equals("G4")) {
						book.modsecG4(tid, showdate);
					}

					else if (a.equals("G5")) {
						book.modsecG5(tid, showdate);
					}

					else if (a.equals("G6")) {
						book.modsecG6(tid, showdate);
					}

					else if (a.equals("G7")) {
						book.modsecG7(tid, showdate);
					}

					else if (a.equals("G8")) {
						book.modsecG8(tid, showdate);
					}

					else if (a.equals("G9")) {
						book.modsecG9(tid, showdate);
					}

					else if (a.equals("G10")) {
						book.modsecG10(tid, showdate);
					}

					else if (a.equals("G11")) {
						book.modsecG11(tid, showdate);
					}

					else if (a.equals("G12")) {
						book.modsecG12(tid, showdate);
					}

					else if (a.equals("H1")) {
						book.modsecH1(tid, showdate);
					}

					else if (a.equals("H2")) {
						book.modsecH2(tid, showdate);
					}

					else if (a.equals("H3")) {
						book.modsecH3(tid, showdate);
					}

					else if (a.equals("H4")) {
						book.modsecH4(tid, showdate);
					}

					else if (a.equals("H5")) {
						book.modsecH5(tid, showdate);
					}

					else if (a.equals("H6")) {
						book.modsecH6(tid, showdate);
					}

					else if (a.equals("H7")) {
						book.modsecH7(tid, showdate);
					}

					else if (a.equals("H8")) {
						book.modsecH8(tid, showdate);
					}

					else if (a.equals("H9")) {
						book.modsecH9(tid, showdate);
					}

					else if (a.equals("H10")) {
						book.modsecH10(tid, showdate);
					}

					else if (a.equals("H11")) {
						book.modsecH11(tid, showdate);
					}

					else if (a.equals("H12")) {
						book.modsecH12(tid, showdate);
					}

					else if (a.equals("I1")) {
						book.modsecI1(tid, showdate);
					}

					else if (a.equals("I2")) {
						book.modsecI2(tid, showdate);
					}

					else if (a.equals("I3")) {
						book.modsecI3(tid, showdate);
					}

					else if (a.equals("I4")) {
						book.modsecI4(tid, showdate);
					}

					else if (a.equals("I5")) {
						book.modsecI5(tid, showdate);
					}

					else if (a.equals("I6")) {
						book.modsecI6(tid, showdate);
					}

					else if (a.equals("I7")) {
						book.modsecI7(tid, showdate);
					}

					else if (a.equals("I8")) {
						book.modsecI8(tid, showdate);
					}

					else if (a.equals("I9")) {
						book.modsecI9(tid, showdate);
					}

					else if (a.equals("I10")) {
						book.modsecI10(tid, showdate);
					}

					else if (a.equals("I11")) {
						book.modsecI11(tid, showdate);
					}

					else if (a.equals("I12")) {
						book.modsecI12(tid, showdate);
					}

					else if (a.equals("J1")) {
						book.modsecJ1(tid, showdate);
					}

					else if (a.equals("J2")) {
						book.modsecJ2(tid, showdate);
					}

					else if (a.equals("J3")) {
						book.modsecJ3(tid, showdate);
					}

					else if (a.equals("J4")) {
						book.modsecJ4(tid, showdate);
					}

					else if (a.equals("J5")) {
						book.modsecJ5(tid, showdate);
					}

					else if (a.equals("J6")) {
						book.modsecJ6(tid, showdate);
					}

					else if (a.equals("J7")) {
						book.modsecJ7(tid, showdate);
					}

					else if (a.equals("J8")) {
						book.modsecJ8(tid, showdate);
					}

					else if (a.equals("J9")) {
						book.modsecJ9(tid, showdate);
					}

					else if (a.equals("J10")) {
						book.modsecJ10(tid, showdate);
					}

					else if (a.equals("J11")) {
						book.modsecJ11(tid, showdate);
					}

					else if (a.equals("J12")) {
						book.modsecJ12(tid, showdate);
					}
				}
			}

			book.deleteById(cid);
			superlog.info(cid + " " + env.getProperty("bds"));
			return env.getProperty("bds");

		} else {
			superlog.error(env.getProperty("ibi"));
			throw new NotFoundException(env.getProperty("ibi"));
		}
	}

}
