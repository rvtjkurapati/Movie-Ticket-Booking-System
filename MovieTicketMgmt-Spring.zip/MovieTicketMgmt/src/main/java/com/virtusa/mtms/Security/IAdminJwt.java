package com.virtusa.mtms.Security;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.mtms.Entity.Admin;

public interface IAdminJwt extends JpaRepository<Admin, Integer>{

	Admin findByUname(String uname);
	
}
