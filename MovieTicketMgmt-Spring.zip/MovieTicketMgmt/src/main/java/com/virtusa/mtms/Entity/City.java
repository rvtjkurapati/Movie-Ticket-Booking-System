package com.virtusa.mtms.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity(name="city")
@AllArgsConstructor
public class City {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int cid;
	@Pattern(regexp = "^[A-Z].*$",message="Name Should Start with Capital letter")
    String cname;
   
}
