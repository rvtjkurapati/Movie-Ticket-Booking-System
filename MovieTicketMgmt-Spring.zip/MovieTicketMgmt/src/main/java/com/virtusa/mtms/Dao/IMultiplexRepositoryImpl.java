package com.virtusa.mtms.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Location;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Multiplex;
@Transactional
@Repository
public interface IMultiplexRepositoryImpl extends JpaRepository<Multiplex, Integer> {
	
	@Query("select c from multiplex c where c.mxname like ?1%")
	public List<Multiplex> findByName(String name);
	
	@Query("select c from multiplex c where c.mxname like ?1% and c.lid!=?2")
	public List<Multiplex> findByMxName(String name,Location lid);
	
	@Query("select c from multiplex c where c.lid=?1")
	public List<Multiplex> getByLid(Location lid);

	@Query("select cid from location  where lid =?1")
	public City CidByLid(Location lid);
	
	@Query("select c from multiplex c where c.cid = ?1")
	public List<Multiplex> findByCId(City cid);
	
	@Query("select mornid from morningseats where mxid=?1")
	public List<Integer> getMornId(Multiplex mxid);
	
	@Query("select matid from matineeseats  where mxid=?1")
	public List<Integer> getMatId(Multiplex mxid);
	
	@Query("select secid from secondshowseats where  mxid=?1")
	public List<Integer> getSecId(Multiplex mxid);
	
	@Query("select bid from booking  where mxid=?1")
	public List<Integer> getBId(Multiplex mxid);
	
	@Query("select tid from theatre where  mxid=?1")
	public List<Integer> getTId(Multiplex mxid);
	

}
