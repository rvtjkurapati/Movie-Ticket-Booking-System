package com.virtusa.mtms.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.mtms.Entity.Matineeseats;

public interface IMatineeSeatsRepositoryImpl extends JpaRepository<Matineeseats, Integer> {

}
