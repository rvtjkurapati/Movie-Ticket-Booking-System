package com.virtusa.mtms.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.mtms.Dao.IMovieRepositoryImpl;
import com.virtusa.mtms.Entity.Availability;
import com.virtusa.mtms.Entity.City;
import com.virtusa.mtms.Entity.Customer;
import com.virtusa.mtms.Entity.Location;
import com.virtusa.mtms.Entity.Movie;
import com.virtusa.mtms.Entity.Theatre;
import com.virtusa.mtms.Service.IGuestServiceImpl;

@RestController
@RequestMapping("/guest")
public class GuestController {
	
	@Autowired
	IGuestServiceImpl guestRepo;
	
	
	@GetMapping("/showcity")
	public List<City> showCity()
	{
		return guestRepo.showCity();
	}
	
	@GetMapping("/register")
	public String register(@RequestBody Customer c)
	{
		return guestRepo.register(c);
	}
	@GetMapping("/Welcome")
	public String welcome()
	{
		return guestRepo.welcome();
	}
	
	
	@GetMapping("/showmovie")
	public List<Movie> showMovies()
	{
		return guestRepo.showMovie();
	}
	
	
	@GetMapping("/searchmoviebyName/{id}")
	public List<Movie> searchmoviebyName(@PathVariable("id") String id)
	{
		return guestRepo.searchMovieByName(id);
	}
	
	@GetMapping("/searchmoviebyCat/{id}")
	public List<Movie> searchmoviebyCat(@PathVariable("id") String id)
	{
		return guestRepo.searchMovieByCat(id);
	}
	
	@GetMapping("/searchmoviebyGen/{id}")
	public List<Movie> searchmoviebyGen(@PathVariable("id") String id)
	{
		return guestRepo.searchMovieByGen(id);
	}
	
	@GetMapping("/searchmoviebyLocation/{id}")
	public List<Movie> searchmoviebyLoc(@PathVariable("id") String id)
	{
		return guestRepo.searchMovieByLoc(id);
	}
	
	
	@GetMapping("/searchTheatrebyMid/{id}")
	public List<Theatre> searchtheatrebyMid(@PathVariable("id") Movie id)
	{
		return guestRepo.searchTheatreByMvid(id);
	}
	
	@GetMapping("/checkavail")
	public String checkAvail(@RequestBody Availability c)
	{
		return guestRepo.availability(c);
	}

}
