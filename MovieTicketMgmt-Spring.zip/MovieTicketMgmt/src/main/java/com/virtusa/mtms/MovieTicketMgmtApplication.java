package com.virtusa.mtms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieTicketMgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieTicketMgmtApplication.class, args);
	}

}