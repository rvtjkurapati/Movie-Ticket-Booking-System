var slides = document.querySelector('.slider-items').children;
var nextSlide = document.querySelector(".right-slide");
var prevSlide = document.querySelector(".left-slide");
var totalSlides = slides.length;
var index = 0;

nextSlide.onclick = function() {
	next("next");
}
prevSlide.onclick = function() {
	next("prev");
}

function next(direction) {

	if (direction == "next") {
		index++;
		if (index == totalSlides) {
			index = 0;
		}
	}
	else {
		if (index == 0) {
			index = totalSlides - 1;
		}
		else {
			index--;
		}
	}

	for (i = 0; i < slides.length; i++) {
		slides[i].classList.remove("active");
	}
	slides[index].classList.add("active");

}


const arrows = document.querySelectorAll(".arrow");
const movieLists = document.querySelectorAll(".movie-list");

arrows.forEach((arrow, i) => {
	const itemNumber = movieLists[i].querySelectorAll("img").length;
	let clickCounter = 0;
	arrow.addEventListener("click", () => {
		const ratio = Math.floor(window.innerWidth / 500);
		clickCounter++;
		if (itemNumber - (4 + clickCounter) + (4 - ratio) >= 0) {
			movieLists[i].style.transform = `translateX(${movieLists[i].computedStyleMap().get("transform")[0].x.value - 530
				}px)`;
		} else {
			movieLists[i].style.transform = "translateX(0)";
			clickCounter = 0;
		}
	});

	console.log(Math.floor(window.innerWidth / 500));
});
