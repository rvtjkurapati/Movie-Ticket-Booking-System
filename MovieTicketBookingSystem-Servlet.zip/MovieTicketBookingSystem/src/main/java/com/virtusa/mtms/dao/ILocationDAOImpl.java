package com.virtusa.mtms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.virtusa.mtms.dto.Location;
import com.virtusa.mtms.util.DbConnection;

public class ILocationDAOImpl {

	public boolean AddLocation(Location l) {

		try {
			Connection con = DbConnection.getConnection();

			String cmd3 = "select * from city where  cityId=?";
			PreparedStatement ps3 = con.prepareStatement(cmd3);
			ps3.setInt(1, l.getCid());
			ResultSet rs3 = ps3.executeQuery();

			String cmd1 = "select * from location where location=? and cityId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1, l.getLname());
			ps1.setInt(2, l.getCid());
			ResultSet rs = ps1.executeQuery();

			if (!rs.next() && rs3.next()) {
				String cmd2 = "insert into location (cityId,location) values(?,?)";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, l.getCid());
				ps2.setString(2, l.getLname());
				ps2.executeUpdate();
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return false;
	}

	public boolean DelLocation(int s) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from location where locId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, s);
			ResultSet rs = ps1.executeQuery();

			if (rs.next()) {

				String cmd6 = "select multiplexId from multiplex where locId=?";
				PreparedStatement ps6 = con.prepareStatement(cmd6);
				ps6.setInt(1, s);
				ResultSet rs2 = ps6.executeQuery();
				while (rs2.next()) {
					int mid = rs2.getInt(1);

					int id = 0;
					String cmd10 = "select movieId from movie where multiplexId=?";
					PreparedStatement ps10 = con.prepareStatement(cmd10);
					ps10.setInt(1, mid);
					ResultSet rs10 = ps10.executeQuery();
					while (rs10.next()) {
						id = rs10.getInt(1);
					}

					String cmd11 = "delete from theatre where movieId=?";
					PreparedStatement ps11 = con.prepareStatement(cmd11);
					ps11.setInt(1, id);
					ps11.executeUpdate();

					String cmd7 = "delete from movie where multiplexId=?";
					PreparedStatement ps7 = con.prepareStatement(cmd7);
					ps7.setInt(1, mid);
					ps7.executeUpdate();

					String cmd8 = "delete from booking where multiplexId=?";
					PreparedStatement ps8 = con.prepareStatement(cmd8);
					ps8.setInt(1, mid);
					ps8.executeUpdate();

					String cmd9 = "delete from morningseats where multiplexId=?";
					PreparedStatement ps9 = con.prepareStatement(cmd9);
					ps9.setInt(1, mid);
					ps9.executeUpdate();

					String cmd12 = "delete from matineeseats where multiplexId=?";
					PreparedStatement ps12 = con.prepareStatement(cmd12);
					ps12.setInt(1, mid);
					ps12.executeUpdate();

					String cmd13 = "delete from secondshowseats where multiplexId=?";
					PreparedStatement ps13 = con.prepareStatement(cmd13);
					ps13.setInt(1, mid);
					ps13.executeUpdate();

				}

				String cmd4 = "delete from multiplex where locId=?";
				PreparedStatement ps4 = con.prepareStatement(cmd4);
				ps4.setInt(1, s);
				ps4.executeUpdate();

				String cmd2 = "delete from location where locId=?";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, s);
				ps2.executeUpdate();

				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public ArrayList<Location> getLocation() {
		ArrayList<Location> log = new ArrayList<Location>();
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from location order by location asc";
			PreparedStatement ps = con.prepareStatement(cmd);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				int lid = rs.getInt(2);
				String came = rs.getString(3);
				Location l = new Location(cid, lid, came);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			} else {
				return null;
			}
		}

		catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public boolean ModifyLocation(int lid, int cid, String name) {

		try {

			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from location where locId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, lid);
			ResultSet rs = ps1.executeQuery();

			String cmd15 = "select * from city where  cityId=?";
			PreparedStatement ps15 = con.prepareStatement(cmd15);
			ps15.setInt(1, cid);
			ResultSet rs15 = ps15.executeQuery();

			String cmd17 = "select * from location where location=? and locId!=?";
			PreparedStatement ps17 = con.prepareStatement(cmd17);
			ps17.setString(1, name);
			ps17.setInt(2, lid);
			ResultSet rs17 = ps17.executeQuery();

			if (rs.next() && rs15.next() && !rs17.next()) {
				String cmd = "update  location  set location=?, cityId=? where locId=?";
				PreparedStatement ps = con.prepareStatement(cmd);
				ps.setString(1, name);
				ps.setInt(2, cid);
				ps.setInt(3, lid);
				ps.executeUpdate();

			}

			else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}

		return false;
	}

	public ArrayList<Location> SearchLocation(String str) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Location> log = new ArrayList<Location>();
			String cmd = "select * from  location  where location like ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, str + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				int lid = rs.getInt(2);
				String cname = rs.getString(3);
				Location l = new Location(cid, lid, cname);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Location> SearchLocationByCid(int ctid) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Location> log = new ArrayList<Location>();
			String cmd = "select * from  location  where cityId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, ctid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				int lid = rs.getInt(2);
				String cname = rs.getString(3);
				Location l = new Location(cid, lid, cname);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Location> SearchLocationByLid(int id) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Location> log = new ArrayList<Location>();
			String cmd = "select * from  location  where locId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				int lid = rs.getInt(2);
				String cname = rs.getString(3);
				Location l = new Location(cid, lid, cname);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public int getLid(String id) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select locId from  location  where location=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				return cid;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return 0;
	}

	public int getCid(String id) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select cityId from  location  where location=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			System.out.println(id);
			while (rs.next()) {
				System.out.println("lopala");
				int cid = rs.getInt(1);
				return cid;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return 0;
	}

	public String getLname(int id) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select location from  location  where locId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			System.out.println(id);
			while (rs.next()) {
				System.out.println("lopala");
				String cid = rs.getString(1);
				return cid;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

}
