package com.virtusa.mtms.dto;

public class Multiplex {

	int cid;
	int lid;
	String mname;
	int mid;
	String add;

	public Multiplex() {
		super();
	}

	public Multiplex(int cid, int lid, String mname, int mid, String add) {
		super();
		this.cid = cid;
		this.lid = lid;
		this.mname = mname;
		this.mid = mid;
		this.add = add;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	@Override
	public String toString() {
		return "Multiplex [cid=" + cid + ", lid=" + lid + ", mname=" + mname + ", mid=" + mid + ", add=" + add + "]";
	}

}
