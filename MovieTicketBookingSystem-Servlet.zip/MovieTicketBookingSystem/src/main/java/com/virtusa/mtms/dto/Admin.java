package com.virtusa.mtms.dto;

public class Admin {

	int id;
	String userName;
	String passWord;
	int bal;

	public Admin() {
		super();
	}

	public Admin(int id, String userName, String passWord, int bal) {
		super();
		this.id = id;
		this.userName = userName;
		this.passWord = passWord;
		this.bal = bal;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public int getBal() {
		return bal;
	}

	public void setBal(int bal) {
		this.bal = bal;
	}

	@Override
	public String toString() {
		String aid = String.valueOf(id);
		while (aid.length() < 15) {
			aid += " ";
		}
		while (userName.length() < 15) {
			userName += " ";
		}
		while (passWord.length() < 15) {
			passWord += " ";
		}

		return "           Id = " + aid + "    Username = " + userName + "    Password = " + passWord;
	}

}
