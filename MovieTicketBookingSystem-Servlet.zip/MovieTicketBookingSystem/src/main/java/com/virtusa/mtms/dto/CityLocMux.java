package com.virtusa.mtms.dto;

public class CityLocMux {

	String cname;
	String lname;
	String mname;

	public CityLocMux() {
		super();
	}

	public CityLocMux(String cname, String lname, String mname) {
		super();
		this.cname = cname;
		this.lname = lname;
		this.mname = mname;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	@Override
	public String toString() {
		return "CityLocMux [cname=" + cname + ", lname=" + lname + ", mname=" + mname + "]";
	}

}
