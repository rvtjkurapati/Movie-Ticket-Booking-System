package com.virtusa.mtms.dto;

public class Booking {

	int bid;
	int cid;
	int tid;
	int mxid;
	int mid;
	String showd;
	String showt;
	String seats;
	String phone;
	int screen;

	public Booking() {
		super();
	}

	public Booking(int bid, int cid, int tid, int mxid, int mid, String showd, String showt, String seats, String phone,
			int screen) {
		super();
		this.bid = bid;
		this.cid = cid;
		this.tid = tid;
		this.mxid = mxid;
		this.mid = mid;
		this.showd = showd;
		this.showt = showt;
		this.seats = seats;
		this.phone = phone;
		this.screen = screen;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public int getMxid() {
		return mxid;
	}

	public void setMxid(int mxid) {
		this.mxid = mxid;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getShowd() {
		return showd;
	}

	public void setShowd(String showd) {
		this.showd = showd;
	}

	public String getShowt() {
		return showt;
	}

	public void setShowt(String showt) {
		this.showt = showt;
	}

	public String getSeats() {
		return seats;
	}

	public void setSeats(String seats) {
		this.seats = seats;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getScreen() {
		return screen;
	}

	public void setScreen(int screen) {
		this.screen = screen;
	}

	@Override
	public String toString() {
		return "Booking [bid=" + bid + ", cid=" + cid + ", tid=" + tid + ", mxid=" + mxid + ", mid=" + mid + ", showd="
				+ showd + ", showt=" + showt + ", seats=" + seats + ", phone=" + phone + ", screen=" + screen + "]";
	}

}
