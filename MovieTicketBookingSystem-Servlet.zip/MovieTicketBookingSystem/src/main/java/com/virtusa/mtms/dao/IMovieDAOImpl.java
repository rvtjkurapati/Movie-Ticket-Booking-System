package com.virtusa.mtms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import com.virtusa.mtms.dto.Movie;
import com.virtusa.mtms.util.DbConnection;

public class IMovieDAOImpl {

	public boolean AddMovie(Movie m) {
		try {
			Connection con = DbConnection.getConnection();

			String cmd1 = "select * from movie  where moviename=? and lang=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1, m.getMname());
			ps1.setString(2, m.getLang());
			ResultSet rs = ps1.executeQuery();

			if (!rs.next()) {
				String cmd2 = "insert into movie (moviename,category,lang,duration,genre,censorRate,director,cast,synopsis,image,relDate) values(?,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setString(1, m.getMname());
				ps2.setString(2, m.getCategory());
				ps2.setString(3, m.getLang());
				ps2.setString(4, m.getDuration());
				ps2.setString(5, m.getGenre());
				ps2.setString(6, m.getCensor());
				ps2.setString(7, m.getDir());
				ps2.setString(8, m.getCast());
				ps2.setString(9, m.getSyn());
				ps2.setString(10, m.getImage());

				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date date1 = sdf1.parse(m.getRelDate());
				java.sql.Date sqlDate = new java.sql.Date(date1.getTime());
				ps2.setDate(11, sqlDate);
				ps2.executeUpdate();

				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return false;
	}

	public boolean DelMovie(int m) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from movie where movieId=?;";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, m);
			ResultSet rs = ps1.executeQuery();
			if (rs.next()) {

				String cmd3 = "delete from booking where movieId=?;";
				PreparedStatement ps3 = con.prepareStatement(cmd3);
				ps3.setInt(1, m);
				ps3.executeUpdate();

				String cmd4 = "delete from morningseats where movieId=?;";
				PreparedStatement ps4 = con.prepareStatement(cmd4);
				ps4.setInt(1, m);
				ps4.executeUpdate();

				String cmd5 = "delete from matineeseats where movieId=?;";
				PreparedStatement ps5 = con.prepareStatement(cmd5);
				ps5.setInt(1, m);
				ps5.executeUpdate();

				String cmd6 = "delete from secondshowseats where movieId=?;";
				PreparedStatement ps6 = con.prepareStatement(cmd6);
				ps6.setInt(1, m);
				ps6.executeUpdate();

				String cmd7 = "delete from theatre where movieId=?;";
				PreparedStatement ps7 = con.prepareStatement(cmd7);
				ps7.setInt(1, m);
				ps7.executeUpdate();

				String cmd2 = "delete from movie where movieId=?;";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, m);
				ps2.executeUpdate();

				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public String SuggestMovie() {
		try {
			Connection con = DbConnection.getConnection();
			int id = 0;
			String name = "";
			String cmd1 = "SELECT movieId,COUNT(movieId) AS `value`  FROM booking  GROUP BY movieId ORDER BY COUNT(*) DESC LIMIT 1;";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ResultSet rs = ps1.executeQuery();
			while (rs.next()) {
				id = rs.getInt(1);
			}

			String cmd2 = "select moviename from movie where movieId=?;";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, id);
			ResultSet rs2 = ps2.executeQuery();
			while (rs2.next()) {
				name = rs2.getString(1);
			}

			if (name.equals("")) {
				return null;
			}

			return "Movie: " + name;

		} catch (Exception e) {
			System.out.println("sugg mv");
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Movie> getMovies() {

		try {
			ArrayList<Movie> log = new ArrayList<Movie>();
			Connection con = DbConnection.getConnection();
			String cmd = "select * from movie";
			PreparedStatement ps = con.prepareStatement(cmd);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				String mname = rs.getString(2);
				String cat = rs.getString(3);
				String lang = rs.getString(4);
				String dur = rs.getString(5);
				String gen = rs.getString(6);
				String cen = rs.getString(7);

				String dir = rs.getString(8);
				String cast = rs.getString(9);
				String syn = rs.getString(10);

				String img = rs.getString(11);
				String relDate = rs.getString(12);

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				relDate = LocalDate.parse(relDate, formatter).format(formatter2);

				Movie l = new Movie(id, mname, cat, lang, dur, gen, cen, img, dir, cast, syn, relDate);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println("get mv");
			e.getStackTrace();
		}
		return null;
	}

	public boolean ModifyMovie(Movie m) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from movie where movieId=?;";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, m.getMid());
			ResultSet rs1 = ps1.executeQuery();

			String cmd20 = "select * from movie  where moviename=? and lang=? and movieId!=?";
			PreparedStatement ps20 = con.prepareStatement(cmd20);
			ps20.setString(1, m.getMname());
			ps20.setString(2, m.getLang());
			ps20.setInt(3, m.getMid());
			ResultSet rs20 = ps20.executeQuery();

			if (!rs20.next() && rs1.next()) {

				String cmd = "update  movie  set moviename=?,category=?,lang=?,duration=?,genre=?,censorRate=?,image=?,director=?,cast=?,synopsis=?,relDate=? where movieId=?;";
				PreparedStatement ps = con.prepareStatement(cmd);
				ps.setString(1, m.getMname());
				ps.setString(2, m.getCategory());
				ps.setString(3, m.getLang());
				ps.setString(4, m.getDuration());
				ps.setString(5, m.getGenre());
				ps.setString(6, m.getCensor());
				ps.setString(7, m.getImage());
				ps.setString(8, m.getDir());
				ps.setString(9, m.getCast());
				ps.setString(10, m.getSyn());

				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date date1 = sdf1.parse(m.getRelDate());
				java.sql.Date sqlDate = new java.sql.Date(date1.getTime());
				ps.setDate(11, sqlDate);
				ps.setInt(12, m.getMid());
				ps.executeUpdate();

				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e + "haha");
			e.getStackTrace();
		}

		return false;
	}

	public ArrayList<Movie> SearchMovie(String name) {
		ArrayList<Movie> log = new ArrayList<Movie>();
		try {
			Connection con = DbConnection.getConnection();
			String cmd = " select * from movie where moviename like ?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, name + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				String mname = rs.getString(2);
				String cat = rs.getString(3);
				String lang = rs.getString(4);
				String dur = rs.getString(5);
				String gen = rs.getString(6);
				String cen = rs.getString(7);

				String dir = rs.getString(8);
				String cast = rs.getString(9);
				String syn = rs.getString(10);

				String img = rs.getString(11);
				String relDate = rs.getString(12);

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				relDate = LocalDate.parse(relDate, formatter).format(formatter2);

				Movie l = new Movie(id, mname, cat, lang, dur, gen, cen, img, dir, cast, syn, relDate);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			} else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}

		return null;
	}

	public ArrayList<Movie> SearchMovieByCat(String name) {
		ArrayList<Movie> log = new ArrayList<Movie>();
		try {
			Connection con = DbConnection.getConnection();
			String cmd = " select * from movie where category = ?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				String mname = rs.getString(2);
				String cat = rs.getString(3);
				String lang = rs.getString(4);
				String dur = rs.getString(5);
				String gen = rs.getString(6);
				String cen = rs.getString(7);

				String dir = rs.getString(8);
				String cast = rs.getString(9);
				String syn = rs.getString(10);
				String img = rs.getString(11);
				String relDate = rs.getString(12);

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				relDate = LocalDate.parse(relDate, formatter).format(formatter2);

				Movie l = new Movie(id, mname, cat, lang, dur, gen, cen, img, dir, cast, syn, relDate);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			} else {
				return null;
			}

		}

		catch (Exception e) {
			e.getStackTrace();
		}

		return null;
	}

	public ArrayList<Movie> SearchMovieByLang(String name) {
		ArrayList<Movie> log = new ArrayList<Movie>();
		try {
			Connection con = DbConnection.getConnection();
			String cmd = " select * from movie where lang like ?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, name + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				String mname = rs.getString(2);
				String cat = rs.getString(3);
				String lang = rs.getString(4);
				String dur = rs.getString(5);
				String gen = rs.getString(6);
				String cen = rs.getString(7);

				String dir = rs.getString(8);
				String cast = rs.getString(9);
				String syn = rs.getString(10);

				String img = rs.getString(11);
				String relDate = rs.getString(12);

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				relDate = LocalDate.parse(relDate, formatter).format(formatter2);

				Movie l = new Movie(id, mname, cat, lang, dur, gen, cen, img, dir, cast, syn, relDate);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			} else {
				return null;
			}

		}

		catch (Exception e) {
			e.getStackTrace();
		}

		return null;
	}

	public ArrayList<Movie> SearchMovieByGen(String name) {
		ArrayList<Movie> log = new ArrayList<Movie>();
		try {
			Connection con = DbConnection.getConnection();
			String cmd = " select * from movie where genre like ?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, name + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				String mname = rs.getString(2);
				String cat = rs.getString(3);
				String lang = rs.getString(4);
				String dur = rs.getString(5);
				String gen = rs.getString(6);
				String cen = rs.getString(7);

				String dir = rs.getString(8);
				String cast = rs.getString(9);
				String syn = rs.getString(10);

				String img = rs.getString(11);
				String relDate = rs.getString(12);

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				relDate = LocalDate.parse(relDate, formatter).format(formatter2);

				Movie l = new Movie(id, mname, cat, lang, dur, gen, cen, img, dir, cast, syn, relDate);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			} else {
				return null;
			}

		}

		catch (Exception e) {
			e.getStackTrace();
		}

		return null;
	}

	public ArrayList<Movie> SearchMovieByMid(int name) {
		ArrayList<Movie> log = new ArrayList<Movie>();
		try {
			Connection con = DbConnection.getConnection();
			String cmd = " select * from movie where movieId = ?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, name);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				String mname = rs.getString(2);
				String cat = rs.getString(3);
				String lang = rs.getString(4);
				String dur = rs.getString(5);
				String gen = rs.getString(6);
				String cen = rs.getString(7);

				String dir = rs.getString(8);
				String cast = rs.getString(9);
				String syn = rs.getString(10);

				String img = rs.getString(11);
				String relDate = rs.getString(12);

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				relDate = LocalDate.parse(relDate, formatter).format(formatter2);

				Movie l = new Movie(id, mname, cat, lang, dur, gen, cen, img, dir, cast, syn, relDate);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			} else {
				return null;
			}

		}

		catch (Exception e) {
			e.getStackTrace();
		}

		return null;
	}

	public boolean ValMovieId(int d) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from  movie  where movieId=?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, d);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {

				return true;
			}

			else {

				return false;
			}

		}

		catch (Exception e) {
			e.getStackTrace();
		}

		return false;
	}

	public int getMid(String name) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd = " select movieId from movie where moviename = ?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				return id;

			}

		}

		catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}

		return 0;
	}
}
