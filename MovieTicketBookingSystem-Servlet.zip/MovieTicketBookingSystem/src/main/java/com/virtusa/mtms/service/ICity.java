package com.virtusa.mtms.service;

import java.util.ArrayList;

import com.virtusa.mtms.dto.City;

public interface ICity {

	public boolean AddCity(String l);

	public boolean DelCity(int s);

	public ArrayList<City> getCity();

	public boolean ModifyCity(int l, String name);

	public ArrayList<City> SearchCity(String str);

}
