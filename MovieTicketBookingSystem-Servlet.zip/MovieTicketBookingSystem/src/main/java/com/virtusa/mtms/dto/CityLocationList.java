package com.virtusa.mtms.dto;

public class CityLocationList {

	String cname;
	String Lname;

	public CityLocationList() {
		super();
	}

	public CityLocationList(String cname, String lname) {
		super();
		this.cname = cname;
		Lname = lname;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getLname() {
		return Lname;
	}

	public void setLname(String lname) {
		Lname = lname;
	}

	@Override
	public String toString() {
		return "CityLocationList [cname=" + cname + ", Lname=" + Lname + "]";
	}

}
