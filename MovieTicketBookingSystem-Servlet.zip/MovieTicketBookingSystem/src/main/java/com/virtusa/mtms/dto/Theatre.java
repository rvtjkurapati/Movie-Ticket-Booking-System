package com.virtusa.mtms.dto;

public class Theatre {

	int tid;
	int mid;
	int mplexid;
	int cid;
	String show1;
	String show2;
	String show3;
	String sdate;
	String edate;
	int screen;
	int price;

	public Theatre() {
		super();
	}

	public Theatre(int tid, int mid, int mplexid, int cid, String show1, String show2, String show3, String sdate,
			String edate, int screen, int price) {
		super();
		this.tid = tid;
		this.mid = mid;
		this.mplexid = mplexid;
		this.cid = cid;
		this.show1 = show1;
		this.show2 = show2;
		this.show3 = show3;
		this.sdate = sdate;
		this.edate = edate;
		this.screen = screen;
		this.price = price;
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getMplexid() {
		return mplexid;
	}

	public void setMplexid(int mplexid) {
		this.mplexid = mplexid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getShow1() {
		return show1;
	}

	public void setShow1(String show1) {
		this.show1 = show1;
	}

	public String getShow2() {
		return show2;
	}

	public void setShow2(String show2) {
		this.show2 = show2;
	}

	public String getShow3() {
		return show3;
	}

	public void setShow3(String show3) {
		this.show3 = show3;
	}

	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		this.sdate = sdate;
	}

	public String getEdate() {
		return edate;
	}

	public void setEdate(String edate) {
		this.edate = edate;
	}

	public int getScreen() {
		return screen;
	}

	public void setScreen(int screen) {
		this.screen = screen;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Theatre [tid=" + tid + ", mid=" + mid + ", mplexid=" + mplexid + ", cid=" + cid + ", show1=" + show1
				+ ", show2=" + show2 + ", show3=" + show3 + ", sdate=" + sdate + ", edate=" + edate + ", screen="
				+ screen + ", price=" + price + "]";
	}

}
