package com.virtusa.mtms.service;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.mtms.dto.Multiplex;

public interface IMultiplex {
	
	public boolean AddMultiplex(Multiplex l);
	public boolean DelMultiplex(int s);
	public ArrayList<Multiplex> getMultiplex();
	public boolean ModifyMultiplex(int l,int cid,int lid,String name,String add);
	public ArrayList<Multiplex> SearchMultiplex(String str);

}
