package com.virtusa.mtms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.mtms.dto.City;
import com.virtusa.mtms.dto.Seats;
import com.virtusa.mtms.dto.Show;
import com.virtusa.mtms.dto.Movie;
import com.virtusa.mtms.dto.Multiplex;
import com.virtusa.mtms.dto.PresentMovie;
import com.virtusa.mtms.dto.Theatre;
import com.virtusa.mtms.service.IBookingServiceImpl;
import com.virtusa.mtms.service.ICityServiceImpl;
import com.virtusa.mtms.service.IMovieServiceImpl;
import com.virtusa.mtms.service.IMultiplex;
import com.virtusa.mtms.service.IMultiplexServiceImpl;
import com.virtusa.mtms.service.ITheatreServiceImpl;

@WebServlet("/HomePage")
public class HomePageController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public HomePageController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ICityServiceImpl city = new ICityServiceImpl();
		IMovieServiceImpl mv = new IMovieServiceImpl();
		ITheatreServiceImpl ts = new ITheatreServiceImpl();
		HttpSession sn = request.getSession();
		ArrayList<City> cl = city.getCity();
		ArrayList<Movie> lmv = ts.getAllLatestMovies();
		ArrayList<Movie> umv = ts.getAllUpcomingMovies();
		String action = request.getParameter("action");
		String target = "";
		switch (action) {

		case "Lets get started!": {

			sn.setAttribute("cname", "Select Location");
			sn.setAttribute("cityList", cl);
			sn.setAttribute("newMovieList", lmv);
			sn.setAttribute("upComingList", umv);
			target = "Homepage.jsp";
			break;
		}
		case "Admin": {
			target = "AdminLogin.jsp";
			break;
		}
		case "Customer": {
			target = "Signin.jsp";
			break;
		}

		case "search": {
			String movie = request.getParameter("search");

			ArrayList<Movie> smv = mv.SearchMovie(movie);
			System.out.println(smv);

			sn.setAttribute("Movie", movie);
			sn.setAttribute("MovieList", smv);
			target = "GuestMovies.jsp";
			break;
		}

		case "Go": {
			String genre = request.getParameter("genre");
			String lang = request.getParameter("lang");
			ArrayList<City> c = city.getCity();
			ArrayList<Movie> a = ts.searchLmv(genre, lang);
			System.out.println(a);
			sn.setAttribute("ggenre", genre);
			sn.setAttribute("glang", lang);
			sn.setAttribute("CTable", c);
			sn.setAttribute("newMovieList", a);
			target = "AllMovies.jsp";
			break;
		}

		case "Book": {
			String img = request.getParameter("img");
			String mname = request.getParameter("mname");
			String lang = request.getParameter("lang");
			String cen = request.getParameter("cen");
			String gen = request.getParameter("gen");
			String dur = request.getParameter("dur");
			int id = Integer.valueOf(request.getParameter("id"));
			String cat = request.getParameter("cat");
			String dir = request.getParameter("dir");
			String cast = request.getParameter("cast");
			String syn = request.getParameter("syn");

			ArrayList<Show> c = ts.getTheatreByMid(id);

			sn.setAttribute("Bimg", img);
			sn.setAttribute("Bname", mname);
			sn.setAttribute("Blang", lang);
			sn.setAttribute("Bcen", cen);
			sn.setAttribute("Bgen", gen);
			sn.setAttribute("Bdur", dur);
			sn.setAttribute("Bmid", id);
			sn.setAttribute("Bcat", cat);
			sn.setAttribute("Bdir", dir);
			sn.setAttribute("Bcast", cast);
			sn.setAttribute("Bsyn", syn);
			sn.setAttribute("BTList", c);
			target = "GBooking.jsp";

			break;
		}

		}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
