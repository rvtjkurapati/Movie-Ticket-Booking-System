package com.virtusa.mtms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.virtusa.mtms.dto.City;
import com.virtusa.mtms.util.DbConnection;

public class ICityDAOImpl {

	public boolean AddCity(String l) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from city where cityname=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1, l);
			ResultSet rs = ps1.executeQuery();

			if (!rs.next()) {
				String cmd2 = "insert into city (cityname) values(?)";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setString(1, l);
				ps2.executeUpdate();
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public boolean DelCity(int s) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from city where cityId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, s);
			ResultSet rs = ps1.executeQuery();

			if (rs.next()) {

				String cmd5 = "select * from location where cityId=?";
				PreparedStatement ps5 = con.prepareStatement(cmd5);
				ps5.setInt(1, s);
				ResultSet rs1 = ps5.executeQuery();
				if (rs1.next()) {

					String cmd3 = "delete from location where cityId=?";
					PreparedStatement ps3 = con.prepareStatement(cmd3);
					ps3.setInt(1, s);
					ps3.executeUpdate();

				}

				String cmd6 = "select multiplexId from multiplex where cityId=?";
				PreparedStatement ps6 = con.prepareStatement(cmd6);
				ps6.setInt(1, s);
				ResultSet rs2 = ps6.executeQuery();
				while (rs2.next()) {
					int mid = rs2.getInt(1);

					String cmd11 = "delete from theatre where multiplexId=?";
					PreparedStatement ps11 = con.prepareStatement(cmd11);
					ps11.setInt(1, mid);
					ps11.executeUpdate();

					String cmd8 = "delete from booking where multiplexId=?";
					PreparedStatement ps8 = con.prepareStatement(cmd8);
					ps8.setInt(1, mid);
					ps8.executeUpdate();

					String cmd9 = "delete from morningseats where multiplexId=?";
					PreparedStatement ps9 = con.prepareStatement(cmd9);
					ps9.setInt(1, mid);
					ps9.executeUpdate();

					String cmd12 = "delete from matineeseats where multiplexId=?";
					PreparedStatement ps12 = con.prepareStatement(cmd12);
					ps12.setInt(1, mid);
					ps12.executeUpdate();

					String cmd13 = "delete from secondshowseats where multiplexId=?";
					PreparedStatement ps13 = con.prepareStatement(cmd13);
					ps13.setInt(1, mid);
					ps13.executeUpdate();

				}

				String cmd4 = "delete from multiplex where cityId=?";
				PreparedStatement ps4 = con.prepareStatement(cmd4);
				ps4.setInt(1, s);
				ps4.executeUpdate();

				String cmd2 = "delete from city where cityId=?";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, s);
				ps2.executeUpdate();

				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return false;
	}

	public ArrayList<City> getCity() {
		ArrayList<City> log = new ArrayList<City>();
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from city order by cityname asc";
			PreparedStatement ps = con.prepareStatement(cmd);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String came = rs.getString(2);
				City l = new City(id, came);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			} else {
				return null;
			}
		}

		catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public boolean ModifyCity(int cid, String name) {

		try {

			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from city where cityId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, cid);
			ResultSet rs = ps1.executeQuery();

			int e = 1;
			String cmd14 = "select count(cityname) from city where cityname=? and cityId!=?";
			PreparedStatement ps14 = con.prepareStatement(cmd14);
			ps14.setString(1, name);
			ps14.setInt(2, cid);
			ResultSet rs14 = ps14.executeQuery();
			while (rs14.next()) {
				e = rs14.getInt(1);
			}

			if (rs.next() && e == 0) {
				String cmd = "update  city  set cityname=? where cityId=?";
				PreparedStatement ps = con.prepareStatement(cmd);
				ps.setString(1, name);
				ps.setInt(2, cid);
				ps.executeUpdate();

//					int s=cid;

//					String cmd5="select * from location where cityId=?";
//					PreparedStatement ps5 = con.prepareStatement(cmd5);
//					ps5.setInt(1,s);
//					ResultSet rs1= ps5.executeQuery();
//					if(rs1.next())
//					{
//						String cmd3="delete from location where cityId=?";
//						PreparedStatement ps3 = con.prepareStatement(cmd3);
//						ps3.setInt(1,s);
//						ps3.executeUpdate();
//						
//					}

//					
//					String cmd6="select multiplexId from multiplex where cityId=?";
//					PreparedStatement ps6 = con.prepareStatement(cmd6);
//					ps6.setInt(1,s);
//					ResultSet rs2= ps6.executeQuery();
//					while(rs2.next())
//					{
//						int mid=rs2.getInt(1);
//						int id=0;
//						String cmd10="select movieId from movie where multiplexId=?";
//						PreparedStatement ps10 = con.prepareStatement(cmd10);
//						ps10.setInt(1,mid);
//						ResultSet rs10= ps10.executeQuery();
//						while(rs10.next())
//						{	
//							id=rs10.getInt(1);
//						}
//						
//						String cmd11="delete from information where movieId=?";
//						PreparedStatement ps11 = con.prepareStatement(cmd11);
//						ps11.setInt(1,id);
//						ps11.executeUpdate();
//						
//						String cmd7="delete from movie where multiplexId=?";
//						PreparedStatement ps7 = con.prepareStatement(cmd7);
//						ps7.setInt(1,mid);
//						ps7.executeUpdate();
//						
//						String cmd8="delete from booking where multiplexId=?";
//						PreparedStatement ps8 = con.prepareStatement(cmd8);
//						ps8.setInt(1,mid);
//						ps8.executeUpdate();
//						
//						String cmd9="delete from morningseats where multiplexId=?";
//						PreparedStatement ps9 = con.prepareStatement(cmd9);
//						ps9.setInt(1,mid);
//						ps9.executeUpdate();
//						
//						String cmd12="delete from matineeseats where multiplexId=?";
//						PreparedStatement ps12 = con.prepareStatement(cmd12);
//						ps12.setInt(1,mid);
//						ps12.executeUpdate();
//						
//						String cmd13="delete from secondshowseats where multiplexId=?";
//						PreparedStatement ps13 = con.prepareStatement(cmd13);
//						ps13.setInt(1,mid);
//						ps13.executeUpdate();
//						
//					}
//					
//					String cmd4="delete from multiplex where cityId=?";
//					PreparedStatement ps4 = con.prepareStatement(cmd4);
//					ps4.setInt(1,s);
//					ps4.executeUpdate();	
//					return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}

		return false;
	}

	public ArrayList<City> SearchCity(String str) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<City> log = new ArrayList<City>();
			String cmd = "select * from  city  where cityname like ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, str + "%");
			System.out.println(str + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String cname = rs.getString(2);
				City l = new City(id, cname);
				System.out.println(l);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<City> SearchCity(int cid) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<City> log = new ArrayList<City>();
			String cmd = "select * from  city  where cityId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, cid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String cname = rs.getString(2);
				City l = new City(id, cname);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public int getCid(String str) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select cityId from  city  where cityname= ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, str);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				System.out.println("*********");
				int id = rs.getInt(1);
				return id;

			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return 0;
	}

	public String getCname(int str) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select cityname from  city  where cityId= ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, str);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				System.out.println("*********");
				String id = rs.getString(1);
				return id;

			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

}
