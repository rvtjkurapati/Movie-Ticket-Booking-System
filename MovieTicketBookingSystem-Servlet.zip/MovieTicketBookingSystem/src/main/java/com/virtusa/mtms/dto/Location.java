package com.virtusa.mtms.dto;

public class Location {

	int cid;
	int lid;
	String lname;

	public Location() {
		super();
	}

	public Location(int cid, int lid, String lname) {
		super();
		this.cid = cid;
		this.lid = lid;
		this.lname = lname;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	@Override
	public String toString() {
		return "Location [cid=" + cid + ", lid=" + lid + ", lname=" + lname + "]";
	}

}
