package com.virtusa.mtms.service;

import java.util.ArrayList;

import com.virtusa.mtms.dao.ILocationDAOImpl;
import com.virtusa.mtms.dto.Location;

public class ILocationServiceImpl implements ILocation {

	ILocationDAOImpl dao;

	public boolean AddLocation(Location l) {
		dao = new ILocationDAOImpl();
		boolean flag = dao.AddLocation(l);
		return flag;
	}

	public boolean DelLocation(int s) {
		dao = new ILocationDAOImpl();
		boolean flag = dao.DelLocation(s);
		return flag;
	}

	public ArrayList<Location> getLocation() {
		dao = new ILocationDAOImpl();
		ArrayList<Location> al = dao.getLocation();
		return al;
	}

	public boolean ModifyLocation(int l, int cid, String name) {
		dao = new ILocationDAOImpl();
		boolean flag = dao.ModifyLocation(l, cid, name);
		return flag;
	}

	public ArrayList<Location> SearchLocation(String str) {
		dao = new ILocationDAOImpl();
		ArrayList<Location> al = dao.SearchLocation(str);
		return al;
	}

	public ArrayList<Location> SearchLocationByCid(int ctid) {
		dao = new ILocationDAOImpl();
		ArrayList<Location> al = dao.SearchLocationByCid(ctid);
		return al;
	}

	public ArrayList<Location> SearchLocationByLid(int lid) {
		dao = new ILocationDAOImpl();
		ArrayList<Location> al = dao.SearchLocationByLid(lid);
		return al;
	}

	public int getLid(String id) {

		dao = new ILocationDAOImpl();
		int al = dao.getLid(id);
		return al;

	}

	public int getCid(String id) {

		dao = new ILocationDAOImpl();
		int al = dao.getCid(id);
		return al;

	}

	public String getLname(int id) {
		dao = new ILocationDAOImpl();
		String al = dao.getLname(id);
		return al;
	}

}
