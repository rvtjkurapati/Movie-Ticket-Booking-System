package com.virtusa.mtms.service;

import com.virtusa.mtms.dao.ISAdminDAOImpl;

public class ISAdminServiceImpl implements ISAdmin {

	ISAdminDAOImpl dao;

	public boolean Validate(String name, String pwd) {
		dao = new ISAdminDAOImpl();
		boolean flag = dao.Validate(name, pwd);
		return flag;
	}

	public boolean Modify(String name, String pwd) {
		dao = new ISAdminDAOImpl();
		boolean flag = dao.Modify(name, pwd);
		return flag;
	}

}
