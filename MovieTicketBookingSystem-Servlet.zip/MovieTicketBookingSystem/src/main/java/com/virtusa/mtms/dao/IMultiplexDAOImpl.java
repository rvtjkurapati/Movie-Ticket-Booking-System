package com.virtusa.mtms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.mtms.dto.CityLocMux;
import com.virtusa.mtms.dto.CityLocationList;
import com.virtusa.mtms.dto.Multiplex;
import com.virtusa.mtms.util.DbConnection;

public class IMultiplexDAOImpl {

	public boolean AddMultiplex(Multiplex l) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from multiplex where multiplexName=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1, l.getMname());
			ResultSet rs = ps1.executeQuery();

			String cmd11 = "select * from multiplex where locId=?";
			PreparedStatement ps11 = con.prepareStatement(cmd11);
			ps11.setInt(1, l.getLid());
			ResultSet rs11 = ps11.executeQuery();

			if (!rs.next() && !rs11.next()) {
				String cmd2 = "insert into multiplex (cityId,locId,multiplexName,Address) values(?,?,?,?)";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, l.getCid());
				ps2.setInt(2, l.getLid());
				ps2.setString(3, l.getMname());
				ps2.setString(4, l.getAdd());
				ps2.executeUpdate();
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public boolean DelMultiplex(int s) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from multiplex where multiplexId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, s);
			ResultSet rs = ps1.executeQuery();

			if (rs.next()) {

				String cmd11 = "delete from theatre where multiplexId=?";
				PreparedStatement ps11 = con.prepareStatement(cmd11);
				ps11.setInt(1, s);
				ps11.executeUpdate();

				String cmd8 = "delete from booking where multiplexId=?";
				PreparedStatement ps8 = con.prepareStatement(cmd8);
				ps8.setInt(1, s);
				ps8.executeUpdate();

				String cmd9 = "delete from morningseats where multiplexId=?";
				PreparedStatement ps9 = con.prepareStatement(cmd9);
				ps9.setInt(1, s);
				ps9.executeUpdate();

				String cmd12 = "delete from matineeseats where multiplexId=?";
				PreparedStatement ps12 = con.prepareStatement(cmd12);
				ps12.setInt(1, s);
				ps12.executeUpdate();

				String cmd13 = "delete from secondshowseats where multiplexId=?";
				PreparedStatement ps13 = con.prepareStatement(cmd13);
				ps13.setInt(1, s);
				ps13.executeUpdate();

				String cmd4 = "delete from multiplex where multiplexId=?";
				PreparedStatement ps4 = con.prepareStatement(cmd4);
				ps4.setInt(1, s);
				ps4.executeUpdate();

				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return false;
	}

	public ArrayList<Multiplex> getMultiplex() {
		ArrayList<Multiplex> log = new ArrayList<>();
		System.out.println("****************************************");
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from multiplex";
			PreparedStatement ps = con.prepareStatement(cmd);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				int lid = rs.getInt(2);
				String mname = rs.getString(3);
				int mid = rs.getInt(4);
				String add = rs.getString(5);
				Multiplex l = new Multiplex(cid, lid, mname, mid, add);
				log.add(l);
				System.out.println(l);

			}

			if (log.size() != 0) {
				return log;
			} else {
				return null;
			}
		}

		catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public boolean ModifyMultiplex(int l, int cid, int lid, String name, String add) {

		try {

			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from multiplex where multiplexId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, l);
			ResultSet rs = ps1.executeQuery();

			String cmd11 = "select * from multiplex where locId=? and multiplexId!=?";
			PreparedStatement ps11 = con.prepareStatement(cmd11);
			ps11.setInt(1, lid);
			ps11.setInt(2, l);
			ResultSet rs11 = ps11.executeQuery();

			String cmd15 = "select * from multiplex where multiplexName=? and multiplexId!=?";
			PreparedStatement ps15 = con.prepareStatement(cmd15);
			ps15.setString(1, name);
			ps15.setInt(2, l);
			ResultSet rs15 = ps15.executeQuery();

			if (rs.next() && !rs15.next() && !rs11.next()) {
				String cmd = "update  multiplex  set cityId=?, locId=?, multiplexName=?, Address=? where multiplexId=?";
				PreparedStatement ps = con.prepareStatement(cmd);
				ps.setInt(1, cid);
				ps.setInt(2, lid);
				ps.setString(3, name);
				ps.setString(4, add);
				ps.setInt(5, l);
				ps.executeUpdate();
				return true;

			}

			else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}

		return false;
	}

	public ArrayList<Multiplex> SearchMultiplex(String str) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Multiplex> log = new ArrayList<Multiplex>();
			String cmd = "select * from  multiplex  where multiplexName like ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, str + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				int lid = rs.getInt(2);
				String mname = rs.getString(3);
				int mid = rs.getInt(4);
				String add = rs.getString(5);
				Multiplex l = new Multiplex(cid, lid, mname, mid, add);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Multiplex> SearchMultiplexByMid(int id) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Multiplex> log = new ArrayList<Multiplex>();
			String cmd = "select * from  multiplex  where multiplexId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				int lid = rs.getInt(2);
				String mname = rs.getString(3);
				int mid = rs.getInt(4);
				String add = rs.getString(5);
				Multiplex l = new Multiplex(cid, lid, mname, mid, add);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Multiplex> SearchMultiplexLid(int id) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Multiplex> log = new ArrayList<Multiplex>();
			String cmd = "select * from  multiplex  where locId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				int lid = rs.getInt(2);
				String mname = rs.getString(3);
				int mid = rs.getInt(4);
				String add = rs.getString(5);
				Multiplex l = new Multiplex(cid, lid, mname, mid, add);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Multiplex> SearchMultiplexCid(int id) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Multiplex> log = new ArrayList<Multiplex>();
			String cmd = "select * from  multiplex  where cityId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				int lid = rs.getInt(2);
				String mname = rs.getString(3);
				int mid = rs.getInt(4);
				String add = rs.getString(5);
				Multiplex l = new Multiplex(cid, lid, mname, mid, add);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public int getMxid(String name) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Multiplex> log = new ArrayList<Multiplex>();
			String cmd = "select multiplexId from  multiplex  where multiplexName=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				return cid;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return 0;
	}

	public ArrayList<CityLocationList> getCList() {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<CityLocationList> log = new ArrayList<CityLocationList>();
			String cmd = "select cityId,location from  location order by location asc";
			PreparedStatement ps = con.prepareStatement(cmd);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				String cname = "";

				String cmd1 = "select cityname from  city where cityId=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, cid);
				ResultSet rs1 = ps1.executeQuery();
				while (rs1.next()) {
					cname = rs1.getString(1);
				}

				String lname = rs.getString(2);
				CityLocationList l = new CityLocationList(cname, lname);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public String getMxname(int id) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select multiplexName from  multiplex where multiplexId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String cid = rs.getString(1);
				return cid;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<CityLocMux> getMList() {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<CityLocMux> log = new ArrayList<CityLocMux>();
			String cmd = "select cityId,locId,multiplexName from  multiplex order by multiplexName asc";
			PreparedStatement ps = con.prepareStatement(cmd);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				String cname = "";

				String cmd1 = "select cityname from  city where cityId=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, cid);
				ResultSet rs1 = ps1.executeQuery();
				while (rs1.next()) {
					cname = rs1.getString(1);
				}

				int lid = rs.getInt(2);
				String lname = "";
				String cmd11 = "select location from  location where locId=?";
				PreparedStatement ps11 = con.prepareStatement(cmd11);
				ps11.setInt(1, lid);
				ResultSet rs11 = ps11.executeQuery();
				while (rs11.next()) {
					lname = rs11.getString(1);
				}

				String mname = rs.getString(3);
				CityLocMux l = new CityLocMux(cname, lname, mname);
				System.out.println(l);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public int getCid(String id) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select cityId from  multiplex where multiplexName=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				return cid;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return 0;
	}

	public int getLid(String id) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select multiplexId from  multiplex where multiplexName=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int cid = rs.getInt(1);
				return cid;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return 0;
	}
}
