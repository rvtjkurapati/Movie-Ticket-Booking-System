package com.virtusa.mtms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.virtusa.mtms.util.DbConnection;

public class ISAdminDAOImpl {

	public boolean Validate(String name, String pwd) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from sadmin where uname=? and pwd=?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, name);
			ps.setString(2, pwd);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}

		return false;
	}

	public boolean Modify(String name, String pwd) {

		try {

			Connection con = DbConnection.getConnection();

			String cmd = "update  admin  set  pwd=? where uname=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, pwd);
			ps.setString(2, name);
			ps.executeUpdate();
			return true;

		} catch (Exception e) {
			e.getStackTrace();
		}

		return false;
	}

}
