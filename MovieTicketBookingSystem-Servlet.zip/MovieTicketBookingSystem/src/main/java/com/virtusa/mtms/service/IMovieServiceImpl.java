package com.virtusa.mtms.service;

import java.util.ArrayList;
import com.virtusa.mtms.dao.IMovieDAOImpl;
import com.virtusa.mtms.dto.Movie;

public class IMovieServiceImpl implements IMovie {

	IMovieDAOImpl dao;

	public boolean AddMovie(Movie l) {
		dao = new IMovieDAOImpl();
		boolean flag = dao.AddMovie(l);
		return flag;
	}

	public boolean DelMovie(int s) {
		dao = new IMovieDAOImpl();
		boolean flag = dao.DelMovie(s);
		return flag;
	}

	public ArrayList<Movie> getMovies() {
		dao = new IMovieDAOImpl();
		ArrayList<Movie> al = dao.getMovies();
		return al;
	}

	public ArrayList<Movie> SearchMovie(String name) {
		dao = new IMovieDAOImpl();
		ArrayList<Movie> al = dao.SearchMovie(name);
		return al;
	}

	public ArrayList<Movie> SearchMovieByCat(String name) {
		dao = new IMovieDAOImpl();
		ArrayList<Movie> al = dao.SearchMovieByCat(name);
		return al;
	}

	public ArrayList<Movie> SearchMovieByLang(String name) {
		dao = new IMovieDAOImpl();
		ArrayList<Movie> al = dao.SearchMovieByLang(name);
		return al;
	}

	public ArrayList<Movie> SearchMovieByGen(String name) {
		dao = new IMovieDAOImpl();
		ArrayList<Movie> al = dao.SearchMovieByGen(name);
		return al;
	}

	public ArrayList<Movie> SearchMovieByMid(int name) {
		dao = new IMovieDAOImpl();
		ArrayList<Movie> al = dao.SearchMovieByMid(name);
		return al;
	}

	public boolean ModifyMovie(Movie m) {
		dao = new IMovieDAOImpl();
		boolean flag = dao.ModifyMovie(m);
		return flag;
	}

	public boolean ValMovieId(int d) {
		dao = new IMovieDAOImpl();
		boolean flag = dao.ValMovieId(d);
		return flag;
	}

	public String SuggestMovie() {
		dao = new IMovieDAOImpl();
		String flag = dao.SuggestMovie();
		return flag;
	}

	public int getMid(String name) {
		dao = new IMovieDAOImpl();
		int flag = dao.getMid(name);
		return flag;
	}
}
