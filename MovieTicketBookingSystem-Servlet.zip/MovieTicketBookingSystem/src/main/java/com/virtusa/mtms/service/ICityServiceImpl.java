package com.virtusa.mtms.service;

import java.util.ArrayList;

import com.virtusa.mtms.dao.ICityDAOImpl;
import com.virtusa.mtms.dto.City;

public class ICityServiceImpl implements ICity {

	ICityDAOImpl dao;

	public boolean AddCity(String l) {
		dao = new ICityDAOImpl();
		boolean flag = dao.AddCity(l);
		return flag;
	}

	public boolean DelCity(int s) {
		dao = new ICityDAOImpl();
		boolean flag = dao.DelCity(s);
		return flag;
	}

	public ArrayList<City> getCity() {
		dao = new ICityDAOImpl();
		ArrayList<City> al = dao.getCity();
		return al;
	}

	public boolean ModifyCity(int l, String name) {
		dao = new ICityDAOImpl();
		boolean flag = dao.ModifyCity(l, name);
		return flag;
	}

	public ArrayList<City> SearchCity(String str) {
		dao = new ICityDAOImpl();
		ArrayList<City> al = dao.SearchCity(str);
		return al;
	}

	public ArrayList<City> SearchCity(int cid) {
		dao = new ICityDAOImpl();
		ArrayList<City> al = dao.SearchCity(cid);
		return al;

	}

	public int getCid(String str) {
		dao = new ICityDAOImpl();
		int al = dao.getCid(str);
		return al;
	}

	public String getCname(int str) {
		dao = new ICityDAOImpl();
		String al = dao.getCname(str);
		return al;
	}

}
