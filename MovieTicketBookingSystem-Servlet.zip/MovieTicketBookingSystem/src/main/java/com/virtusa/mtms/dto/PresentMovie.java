package com.virtusa.mtms.dto;

public class PresentMovie {

	int mid;
	String mname;
	String Category;
	String lang;
	String duration;
	String genre;
	String censor;
	String show1;
	String show2;
	String show3;
	String sdate;
	String edate;
	int mplexid;
	int cid;
	int screen;
	int price;
	String image;
	String dir;
	String cast;
	String syn;

	public PresentMovie() {
		super();
	}

	public PresentMovie(int mid, String mname, String category, String lang, String duration, String genre,
			String censor, String show1, String show2, String show3, String sdate, String edate, int mplexid, int cid,
			int screen, int price, String image, String dir, String cast, String syn) {
		super();
		this.mid = mid;
		this.mname = mname;
		Category = category;
		this.lang = lang;
		this.duration = duration;
		this.genre = genre;
		this.censor = censor;
		this.show1 = show1;
		this.show2 = show2;
		this.show3 = show3;
		this.sdate = sdate;
		this.edate = edate;
		this.mplexid = mplexid;
		this.cid = cid;
		this.screen = screen;
		this.price = price;
		this.image = image;
		this.dir = dir;
		this.cast = cast;
		this.syn = syn;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getCensor() {
		return censor;
	}

	public void setCensor(String censor) {
		this.censor = censor;
	}

	public String getShow1() {
		return show1;
	}

	public void setShow1(String show1) {
		this.show1 = show1;
	}

	public String getShow2() {
		return show2;
	}

	public void setShow2(String show2) {
		this.show2 = show2;
	}

	public String getShow3() {
		return show3;
	}

	public void setShow3(String show3) {
		this.show3 = show3;
	}

	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		this.sdate = sdate;
	}

	public String getEdate() {
		return edate;
	}

	public void setEdate(String edate) {
		this.edate = edate;
	}

	public int getMplexid() {
		return mplexid;
	}

	public void setMplexid(int mplexid) {
		this.mplexid = mplexid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getScreen() {
		return screen;
	}

	public void setScreen(int screen) {
		this.screen = screen;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDir() {
		return dir;
	}

	public void setDir(String dir) {
		this.dir = dir;
	}

	public String getCast() {
		return cast;
	}

	public void setCast(String cast) {
		this.cast = cast;
	}

	public String getSyn() {
		return syn;
	}

	public void setSyn(String syn) {
		this.syn = syn;
	}

	@Override
	public String toString() {
		return "PresentMovie [mid=" + mid + ", mname=" + mname + ", Category=" + Category + ", lang=" + lang
				+ ", duration=" + duration + ", genre=" + genre + ", censor=" + censor + ", show1=" + show1 + ", show2="
				+ show2 + ", show3=" + show3 + ", sdate=" + sdate + ", edate=" + edate + ", mplexid=" + mplexid
				+ ", cid=" + cid + ", screen=" + screen + ", price=" + price + ", image=" + image + ", dir=" + dir
				+ ", cast=" + cast + ", syn=" + syn + "]";
	}

}
