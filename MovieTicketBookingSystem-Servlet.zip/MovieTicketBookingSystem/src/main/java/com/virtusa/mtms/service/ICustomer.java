package com.virtusa.mtms.service;

import java.util.ArrayList;

import com.virtusa.mtms.dto.Customer;

public interface ICustomer {

	public boolean AddCustomer(Customer l);

	public boolean DelCustomer(int s);

	public boolean ValidateCustomer(String uname, String pwd);

	public ArrayList<Customer> getCustomers();

	public boolean ModifyCustomer(int l, String uname, String pwd, String phn, String mail);

	public ArrayList<Customer> SearchCustomer(String str);

	public Customer getCustIdPhone(Customer l);

	public boolean ValidateId(int id);

}
