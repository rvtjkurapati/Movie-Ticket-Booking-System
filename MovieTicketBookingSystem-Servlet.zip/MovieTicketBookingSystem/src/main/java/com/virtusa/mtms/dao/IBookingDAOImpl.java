package com.virtusa.mtms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.virtusa.mtms.dto.Booking;
import com.virtusa.mtms.dto.Seats;
import com.virtusa.mtms.dto.Ticket;
import com.virtusa.mtms.util.DbConnection;

public class IBookingDAOImpl {

	public boolean BookTicket(Booking b) {
		try {
			Connection con = DbConnection.getConnection();

			String cmd2 = "select * from movie  where movieId=?;";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, b.getMid());
			ResultSet rs2 = ps2.executeQuery();

			String cmd7 = "select * from theatre  where tId=?;";
			PreparedStatement ps7 = con.prepareStatement(cmd7);
			ps7.setInt(1, b.getTid());
			ResultSet rs7 = ps7.executeQuery();

			String mdate = b.getShowd();
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date datei = sdf1.parse(mdate);
			java.sql.Date sqlDate = new java.sql.Date(datei.getTime());

			String cmd3 = "select movieId from theatre where (? >= start_date) and (end_date >= ? ) and movieId=?";
			PreparedStatement ps3 = con.prepareStatement(cmd3);
			ps3.setDate(1, sqlDate);
			ps3.setDate(2, sqlDate);
			ps3.setInt(3, b.getMid());
			ResultSet rs3 = ps3.executeQuery();

			if (rs2.next() && rs3.next() && rs7.next()) {

				String cmd4 = "insert into booking (custId,tId,multiplexId,movieId,showdate,showtime,seats,phone,screen) values(?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps4 = con.prepareStatement(cmd4);
				ps4.setInt(1, b.getCid());
				ps4.setInt(2, b.getTid());
				ps4.setInt(3, b.getMxid());
				ps4.setInt(4, b.getMid());
				ps4.setDate(5, sqlDate);
				ps4.setString(6, b.getShowt());
				ps4.setString(7, b.getSeats());
				ps4.setString(8, b.getPhone());
				ps4.setInt(9, b.getScreen());
				ps4.executeUpdate();

				String s = b.getSeats();
				String[] str = s.split("[,]");

				String cmd5 = "";

				if (b.getShowt().equals(" morning")) {

					for (String a : str) {
						if (a.equals("A1"))

						{

							cmd5 = "update morningseats set A1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A2"))

						{

							cmd5 = "update morningseats set A2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A3"))

						{

							cmd5 = "update morningseats set A3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A4"))

						{

							cmd5 = "update morningseats set A4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A5"))

						{

							cmd5 = "update morningseats set A5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A6"))

						{

							cmd5 = "update morningseats set A6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A7"))

						{

							cmd5 = "update morningseats set A7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A8"))

						{

							cmd5 = "update morningseats set A8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A9"))

						{

							cmd5 = "update morningseats set A9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A10"))

						{

							cmd5 = "update morningseats set A10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A11"))

						{

							cmd5 = "update morningseats set A11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A12"))

						{

							cmd5 = "update morningseats set A12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B1"))

						{

							cmd5 = "update morningseats set B1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B2"))

						{

							cmd5 = "update morningseats set B2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B3"))

						{

							cmd5 = "update morningseats set B3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B4"))

						{

							cmd5 = "update morningseats set B4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B5"))

						{

							cmd5 = "update morningseats set B5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B6"))

						{

							cmd5 = "update morningseats set B6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B7"))

						{

							cmd5 = "update morningseats set B7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B8"))

						{

							cmd5 = "update morningseats set B8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B9"))

						{

							cmd5 = "update morningseats set B9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B10"))

						{

							cmd5 = "update morningseats set B10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B11"))

						{

							cmd5 = "update morningseats set B11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B12"))

						{

							cmd5 = "update morningseats set B12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C1"))

						{

							cmd5 = "update morningseats set C1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C2"))

						{

							cmd5 = "update morningseats set C2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C3"))

						{

							cmd5 = "update morningseats set C3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C4"))

						{

							cmd5 = "update morningseats set C4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C5"))

						{

							cmd5 = "update morningseats set C5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C6"))

						{

							cmd5 = "update morningseats set C6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C7"))

						{

							cmd5 = "update morningseats set C7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C8"))

						{

							cmd5 = "update morningseats set C8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C9"))

						{

							cmd5 = "update morningseats set C9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C10"))

						{

							cmd5 = "update morningseats set C10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C11"))

						{

							cmd5 = "update morningseats set C11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C12"))

						{

							cmd5 = "update morningseats set C12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D1"))

						{

							cmd5 = "update morningseats set D1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D2"))

						{

							cmd5 = "update morningseats set D2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D3"))

						{

							cmd5 = "update morningseats set D3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D4"))

						{

							cmd5 = "update morningseats set D4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D5"))

						{

							cmd5 = "update morningseats set D5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D6"))

						{

							cmd5 = "update morningseats set D6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D7"))

						{

							cmd5 = "update morningseats set D7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D8"))

						{

							cmd5 = "update morningseats set D8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D9"))

						{

							cmd5 = "update morningseats set D9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D10"))

						{

							cmd5 = "update morningseats set D10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D11"))

						{

							cmd5 = "update morningseats set D11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D12"))

						{

							cmd5 = "update morningseats set D12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E1"))

						{

							cmd5 = "update morningseats set E1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E2"))

						{

							cmd5 = "update morningseats set E2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E3"))

						{

							cmd5 = "update morningseats set E3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E4"))

						{

							cmd5 = "update morningseats set E4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E5"))

						{

							cmd5 = "update morningseats set E5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E6"))

						{

							cmd5 = "update morningseats set E6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E7"))

						{

							cmd5 = "update morningseats set E7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E8"))

						{

							cmd5 = "update morningseats set E8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E9"))

						{

							cmd5 = "update morningseats set E9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E10"))

						{

							cmd5 = "update morningseats set E10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E11"))

						{

							cmd5 = "update morningseats set E11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E12"))

						{

							cmd5 = "update morningseats set E12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F1"))

						{

							cmd5 = "update morningseats set F1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F2"))

						{

							cmd5 = "update morningseats set F2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F3"))

						{

							cmd5 = "update morningseats set F3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F4"))

						{

							cmd5 = "update morningseats set F4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F5"))

						{

							cmd5 = "update morningseats set F5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F6"))

						{

							cmd5 = "update morningseats set F6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F7"))

						{

							cmd5 = "update morningseats set F7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F8"))

						{

							cmd5 = "update morningseats set F8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F9"))

						{

							cmd5 = "update morningseats set F9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F10"))

						{

							cmd5 = "update morningseats set F10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F11"))

						{

							cmd5 = "update morningseats set F11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F12"))

						{

							cmd5 = "update morningseats set F12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G1"))

						{

							cmd5 = "update morningseats set G1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G2"))

						{

							cmd5 = "update morningseats set G2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G3"))

						{

							cmd5 = "update morningseats set G3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G4"))

						{

							cmd5 = "update morningseats set G4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G5"))

						{

							cmd5 = "update morningseats set G5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G6"))

						{

							cmd5 = "update morningseats set G6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G7"))

						{

							cmd5 = "update morningseats set G7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G8"))

						{

							cmd5 = "update morningseats set G8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G9"))

						{

							cmd5 = "update morningseats set G9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G10"))

						{

							cmd5 = "update morningseats set G10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G11"))

						{

							cmd5 = "update morningseats set G11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G12"))

						{

							cmd5 = "update morningseats set G12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H1"))

						{

							cmd5 = "update morningseats set H1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H2"))

						{

							cmd5 = "update morningseats set H2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H3"))

						{

							cmd5 = "update morningseats set H3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H4"))

						{

							cmd5 = "update morningseats set H4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H5"))

						{

							cmd5 = "update morningseats set H5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H6"))

						{

							cmd5 = "update morningseats set H6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H7"))

						{

							cmd5 = "update morningseats set H7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H8"))

						{

							cmd5 = "update morningseats set H8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H9"))

						{

							cmd5 = "update morningseats set H9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H10"))

						{

							cmd5 = "update morningseats set H10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H11"))

						{

							cmd5 = "update morningseats set H11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H12"))

						{

							cmd5 = "update morningseats set H12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I1"))

						{

							cmd5 = "update morningseats set I1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I2"))

						{

							cmd5 = "update morningseats set I2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I3"))

						{

							cmd5 = "update morningseats set I3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I4"))

						{

							cmd5 = "update morningseats set I4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I5"))

						{

							cmd5 = "update morningseats set I5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I6"))

						{

							cmd5 = "update morningseats set I6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I7"))

						{

							cmd5 = "update morningseats set I7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I8"))

						{

							cmd5 = "update morningseats set I8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I9"))

						{

							cmd5 = "update morningseats set I9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I10"))

						{

							cmd5 = "update morningseats set I10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I11"))

						{

							cmd5 = "update morningseats set I11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I12"))

						{

							cmd5 = "update morningseats set I12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J1"))

						{

							cmd5 = "update morningseats set J1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J2"))

						{

							cmd5 = "update morningseats set J2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J3"))

						{

							cmd5 = "update morningseats set J3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J4"))

						{

							cmd5 = "update morningseats set J4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J5"))

						{

							cmd5 = "update morningseats set J5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J6"))

						{

							cmd5 = "update morningseats set J6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J7"))

						{

							cmd5 = "update morningseats set J7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J8"))

						{

							cmd5 = "update morningseats set J8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J9"))

						{

							cmd5 = "update morningseats set J9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J10"))

						{

							cmd5 = "update morningseats set J10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J11"))

						{

							cmd5 = "update morningseats set J11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J12"))

						{

							cmd5 = "update morningseats set J12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						PreparedStatement ps5 = con.prepareStatement(cmd5);
						ps5.setInt(1, b.getMid());
						ps5.setDate(2, sqlDate);
						ps5.setInt(3, b.getMxid());
						ps5.setInt(4, b.getTid());
						ps5.executeUpdate();
					}
				} else if (b.getShowt().equals(" matinee")) {
					System.out.println("matinee lopala bane undhi");

					for (String a : str) {
						System.out.println(a);
						if (a.equals("A1"))

						{

							cmd5 = "update matineeseats set A1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A2"))

						{

							cmd5 = "update matineeseats set A2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A3"))

						{

							cmd5 = "update matineeseats set A3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A4"))

						{

							cmd5 = "update matineeseats set A4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A5"))

						{

							cmd5 = "update matineeseats set A5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A6"))

						{

							cmd5 = "update matineeseats set A6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A7"))

						{

							cmd5 = "update matineeseats set A7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A8"))

						{

							cmd5 = "update matineeseats set A8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A9"))

						{

							cmd5 = "update matineeseats set A9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A10"))

						{

							cmd5 = "update matineeseats set A10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A11"))

						{

							cmd5 = "update matineeseats set A11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A12"))

						{

							cmd5 = "update matineeseats set A12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B1"))

						{

							cmd5 = "update matineeseats set B1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B2"))

						{

							cmd5 = "update matineeseats set B2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B3"))

						{

							cmd5 = "update matineeseats set B3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B4"))

						{

							cmd5 = "update matineeseats set B4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B5"))

						{

							cmd5 = "update matineeseats set B5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B6"))

						{

							cmd5 = "update matineeseats set B6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B7"))

						{

							cmd5 = "update matineeseats set B7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B8"))

						{

							cmd5 = "update matineeseats set B8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B9"))

						{

							cmd5 = "update matineeseats set B9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B10"))

						{

							cmd5 = "update matineeseats set B10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B11"))

						{

							cmd5 = "update matineeseats set B11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B12"))

						{

							cmd5 = "update matineeseats set B12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C1"))

						{

							cmd5 = "update matineeseats set C1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C2"))

						{

							cmd5 = "update matineeseats set C2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C3"))

						{

							cmd5 = "update matineeseats set C3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C4"))

						{

							cmd5 = "update matineeseats set C4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C5"))

						{

							cmd5 = "update matineeseats set C5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C6"))

						{

							cmd5 = "update matineeseats set C6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C7"))

						{

							cmd5 = "update matineeseats set C7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C8"))

						{

							cmd5 = "update matineeseats set C8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C9"))

						{

							cmd5 = "update matineeseats set C9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C10"))

						{

							cmd5 = "update matineeseats set C10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C11"))

						{

							cmd5 = "update matineeseats set C11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C12"))

						{

							cmd5 = "update matineeseats set C12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D1"))

						{

							cmd5 = "update matineeseats set D1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D2"))

						{

							cmd5 = "update matineeseats set D2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D3"))

						{

							cmd5 = "update matineeseats set D3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D4"))

						{

							cmd5 = "update matineeseats set D4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D5"))

						{

							cmd5 = "update matineeseats set D5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D6"))

						{

							cmd5 = "update matineeseats set D6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D7"))

						{

							cmd5 = "update matineeseats set D7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D8"))

						{

							cmd5 = "update matineeseats set D8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D9"))

						{

							cmd5 = "update matineeseats set D9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D10"))

						{

							cmd5 = "update matineeseats set D10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D11"))

						{

							cmd5 = "update matineeseats set D11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D12"))

						{

							cmd5 = "update matineeseats set D12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E1"))

						{

							cmd5 = "update matineeseats set E1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E2"))

						{

							cmd5 = "update matineeseats set E2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E3"))

						{

							cmd5 = "update matineeseats set E3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E4"))

						{

							cmd5 = "update matineeseats set E4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E5"))

						{

							cmd5 = "update matineeseats set E5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E6"))

						{

							cmd5 = "update matineeseats set E6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E7"))

						{

							cmd5 = "update matineeseats set E7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E8"))

						{

							cmd5 = "update matineeseats set E8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E9"))

						{

							cmd5 = "update matineeseats set E9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E10"))

						{

							cmd5 = "update matineeseats set E10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E11"))

						{

							cmd5 = "update matineeseats set E11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E12"))

						{

							cmd5 = "update matineeseats set E12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F1"))

						{

							cmd5 = "update matineeseats set F1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F2"))

						{

							cmd5 = "update matineeseats set F2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F3"))

						{

							cmd5 = "update matineeseats set F3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F4"))

						{

							cmd5 = "update matineeseats set F4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F5"))

						{

							cmd5 = "update matineeseats set F5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F6"))

						{

							cmd5 = "update matineeseats set F6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F7"))

						{

							cmd5 = "update matineeseats set F7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F8"))

						{

							cmd5 = "update matineeseats set F8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F9"))

						{

							cmd5 = "update matineeseats set F9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F10"))

						{

							cmd5 = "update matineeseats set F10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F11"))

						{

							cmd5 = "update matineeseats set F11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F12"))

						{

							cmd5 = "update matineeseats set F12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G1"))

						{

							cmd5 = "update matineeseats set G1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G2"))

						{

							cmd5 = "update matineeseats set G2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G3"))

						{

							cmd5 = "update matineeseats set G3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G4"))

						{

							cmd5 = "update matineeseats set G4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G5"))

						{

							cmd5 = "update matineeseats set G5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G6"))

						{

							cmd5 = "update matineeseats set G6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G7"))

						{

							cmd5 = "update matineeseats set G7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G8"))

						{

							cmd5 = "update matineeseats set G8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G9"))

						{

							cmd5 = "update matineeseats set G9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G10"))

						{

							cmd5 = "update matineeseats set G10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G11"))

						{

							cmd5 = "update matineeseats set G11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G12"))

						{

							cmd5 = "update matineeseats set G12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H1"))

						{

							cmd5 = "update matineeseats set H1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H2"))

						{

							cmd5 = "update matineeseats set H2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H3"))

						{

							cmd5 = "update matineeseats set H3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H4"))

						{

							cmd5 = "update matineeseats set H4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H5"))

						{

							cmd5 = "update matineeseats set H5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H6"))

						{

							cmd5 = "update matineeseats set H6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H7"))

						{

							cmd5 = "update matineeseats set H7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H8"))

						{

							cmd5 = "update matineeseats set H8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H9"))

						{

							cmd5 = "update matineeseats set H9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H10"))

						{

							cmd5 = "update matineeseats set H10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H11"))

						{

							cmd5 = "update matineeseats set H11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H12"))

						{

							cmd5 = "update matineeseats set H12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I1"))

						{

							cmd5 = "update matineeseats set I1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I2"))

						{

							cmd5 = "update matineeseats set I2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I3"))

						{

							cmd5 = "update matineeseats set I3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I4"))

						{

							cmd5 = "update matineeseats set I4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I5"))

						{

							cmd5 = "update matineeseats set I5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I6"))

						{

							cmd5 = "update matineeseats set I6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I7"))

						{

							cmd5 = "update matineeseats set I7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I8"))

						{

							cmd5 = "update matineeseats set I8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I9"))

						{

							cmd5 = "update matineeseats set I9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I10"))

						{

							cmd5 = "update matineeseats set I10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I11"))

						{

							cmd5 = "update matineeseats set I11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I12"))

						{

							cmd5 = "update matineeseats set I12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J1"))

						{

							cmd5 = "update matineeseats set J1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J2"))

						{

							cmd5 = "update matineeseats set J2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J3"))

						{

							cmd5 = "update matineeseats set J3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J4"))

						{

							cmd5 = "update matineeseats set J4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J5"))

						{

							cmd5 = "update matineeseats set J5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J6"))

						{

							cmd5 = "update matineeseats set J6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J7"))

						{

							cmd5 = "update matineeseats set J7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J8"))

						{

							cmd5 = "update matineeseats set J8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J9"))

						{

							cmd5 = "update matineeseats set J9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J10"))

						{

							cmd5 = "update matineeseats set J10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J11"))

						{

							cmd5 = "update matineeseats set J11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J12"))

						{

							cmd5 = "update matineeseats set J12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						PreparedStatement ps5 = con.prepareStatement(cmd5);
						ps5.setInt(1, b.getMid());
						ps5.setDate(2, sqlDate);
						ps5.setInt(3, b.getMxid());
						ps5.setInt(4, b.getTid());
						ps5.executeUpdate();
					}
				} else if (b.getShowt().equals(" secondshow")) {

					for (String a : str) {
						if (a.equals("A1"))

						{

							cmd5 = "update secondshowseats set A1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A2"))

						{

							cmd5 = "update secondshowseats set A2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A3"))

						{

							cmd5 = "update secondshowseats set A3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A4"))

						{

							cmd5 = "update secondshowseats set A4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A5"))

						{

							cmd5 = "update secondshowseats set A5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A6"))

						{

							cmd5 = "update secondshowseats set A6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A7"))

						{

							cmd5 = "update secondshowseats set A7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A8"))

						{

							cmd5 = "update secondshowseats set A8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A9"))

						{

							cmd5 = "update secondshowseats set A9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A10"))

						{

							cmd5 = "update secondshowseats set A10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A11"))

						{

							cmd5 = "update secondshowseats set A11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A12"))

						{

							cmd5 = "update secondshowseats set A12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B1"))

						{

							cmd5 = "update secondshowseats set B1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B2"))

						{

							cmd5 = "update secondshowseats set B2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B3"))

						{

							cmd5 = "update secondshowseats set B3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B4"))

						{

							cmd5 = "update secondshowseats set B4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B5"))

						{

							cmd5 = "update secondshowseats set B5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B6"))

						{

							cmd5 = "update secondshowseats set B6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B7"))

						{

							cmd5 = "update secondshowseats set B7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B8"))

						{

							cmd5 = "update secondshowseats set B8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B9"))

						{

							cmd5 = "update secondshowseats set B9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B10"))

						{

							cmd5 = "update secondshowseats set B10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B11"))

						{

							cmd5 = "update secondshowseats set B11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B12"))

						{

							cmd5 = "update secondshowseats set B12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C1"))

						{

							cmd5 = "update secondshowseats set C1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C2"))

						{

							cmd5 = "update secondshowseats set C2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C3"))

						{

							cmd5 = "update secondshowseats set C3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C4"))

						{

							cmd5 = "update secondshowseats set C4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C5"))

						{

							cmd5 = "update secondshowseats set C5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C6"))

						{

							cmd5 = "update secondshowseats set C6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C7"))

						{

							cmd5 = "update secondshowseats set C7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C8"))

						{

							cmd5 = "update secondshowseats set C8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C9"))

						{

							cmd5 = "update secondshowseats set C9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C10"))

						{

							cmd5 = "update secondshowseats set C10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C11"))

						{

							cmd5 = "update secondshowseats set C11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C12"))

						{

							cmd5 = "update secondshowseats set C12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D1"))

						{

							cmd5 = "update secondshowseats set D1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D2"))

						{

							cmd5 = "update secondshowseats set D2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D3"))

						{

							cmd5 = "update secondshowseats set D3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D4"))

						{

							cmd5 = "update secondshowseats set D4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D5"))

						{

							cmd5 = "update secondshowseats set D5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D6"))

						{

							cmd5 = "update secondshowseats set D6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D7"))

						{

							cmd5 = "update secondshowseats set D7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D8"))

						{

							cmd5 = "update secondshowseats set D8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D9"))

						{

							cmd5 = "update secondshowseats set D9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D10"))

						{

							cmd5 = "update secondshowseats set D10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D11"))

						{

							cmd5 = "update secondshowseats set D11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D12"))

						{

							cmd5 = "update secondshowseats set D12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E1"))

						{

							cmd5 = "update secondshowseats set E1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E2"))

						{

							cmd5 = "update secondshowseats set E2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E3"))

						{

							cmd5 = "update secondshowseats set E3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E4"))

						{

							cmd5 = "update secondshowseats set E4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E5"))

						{

							cmd5 = "update secondshowseats set E5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E6"))

						{

							cmd5 = "update secondshowseats set E6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E7"))

						{

							cmd5 = "update secondshowseats set E7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E8"))

						{

							cmd5 = "update secondshowseats set E8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E9"))

						{

							cmd5 = "update secondshowseats set E9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E10"))

						{

							cmd5 = "update secondshowseats set E10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E11"))

						{

							cmd5 = "update secondshowseats set E11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E12"))

						{

							cmd5 = "update secondshowseats set E12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F1"))

						{

							cmd5 = "update secondshowseats set F1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F2"))

						{

							cmd5 = "update secondshowseats set F2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F3"))

						{

							cmd5 = "update secondshowseats set F3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F4"))

						{

							cmd5 = "update secondshowseats set F4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F5"))

						{

							cmd5 = "update secondshowseats set F5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F6"))

						{

							cmd5 = "update secondshowseats set F6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F7"))

						{

							cmd5 = "update secondshowseats set F7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F8"))

						{

							cmd5 = "update secondshowseats set F8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F9"))

						{

							cmd5 = "update secondshowseats set F9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F10"))

						{

							cmd5 = "update secondshowseats set F10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F11"))

						{

							cmd5 = "update secondshowseats set F11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F12"))

						{

							cmd5 = "update secondshowseats set F12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G1"))

						{

							cmd5 = "update secondshowseats set G1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G2"))

						{

							cmd5 = "update secondshowseats set G2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G3"))

						{

							cmd5 = "update secondshowseats set G3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G4"))

						{

							cmd5 = "update secondshowseats set G4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G5"))

						{

							cmd5 = "update secondshowseats set G5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G6"))

						{

							cmd5 = "update secondshowseats set G6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G7"))

						{

							cmd5 = "update secondshowseats set G7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G8"))

						{

							cmd5 = "update secondshowseats set G8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G9"))

						{

							cmd5 = "update secondshowseats set G9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G10"))

						{

							cmd5 = "update secondshowseats set G10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G11"))

						{

							cmd5 = "update secondshowseats set G11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G12"))

						{

							cmd5 = "update secondshowseats set G12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H1"))

						{

							cmd5 = "update secondshowseats set H1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H2"))

						{

							cmd5 = "update secondshowseats set H2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H3"))

						{

							cmd5 = "update secondshowseats set H3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H4"))

						{

							cmd5 = "update secondshowseats set H4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H5"))

						{

							cmd5 = "update secondshowseats set H5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H6"))

						{

							cmd5 = "update secondshowseats set H6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H7"))

						{

							cmd5 = "update secondshowseats set H7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H8"))

						{

							cmd5 = "update secondshowseats set H8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H9"))

						{

							cmd5 = "update secondshowseats set H9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H10"))

						{

							cmd5 = "update secondshowseats set H10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H11"))

						{

							cmd5 = "update secondshowseats set H11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H12"))

						{

							cmd5 = "update secondshowseats set H12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I1"))

						{

							cmd5 = "update secondshowseats set I1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I2"))

						{

							cmd5 = "update secondshowseats set I2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I3"))

						{

							cmd5 = "update secondshowseats set I3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I4"))

						{

							cmd5 = "update secondshowseats set I4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I5"))

						{

							cmd5 = "update secondshowseats set I5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I6"))

						{

							cmd5 = "update secondshowseats set I6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I7"))

						{

							cmd5 = "update secondshowseats set I7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I8"))

						{

							cmd5 = "update secondshowseats set I8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I9"))

						{

							cmd5 = "update secondshowseats set I9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I10"))

						{

							cmd5 = "update secondshowseats set I10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I11"))

						{

							cmd5 = "update secondshowseats set I11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I12"))

						{

							cmd5 = "update secondshowseats set I12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J1"))

						{

							cmd5 = "update secondshowseats set J1=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J2"))

						{

							cmd5 = "update secondshowseats set J2=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J3"))

						{

							cmd5 = "update secondshowseats set J3=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J4"))

						{

							cmd5 = "update secondshowseats set J4=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J5"))

						{

							cmd5 = "update secondshowseats set J5=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J6"))

						{

							cmd5 = "update secondshowseats set J6=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J7"))

						{

							cmd5 = "update secondshowseats set J7=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J8"))

						{

							cmd5 = "update secondshowseats set J8=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J9"))

						{

							cmd5 = "update secondshowseats set J9=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J10"))

						{

							cmd5 = "update secondshowseats set J10=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J11"))

						{

							cmd5 = "update secondshowseats set J11=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J12"))

						{

							cmd5 = "update secondshowseats set J12=0 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						PreparedStatement ps5 = con.prepareStatement(cmd5);
						ps5.setInt(1, b.getMid());
						ps5.setDate(2, sqlDate);
						ps5.setInt(3, b.getMxid());
						ps5.setInt(4, b.getTid());
						ps5.executeUpdate();
					}
				}

				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return false;
	}

	public boolean ModifyBooking(Booking b) {
		try {
			Connection con = DbConnection.getConnection();

			String cmd2 = "select * from booking  where bid=?;";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, b.getBid());
			ResultSet rs2 = ps2.executeQuery();
			if (rs2.next()) {
				String cmd = "update  booking  set phone=? where bid=?";
				PreparedStatement ps = con.prepareStatement(cmd);
				ps.setString(1, b.getPhone());
				ps.setInt(2, b.getBid());
				ps.executeUpdate();
				return true;
			}
		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}

		return false;
	}

	public boolean CancelTicket(int id) {
		try {

			int tid = 0;
			int mid = 0;
			String seats = "";
			String stime = "";
			String date = "";
			int mxid = 0;
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from booking  where bid=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, id);

			String cmd3 = "select * from booking  where bid=?";
			PreparedStatement ps3 = con.prepareStatement(cmd3);
			ps3.setInt(1, id);
			ResultSet rs1 = ps1.executeQuery();
			ResultSet rs3 = ps3.executeQuery();
			while (rs1.next()) {
				tid = rs1.getInt(3);
				mxid = rs1.getInt(4);
				mid = rs1.getInt(5);
				stime = rs1.getString(7);
				seats = rs1.getString(8);
				date = rs1.getString(6);
			}

			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date datei = sdf1.parse(date);
			java.sql.Date sqlDate = new java.sql.Date(datei.getTime());

			if (rs3.next()) {

				String s = seats;
				String[] str = s.split("[,]");

				String cmd5 = "";

				if (stime.equals(" morning")) {

					for (String a : str) {
						if (a.equals("A1"))

						{

							cmd5 = "update morningseats set A1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A2"))

						{

							cmd5 = "update morningseats set A2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A3"))

						{

							cmd5 = "update morningseats set A3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A4"))

						{

							cmd5 = "update morningseats set A4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A5"))

						{

							cmd5 = "update morningseats set A5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A6"))

						{

							cmd5 = "update morningseats set A6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A7"))

						{

							cmd5 = "update morningseats set A7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A8"))

						{

							cmd5 = "update morningseats set A8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A9"))

						{

							cmd5 = "update morningseats set A9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A10"))

						{

							cmd5 = "update morningseats set A10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A11"))

						{

							cmd5 = "update morningseats set A11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A12"))

						{

							cmd5 = "update morningseats set A12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B1"))

						{

							cmd5 = "update morningseats set B1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B2"))

						{

							cmd5 = "update morningseats set B2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B3"))

						{

							cmd5 = "update morningseats set B3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B4"))

						{

							cmd5 = "update morningseats set B4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B5"))

						{

							cmd5 = "update morningseats set B5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B6"))

						{

							cmd5 = "update morningseats set B6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B7"))

						{

							cmd5 = "update morningseats set B7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B8"))

						{

							cmd5 = "update morningseats set B8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B9"))

						{

							cmd5 = "update morningseats set B9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B10"))

						{

							cmd5 = "update morningseats set B10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B11"))

						{

							cmd5 = "update morningseats set B11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B12"))

						{

							cmd5 = "update morningseats set B12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C1"))

						{

							cmd5 = "update morningseats set C1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C2"))

						{

							cmd5 = "update morningseats set C2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C3"))

						{

							cmd5 = "update morningseats set C3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C4"))

						{

							cmd5 = "update morningseats set C4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C5"))

						{

							cmd5 = "update morningseats set C5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C6"))

						{

							cmd5 = "update morningseats set C6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C7"))

						{

							cmd5 = "update morningseats set C7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C8"))

						{

							cmd5 = "update morningseats set C8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C9"))

						{

							cmd5 = "update morningseats set C9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C10"))

						{

							cmd5 = "update morningseats set C10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C11"))

						{

							cmd5 = "update morningseats set C11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C12"))

						{

							cmd5 = "update morningseats set C12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D1"))

						{

							cmd5 = "update morningseats set D1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D2"))

						{

							cmd5 = "update morningseats set D2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D3"))

						{

							cmd5 = "update morningseats set D3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D4"))

						{

							cmd5 = "update morningseats set D4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D5"))

						{

							cmd5 = "update morningseats set D5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D6"))

						{

							cmd5 = "update morningseats set D6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D7"))

						{

							cmd5 = "update morningseats set D7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D8"))

						{

							cmd5 = "update morningseats set D8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D9"))

						{

							cmd5 = "update morningseats set D9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D10"))

						{

							cmd5 = "update morningseats set D10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D11"))

						{

							cmd5 = "update morningseats set D11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D12"))

						{

							cmd5 = "update morningseats set D12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E1"))

						{

							cmd5 = "update morningseats set E1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E2"))

						{

							cmd5 = "update morningseats set E2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E3"))

						{

							cmd5 = "update morningseats set E3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E4"))

						{

							cmd5 = "update morningseats set E4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E5"))

						{

							cmd5 = "update morningseats set E5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E6"))

						{

							cmd5 = "update morningseats set E6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E7"))

						{

							cmd5 = "update morningseats set E7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E8"))

						{

							cmd5 = "update morningseats set E8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E9"))

						{

							cmd5 = "update morningseats set E9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E10"))

						{

							cmd5 = "update morningseats set E10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E11"))

						{

							cmd5 = "update morningseats set E11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E12"))

						{

							cmd5 = "update morningseats set E12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F1"))

						{

							cmd5 = "update morningseats set F1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F2"))

						{

							cmd5 = "update morningseats set F2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F3"))

						{

							cmd5 = "update morningseats set F3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F4"))

						{

							cmd5 = "update morningseats set F4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F5"))

						{

							cmd5 = "update morningseats set F5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F6"))

						{

							cmd5 = "update morningseats set F6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F7"))

						{

							cmd5 = "update morningseats set F7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F8"))

						{

							cmd5 = "update morningseats set F8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F9"))

						{

							cmd5 = "update morningseats set F9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F10"))

						{

							cmd5 = "update morningseats set F10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F11"))

						{

							cmd5 = "update morningseats set F11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F12"))

						{

							cmd5 = "update morningseats set F12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G1"))

						{

							cmd5 = "update morningseats set G1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G2"))

						{

							cmd5 = "update morningseats set G2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G3"))

						{

							cmd5 = "update morningseats set G3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G4"))

						{

							cmd5 = "update morningseats set G4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G5"))

						{

							cmd5 = "update morningseats set G5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G6"))

						{

							cmd5 = "update morningseats set G6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G7"))

						{

							cmd5 = "update morningseats set G7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G8"))

						{

							cmd5 = "update morningseats set G8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G9"))

						{

							cmd5 = "update morningseats set G9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G10"))

						{

							cmd5 = "update morningseats set G10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G11"))

						{

							cmd5 = "update morningseats set G11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G12"))

						{

							cmd5 = "update morningseats set G12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H1"))

						{

							cmd5 = "update morningseats set H1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H2"))

						{

							cmd5 = "update morningseats set H2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H3"))

						{

							cmd5 = "update morningseats set H3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H4"))

						{

							cmd5 = "update morningseats set H4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H5"))

						{

							cmd5 = "update morningseats set H5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H6"))

						{

							cmd5 = "update morningseats set H6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H7"))

						{

							cmd5 = "update morningseats set H7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H8"))

						{

							cmd5 = "update morningseats set H8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H9"))

						{

							cmd5 = "update morningseats set H9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H10"))

						{

							cmd5 = "update morningseats set H10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H11"))

						{

							cmd5 = "update morningseats set H11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H12"))

						{

							cmd5 = "update morningseats set H12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I1"))

						{

							cmd5 = "update morningseats set I1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I2"))

						{

							cmd5 = "update morningseats set I2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I3"))

						{

							cmd5 = "update morningseats set I3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I4"))

						{

							cmd5 = "update morningseats set I4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I5"))

						{

							cmd5 = "update morningseats set I5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I6"))

						{

							cmd5 = "update morningseats set I6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I7"))

						{

							cmd5 = "update morningseats set I7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I8"))

						{

							cmd5 = "update morningseats set I8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I9"))

						{

							cmd5 = "update morningseats set I9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I10"))

						{

							cmd5 = "update morningseats set I10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I11"))

						{

							cmd5 = "update morningseats set I11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I12"))

						{

							cmd5 = "update morningseats set I12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J1"))

						{

							cmd5 = "update morningseats set J1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J2"))

						{

							cmd5 = "update morningseats set J2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J3"))

						{

							cmd5 = "update morningseats set J3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J4"))

						{

							cmd5 = "update morningseats set J4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J5"))

						{

							cmd5 = "update morningseats set J5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J6"))

						{

							cmd5 = "update morningseats set J6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J7"))

						{

							cmd5 = "update morningseats set J7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J8"))

						{

							cmd5 = "update morningseats set J8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J9"))

						{

							cmd5 = "update morningseats set J9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J10"))

						{

							cmd5 = "update morningseats set J10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J11"))

						{

							cmd5 = "update morningseats set J11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J12"))

						{

							cmd5 = "update morningseats set J12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						PreparedStatement ps5 = con.prepareStatement(cmd5);
						ps5.setInt(1, mid);
						ps5.setDate(2, sqlDate);
						ps5.setInt(3, mxid);
						ps5.setInt(4, tid);
						ps5.executeUpdate();
					}
				} else if (stime.equals(" matinee")) {

					for (String a : str) {
						if (a.equals("A1"))

						{

							cmd5 = "update matineeseats set A1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A2"))

						{

							cmd5 = "update matineeseats set A2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A3"))

						{

							cmd5 = "update matineeseats set A3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A4"))

						{

							cmd5 = "update matineeseats set A4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A5"))

						{

							cmd5 = "update matineeseats set A5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A6"))

						{

							cmd5 = "update matineeseats set A6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A7"))

						{

							cmd5 = "update matineeseats set A7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A8"))

						{

							cmd5 = "update matineeseats set A8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A9"))

						{

							cmd5 = "update matineeseats set A9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A10"))

						{

							cmd5 = "update matineeseats set A10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A11"))

						{

							cmd5 = "update matineeseats set A11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A12"))

						{

							cmd5 = "update matineeseats set A12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B1"))

						{

							cmd5 = "update matineeseats set B1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B2"))

						{

							cmd5 = "update matineeseats set B2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B3"))

						{

							cmd5 = "update matineeseats set B3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B4"))

						{

							cmd5 = "update matineeseats set B4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B5"))

						{

							cmd5 = "update matineeseats set B5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B6"))

						{

							cmd5 = "update matineeseats set B6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B7"))

						{

							cmd5 = "update matineeseats set B7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B8"))

						{

							cmd5 = "update matineeseats set B8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B9"))

						{

							cmd5 = "update matineeseats set B9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B10"))

						{

							cmd5 = "update matineeseats set B10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B11"))

						{

							cmd5 = "update matineeseats set B11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B12"))

						{

							cmd5 = "update matineeseats set B12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C1"))

						{

							cmd5 = "update matineeseats set C1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C2"))

						{

							cmd5 = "update matineeseats set C2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C3"))

						{

							cmd5 = "update matineeseats set C3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C4"))

						{

							cmd5 = "update matineeseats set C4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C5"))

						{

							cmd5 = "update matineeseats set C5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C6"))

						{

							cmd5 = "update matineeseats set C6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C7"))

						{

							cmd5 = "update matineeseats set C7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C8"))

						{

							cmd5 = "update matineeseats set C8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C9"))

						{

							cmd5 = "update matineeseats set C9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C10"))

						{

							cmd5 = "update matineeseats set C10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C11"))

						{

							cmd5 = "update matineeseats set C11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C12"))

						{

							cmd5 = "update matineeseats set C12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D1"))

						{

							cmd5 = "update matineeseats set D1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D2"))

						{

							cmd5 = "update matineeseats set D2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D3"))

						{

							cmd5 = "update matineeseats set D3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D4"))

						{

							cmd5 = "update matineeseats set D4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D5"))

						{

							cmd5 = "update matineeseats set D5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D6"))

						{

							cmd5 = "update matineeseats set D6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D7"))

						{

							cmd5 = "update matineeseats set D7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D8"))

						{

							cmd5 = "update matineeseats set D8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D9"))

						{

							cmd5 = "update matineeseats set D9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D10"))

						{

							cmd5 = "update matineeseats set D10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D11"))

						{

							cmd5 = "update matineeseats set D11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D12"))

						{

							cmd5 = "update matineeseats set D12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E1"))

						{

							cmd5 = "update matineeseats set E1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E2"))

						{

							cmd5 = "update matineeseats set E2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E3"))

						{

							cmd5 = "update matineeseats set E3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E4"))

						{

							cmd5 = "update matineeseats set E4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E5"))

						{

							cmd5 = "update matineeseats set E5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E6"))

						{

							cmd5 = "update matineeseats set E6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E7"))

						{

							cmd5 = "update matineeseats set E7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E8"))

						{

							cmd5 = "update matineeseats set E8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E9"))

						{

							cmd5 = "update matineeseats set E9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E10"))

						{

							cmd5 = "update matineeseats set E10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E11"))

						{

							cmd5 = "update matineeseats set E11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E12"))

						{

							cmd5 = "update matineeseats set E12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F1"))

						{

							cmd5 = "update matineeseats set F1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F2"))

						{

							cmd5 = "update matineeseats set F2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F3"))

						{

							cmd5 = "update matineeseats set F3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F4"))

						{

							cmd5 = "update matineeseats set F4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F5"))

						{

							cmd5 = "update matineeseats set F5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F6"))

						{

							cmd5 = "update matineeseats set F6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F7"))

						{

							cmd5 = "update matineeseats set F7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F8"))

						{

							cmd5 = "update matineeseats set F8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F9"))

						{

							cmd5 = "update matineeseats set F9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F10"))

						{

							cmd5 = "update matineeseats set F10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F11"))

						{

							cmd5 = "update matineeseats set F11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F12"))

						{

							cmd5 = "update matineeseats set F12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G1"))

						{

							cmd5 = "update matineeseats set G1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G2"))

						{

							cmd5 = "update matineeseats set G2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G3"))

						{

							cmd5 = "update matineeseats set G3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G4"))

						{

							cmd5 = "update matineeseats set G4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G5"))

						{

							cmd5 = "update matineeseats set G5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G6"))

						{

							cmd5 = "update matineeseats set G6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G7"))

						{

							cmd5 = "update matineeseats set G7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G8"))

						{

							cmd5 = "update matineeseats set G8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G9"))

						{

							cmd5 = "update matineeseats set G9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G10"))

						{

							cmd5 = "update matineeseats set G10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G11"))

						{

							cmd5 = "update matineeseats set G11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G12"))

						{

							cmd5 = "update matineeseats set G12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H1"))

						{

							cmd5 = "update matineeseats set H1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H2"))

						{

							cmd5 = "update matineeseats set H2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H3"))

						{

							cmd5 = "update matineeseats set H3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H4"))

						{

							cmd5 = "update matineeseats set H4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H5"))

						{

							cmd5 = "update matineeseats set H5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H6"))

						{

							cmd5 = "update matineeseats set H6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H7"))

						{

							cmd5 = "update matineeseats set H7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H8"))

						{

							cmd5 = "update matineeseats set H8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H9"))

						{

							cmd5 = "update matineeseats set H9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H10"))

						{

							cmd5 = "update matineeseats set H10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H11"))

						{

							cmd5 = "update matineeseats set H11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H12"))

						{

							cmd5 = "update matineeseats set H12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I1"))

						{

							cmd5 = "update matineeseats set I1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I2"))

						{

							cmd5 = "update matineeseats set I2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I3"))

						{

							cmd5 = "update matineeseats set I3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I4"))

						{

							cmd5 = "update matineeseats set I4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I5"))

						{

							cmd5 = "update matineeseats set I5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I6"))

						{

							cmd5 = "update matineeseats set I6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I7"))

						{

							cmd5 = "update matineeseats set I7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I8"))

						{

							cmd5 = "update matineeseats set I8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I9"))

						{

							cmd5 = "update matineeseats set I9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I10"))

						{

							cmd5 = "update matineeseats set I10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I11"))

						{

							cmd5 = "update matineeseats set I11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I12"))

						{

							cmd5 = "update matineeseats set I12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J1"))

						{

							cmd5 = "update matineeseats set J1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J2"))

						{

							cmd5 = "update matineeseats set J2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J3"))

						{

							cmd5 = "update matineeseats set J3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J4"))

						{

							cmd5 = "update matineeseats set J4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J5"))

						{

							cmd5 = "update matineeseats set J5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J6"))

						{

							cmd5 = "update matineeseats set J6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J7"))

						{

							cmd5 = "update matineeseats set J7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J8"))

						{

							cmd5 = "update matineeseats set J8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J9"))

						{

							cmd5 = "update matineeseats set J9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J10"))

						{

							cmd5 = "update matineeseats set J10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J11"))

						{

							cmd5 = "update matineeseats set J11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J12"))

						{

							cmd5 = "update matineeseats set J12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						PreparedStatement ps5 = con.prepareStatement(cmd5);
						ps5.setInt(1, mid);
						ps5.setDate(2, sqlDate);
						ps5.setInt(3, mxid);
						ps5.setInt(4, tid);
						ps5.executeUpdate();
					}
				} else if (stime.equals(" secondshow")) {

					for (String a : str) {
						if (a.equals("A1"))

						{

							cmd5 = "update secondshowseats set A1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A2"))

						{

							cmd5 = "update secondshowseats set A2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A3"))

						{

							cmd5 = "update secondshowseats set A3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A4"))

						{

							cmd5 = "update secondshowseats set A4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A5"))

						{

							cmd5 = "update secondshowseats set A5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A6"))

						{

							cmd5 = "update secondshowseats set A6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A7"))

						{

							cmd5 = "update secondshowseats set A7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A8"))

						{

							cmd5 = "update secondshowseats set A8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A9"))

						{

							cmd5 = "update secondshowseats set A9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A10"))

						{

							cmd5 = "update secondshowseats set A10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A11"))

						{

							cmd5 = "update secondshowseats set A11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("A12"))

						{

							cmd5 = "update secondshowseats set A12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B1"))

						{

							cmd5 = "update secondshowseats set B1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B2"))

						{

							cmd5 = "update secondshowseats set B2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B3"))

						{

							cmd5 = "update secondshowseats set B3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B4"))

						{

							cmd5 = "update secondshowseats set B4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B5"))

						{

							cmd5 = "update secondshowseats set B5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B6"))

						{

							cmd5 = "update secondshowseats set B6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B7"))

						{

							cmd5 = "update secondshowseats set B7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B8"))

						{

							cmd5 = "update secondshowseats set B8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B9"))

						{

							cmd5 = "update secondshowseats set B9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B10"))

						{

							cmd5 = "update secondshowseats set B10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B11"))

						{

							cmd5 = "update secondshowseats set B11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("B12"))

						{

							cmd5 = "update secondshowseats set B12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C1"))

						{

							cmd5 = "update secondshowseats set C1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C2"))

						{

							cmd5 = "update secondshowseats set C2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C3"))

						{

							cmd5 = "update secondshowseats set C3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C4"))

						{

							cmd5 = "update secondshowseats set C4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C5"))

						{

							cmd5 = "update secondshowseats set C5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C6"))

						{

							cmd5 = "update secondshowseats set C6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C7"))

						{

							cmd5 = "update secondshowseats set C7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C8"))

						{

							cmd5 = "update secondshowseats set C8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C9"))

						{

							cmd5 = "update secondshowseats set C9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C10"))

						{

							cmd5 = "update secondshowseats set C10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C11"))

						{

							cmd5 = "update secondshowseats set C11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("C12"))

						{

							cmd5 = "update secondshowseats set C12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D1"))

						{

							cmd5 = "update secondshowseats set D1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D2"))

						{

							cmd5 = "update secondshowseats set D2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D3"))

						{

							cmd5 = "update secondshowseats set D3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D4"))

						{

							cmd5 = "update secondshowseats set D4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D5"))

						{

							cmd5 = "update secondshowseats set D5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D6"))

						{

							cmd5 = "update secondshowseats set D6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D7"))

						{

							cmd5 = "update secondshowseats set D7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D8"))

						{

							cmd5 = "update secondshowseats set D8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D9"))

						{

							cmd5 = "update secondshowseats set D9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D10"))

						{

							cmd5 = "update secondshowseats set D10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D11"))

						{

							cmd5 = "update secondshowseats set D11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("D12"))

						{

							cmd5 = "update secondshowseats set D12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E1"))

						{

							cmd5 = "update secondshowseats set E1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E2"))

						{

							cmd5 = "update secondshowseats set E2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E3"))

						{

							cmd5 = "update secondshowseats set E3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E4"))

						{

							cmd5 = "update secondshowseats set E4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E5"))

						{

							cmd5 = "update secondshowseats set E5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E6"))

						{

							cmd5 = "update secondshowseats set E6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E7"))

						{

							cmd5 = "update secondshowseats set E7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E8"))

						{

							cmd5 = "update secondshowseats set E8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E9"))

						{

							cmd5 = "update secondshowseats set E9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E10"))

						{

							cmd5 = "update secondshowseats set E10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E11"))

						{

							cmd5 = "update secondshowseats set E11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("E12"))

						{

							cmd5 = "update secondshowseats set E12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F1"))

						{

							cmd5 = "update secondshowseats set F1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F2"))

						{

							cmd5 = "update secondshowseats set F2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F3"))

						{

							cmd5 = "update secondshowseats set F3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F4"))

						{

							cmd5 = "update secondshowseats set F4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F5"))

						{

							cmd5 = "update secondshowseats set F5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F6"))

						{

							cmd5 = "update secondshowseats set F6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F7"))

						{

							cmd5 = "update secondshowseats set F7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F8"))

						{

							cmd5 = "update secondshowseats set F8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F9"))

						{

							cmd5 = "update secondshowseats set F9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F10"))

						{

							cmd5 = "update secondshowseats set F10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F11"))

						{

							cmd5 = "update secondshowseats set F11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("F12"))

						{

							cmd5 = "update secondshowseats set F12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G1"))

						{

							cmd5 = "update secondshowseats set G1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G2"))

						{

							cmd5 = "update secondshowseats set G2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G3"))

						{

							cmd5 = "update secondshowseats set G3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G4"))

						{

							cmd5 = "update secondshowseats set G4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G5"))

						{

							cmd5 = "update secondshowseats set G5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G6"))

						{

							cmd5 = "update secondshowseats set G6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G7"))

						{

							cmd5 = "update secondshowseats set G7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G8"))

						{

							cmd5 = "update secondshowseats set G8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G9"))

						{

							cmd5 = "update secondshowseats set G9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G10"))

						{

							cmd5 = "update secondshowseats set G10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G11"))

						{

							cmd5 = "update secondshowseats set G11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("G12"))

						{

							cmd5 = "update secondshowseats set G12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H1"))

						{

							cmd5 = "update secondshowseats set H1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H2"))

						{

							cmd5 = "update secondshowseats set H2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H3"))

						{

							cmd5 = "update secondshowseats set H3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H4"))

						{

							cmd5 = "update secondshowseats set H4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H5"))

						{

							cmd5 = "update secondshowseats set H5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H6"))

						{

							cmd5 = "update secondshowseats set H6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H7"))

						{

							cmd5 = "update secondshowseats set H7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H8"))

						{

							cmd5 = "update secondshowseats set H8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H9"))

						{

							cmd5 = "update secondshowseats set H9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H10"))

						{

							cmd5 = "update secondshowseats set H10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H11"))

						{

							cmd5 = "update secondshowseats set H11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("H12"))

						{

							cmd5 = "update secondshowseats set H12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I1"))

						{

							cmd5 = "update secondshowseats set I1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I2"))

						{

							cmd5 = "update secondshowseats set I2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I3"))

						{

							cmd5 = "update secondshowseats set I3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I4"))

						{

							cmd5 = "update secondshowseats set I4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I5"))

						{

							cmd5 = "update secondshowseats set I5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I6"))

						{

							cmd5 = "update secondshowseats set I6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I7"))

						{

							cmd5 = "update secondshowseats set I7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I8"))

						{

							cmd5 = "update secondshowseats set I8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I9"))

						{

							cmd5 = "update secondshowseats set I9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I10"))

						{

							cmd5 = "update secondshowseats set I10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I11"))

						{

							cmd5 = "update secondshowseats set I11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("I12"))

						{

							cmd5 = "update secondshowseats set I12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J1"))

						{

							cmd5 = "update secondshowseats set J1=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J2"))

						{

							cmd5 = "update secondshowseats set J2=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J3"))

						{

							cmd5 = "update secondshowseats set J3=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J4"))

						{

							cmd5 = "update secondshowseats set J4=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J5"))

						{

							cmd5 = "update secondshowseats set J5=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J6"))

						{

							cmd5 = "update secondshowseats set J6=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J7"))

						{

							cmd5 = "update secondshowseats set J7=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J8"))

						{

							cmd5 = "update secondshowseats set J8=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J9"))

						{

							cmd5 = "update secondshowseats set J9=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J10"))

						{

							cmd5 = "update secondshowseats set J10=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J11"))

						{

							cmd5 = "update secondshowseats set J11=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						else if (a.equals("J12"))

						{

							cmd5 = "update secondshowseats set J12=1 where (movieId=? and showdate=? and multiplexId=? and tId=?)";

						}

						PreparedStatement ps5 = con.prepareStatement(cmd5);
						ps5.setInt(1, mid);
						ps5.setDate(2, sqlDate);
						ps5.setInt(3, mxid);
						ps5.setInt(4, tid);
						ps5.executeUpdate();
					}
				}

				String cmd6 = "delete from booking  where bid=?";
				PreparedStatement ps6 = con.prepareStatement(cmd6);
				ps6.setInt(1, id);
				ps6.executeUpdate();

				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {

			e.getStackTrace();
		}
		return false;
	}

	public ArrayList<Ticket> ShowTicket(int custid) {
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Ticket> al = new ArrayList<Ticket>();
			String cmd1 = "select * from booking  where custid=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, custid);
			ResultSet rs3 = ps1.executeQuery();

			if (rs3.next()) {

				String cmd2 = "select * from booking where custId=?";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, custid);
				ResultSet rs1 = ps2.executeQuery();

				int bid = 0;
				int cid = 0;
				int tid = 0;
				int mid = 0;
				int mxid = 0;
				int screen = 0;
				String sdate = "";
				String date = "";
				String showt = "";
				String seats = "";

				String img = "";
				String mname = "";
				String cen = "";
				String lang = "";
				String dur = "";
				String cat = "";

				while (rs1.next()) {
					bid = rs1.getInt(1);
					cid = rs1.getInt(2);
					tid = rs1.getInt(3);

					mxid = rs1.getInt(4);
					mid = rs1.getInt(5);
					sdate = rs1.getString(6);
					showt = rs1.getString(7);
					seats = rs1.getString(8);
					screen = rs1.getInt(10);

					System.out.println(mxid + "" + mxid);
					String cmd3 = "select * from movie where movieId=?";
					PreparedStatement ps3 = con.prepareStatement(cmd3);
					ps3.setInt(1, mid);
					ResultSet rs2 = ps3.executeQuery();

					while (rs2.next()) {

						mname = rs2.getString(2);
						cat = rs2.getString(3);
						lang = rs2.getString(4);
						dur = rs2.getString(5);
						cen = rs2.getString(7);
						img = rs2.getString(11);
					}

					String cmd4 = "SELECT date_format(showdate, \"%M %D %Y\") as date from booking where (movieId=? and bid=? and multiplexId=?)";
					PreparedStatement ps4 = con.prepareStatement(cmd4);
					ps4.setInt(1, mid);
					ps4.setInt(2, bid);
					ps4.setInt(3, mxid);
					ResultSet rs4 = ps4.executeQuery();

					while (rs4.next()) {
						date = rs4.getString(1);
					}

					String mxname = "";
					String loc = "";
					int lid = 0;
					String cmd6 = "select multiplexName,locId from multiplex where multiplexId=?";
					PreparedStatement ps6 = con.prepareStatement(cmd6);
					ps6.setInt(1, mxid);
					ResultSet rs6 = ps6.executeQuery();
					while (rs6.next()) {
						mxname = rs6.getString(1);
						lid = rs6.getInt(2);
					}
					System.out.println(mxid);
					System.out.println(mxname);
					System.out.println("check1");

					String cmd9 = "select location from location where locId=?";
					PreparedStatement ps9 = con.prepareStatement(cmd9);
					ps9.setInt(1, lid);
					ResultSet rs9 = ps9.executeQuery();
					while (rs9.next()) {
						loc = rs9.getString(1);
					}
					System.out.println("check2");

					String time = "";
					String cmd5 = "";

					if (showt.equals(" morning")) {
						cmd5 = "select showtime from morningseats where movieId= ? and tId=? and showdate=?";
					} else if (showt.equals(" matinee")) {
						cmd5 = "select showtime  from matineeseats where movieId= ? and tId=? and showdate=?";
					} else if (showt.equals(" secondshow")) {
						cmd5 = "select showtime  from secondshowseats where movieId= ? and tId=? and showdate=?";
					}

					PreparedStatement ps5 = con.prepareStatement(cmd5);
					ps5.setInt(1, mid);
					ps5.setInt(2, tid);

					SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
					java.util.Date datei = sdf1.parse(sdate);
					java.sql.Date sqlDate = new java.sql.Date(datei.getTime());

					ps5.setDate(3, sqlDate);
					ResultSet rs5 = ps5.executeQuery();
					System.out.println("check3");
					while (rs5.next()) {
						time = rs5.getString(1);
					}

					Ticket l = new Ticket(bid, cid, mxid, img, mname, cen, lang, dur, cat, mxname, loc, date, time,
							seats, screen);
					al.add(l);
				}

				return al;
			}

			else {
				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
			return null;
		}

	}

	public ArrayList<Booking> getBookings() {
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Booking> al = new ArrayList<Booking>();
			String cmd1 = "select * from booking";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ResultSet rs3 = ps1.executeQuery();
			while (rs3.next()) {
				int bid = rs3.getInt(1);
				int cid = rs3.getInt(2);
				int tid = rs3.getInt(3);
				int mxid = rs3.getInt(4);

				int mid = rs3.getInt(5);
				String date = rs3.getString(6);
				String time = rs3.getString(7);
				String seats = rs3.getString(8);
				String phone = rs3.getString(9);
				int screen = rs3.getInt(10);
				Booking l = new Booking(bid, cid, tid, mxid, mid, date, time, seats, phone, screen);
				al.add(l);
			}

			if (al.size() != 0) {

				return al;
			}

			else {
				return null;
			}

		} catch (Exception e) {

			e.getStackTrace();
			return null;
		}

	}

	public ArrayList<Booking> SearchBookingCid(int id) {
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Booking> al = new ArrayList<Booking>();
			String cmd2 = "select * from booking where custId=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, id);
			ResultSet rs2 = ps2.executeQuery();

			if (rs2.next()) {

				String cmd1 = "select * from booking where custId=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, id);
				ResultSet rs3 = ps1.executeQuery();
				while (rs3.next()) {
					int bid = rs3.getInt(1);
					int cid = rs3.getInt(2);
					int tid = rs3.getInt(3);
					int mxid = rs3.getInt(4);

					int mid = rs3.getInt(5);
					String date = rs3.getString(6);
					String time = rs3.getString(7);
					String seats = rs3.getString(8);
					String phone = rs3.getString(9);
					int screen = rs3.getInt(10);
					Booking l = new Booking(bid, cid, tid, mxid, mid, date, time, seats, phone, screen);
					al.add(l);
				}

				if (al.size() != 0) {

					return al;
				}

				else {
					return null;
				}

			} else {
				return null;
			}

		} catch (Exception e) {

			e.getStackTrace();
			return null;
		}

	}

	public ArrayList<Booking> SearchBookingBid(int id) {
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Booking> al = new ArrayList<Booking>();
			String cmd2 = "select * from booking where bid=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, id);
			ResultSet rs2 = ps2.executeQuery();

			if (rs2.next()) {

				String cmd1 = "select * from booking where bid=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, id);
				ResultSet rs3 = ps1.executeQuery();
				while (rs3.next()) {
					int bid = rs3.getInt(1);
					int cid = rs3.getInt(2);
					int tid = rs3.getInt(3);
					int mxid = rs3.getInt(4);

					int mid = rs3.getInt(5);
					String date = rs3.getString(6);
					String time = rs3.getString(7);
					String seats = rs3.getString(8);
					String phone = rs3.getString(9);
					int screen = rs3.getInt(10);
					Booking l = new Booking(bid, cid, tid, mxid, mid, date, time, seats, phone, screen);
					al.add(l);
				}

				if (al.size() != 0) {

					return al;
				}

				else {
					return null;
				}

			} else {
				return null;
			}

		} catch (Exception e) {

			e.getStackTrace();
			return null;
		}

	}

	public ArrayList<Booking> SearchBookingMid(int id) {
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Booking> al = new ArrayList<Booking>();
			String cmd2 = "select * from booking where movieId=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, id);
			ResultSet rs2 = ps2.executeQuery();

			if (rs2.next()) {

				String cmd1 = "select * from booking where movieId=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, id);
				ResultSet rs3 = ps1.executeQuery();
				while (rs3.next()) {
					int bid = rs3.getInt(1);
					int cid = rs3.getInt(2);
					int tid = rs3.getInt(3);
					int mxid = rs3.getInt(4);

					int mid = rs3.getInt(5);
					String date = rs3.getString(6);
					String time = rs3.getString(7);
					String seats = rs3.getString(8);
					String phone = rs3.getString(9);
					int screen = rs3.getInt(10);
					Booking l = new Booking(bid, cid, tid, mxid, mid, date, time, seats, phone, screen);
					al.add(l);
				}

				if (al.size() != 0) {

					return al;
				}

				else {
					return null;
				}

			} else {
				return null;
			}

		} catch (Exception e) {

			e.getStackTrace();
			return null;
		}

	}

	public ArrayList<Booking> SearchBookingMxid(int id) {
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Booking> al = new ArrayList<Booking>();
			String cmd2 = "select * from booking where multiplexId=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, id);
			ResultSet rs2 = ps2.executeQuery();

			if (rs2.next()) {

				String cmd1 = "select * from booking where multiplexId=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, id);
				ResultSet rs3 = ps1.executeQuery();
				while (rs3.next()) {
					int bid = rs3.getInt(1);
					int cid = rs3.getInt(2);
					int tid = rs3.getInt(3);
					int mxid = rs3.getInt(4);

					int mid = rs3.getInt(5);
					String date = rs3.getString(6);
					String time = rs3.getString(7);
					String seats = rs3.getString(8);
					String phone = rs3.getString(9);

					int screen = rs3.getInt(10);
					Booking l = new Booking(bid, cid, tid, mxid, mid, date, time, seats, phone, screen);
					al.add(l);
				}

				if (al.size() != 0) {

					return al;
				}

				else {
					return null;
				}

			} else {
				return null;
			}

		} catch (Exception e) {

			e.getStackTrace();
			return null;
		}

	}

	public ArrayList<Seats> getMorningSeats(String date, int tid) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Seats> al = new ArrayList<Seats>();

			String cmd2 = "select * from morningseats where tId=? and showdate=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, tid);

			String mdate = date;
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date datei = sdf1.parse(mdate);
			java.sql.Date sqlDate = new java.sql.Date(datei.getTime());

			ps2.setDate(2, sqlDate);

			ResultSet rs2 = ps2.executeQuery();

			if (rs2.next()) {

				String cmd1 = "select * from morningseats where tId=? and showdate=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, tid);
				ps1.setDate(2, sqlDate);

				ResultSet rs3 = ps1.executeQuery();
				while (rs3.next()) {

					int movieId = rs3.getInt(2);
					int multiplexId = rs3.getInt(3);
					String showdate = rs3.getString(4);
					String showtime = rs3.getString(5);
					int A1 = rs3.getInt(6);
					int A2 = rs3.getInt(7);
					int A3 = rs3.getInt(8);
					int A4 = rs3.getInt(9);
					int A5 = rs3.getInt(10);
					int A6 = rs3.getInt(11);
					int A7 = rs3.getInt(12);
					int A8 = rs3.getInt(13);
					int A9 = rs3.getInt(14);
					int A10 = rs3.getInt(15);
					int A11 = rs3.getInt(16);
					int A12 = rs3.getInt(17);
					int B1 = rs3.getInt(18);
					int B2 = rs3.getInt(19);
					int B3 = rs3.getInt(20);
					int B4 = rs3.getInt(21);
					int B5 = rs3.getInt(22);
					int B6 = rs3.getInt(23);
					int B7 = rs3.getInt(24);
					int B8 = rs3.getInt(25);
					int B9 = rs3.getInt(26);
					int B10 = rs3.getInt(27);
					int B11 = rs3.getInt(28);
					int B12 = rs3.getInt(29);
					int C1 = rs3.getInt(30);
					int C2 = rs3.getInt(31);
					int C3 = rs3.getInt(32);
					int C4 = rs3.getInt(33);
					int C5 = rs3.getInt(34);
					int C6 = rs3.getInt(35);
					int C7 = rs3.getInt(36);
					int C8 = rs3.getInt(37);
					int C9 = rs3.getInt(38);
					int C10 = rs3.getInt(39);
					int C11 = rs3.getInt(40);
					int C12 = rs3.getInt(41);
					int D1 = rs3.getInt(42);
					int D2 = rs3.getInt(43);
					int D3 = rs3.getInt(44);
					int D4 = rs3.getInt(45);
					int D5 = rs3.getInt(46);
					int D6 = rs3.getInt(47);
					int D7 = rs3.getInt(48);
					int D8 = rs3.getInt(49);
					int D9 = rs3.getInt(50);
					int D10 = rs3.getInt(51);
					int D11 = rs3.getInt(52);
					int D12 = rs3.getInt(53);
					int E1 = rs3.getInt(54);
					int E2 = rs3.getInt(55);
					int E3 = rs3.getInt(56);
					int E4 = rs3.getInt(57);
					int E5 = rs3.getInt(58);
					int E6 = rs3.getInt(59);
					int E7 = rs3.getInt(60);
					int E8 = rs3.getInt(61);
					int E9 = rs3.getInt(62);
					int E10 = rs3.getInt(63);
					int E11 = rs3.getInt(64);
					int E12 = rs3.getInt(65);
					int F1 = rs3.getInt(66);
					int F2 = rs3.getInt(67);
					int F3 = rs3.getInt(68);
					int F4 = rs3.getInt(69);
					int F5 = rs3.getInt(70);
					int F6 = rs3.getInt(71);
					int F7 = rs3.getInt(72);
					int F8 = rs3.getInt(73);
					int F9 = rs3.getInt(74);
					int F10 = rs3.getInt(75);
					int F11 = rs3.getInt(76);
					int F12 = rs3.getInt(77);
					int G1 = rs3.getInt(78);
					int G2 = rs3.getInt(79);
					int G3 = rs3.getInt(80);
					int G4 = rs3.getInt(81);
					int G5 = rs3.getInt(82);
					int G6 = rs3.getInt(83);
					int G7 = rs3.getInt(84);
					int G8 = rs3.getInt(85);
					int G9 = rs3.getInt(86);
					int G10 = rs3.getInt(87);
					int G11 = rs3.getInt(88);
					int G12 = rs3.getInt(89);
					int H1 = rs3.getInt(90);
					int H2 = rs3.getInt(91);
					int H3 = rs3.getInt(92);
					int H4 = rs3.getInt(93);
					int H5 = rs3.getInt(94);
					int H6 = rs3.getInt(95);
					int H7 = rs3.getInt(96);
					int H8 = rs3.getInt(97);
					int H9 = rs3.getInt(98);
					int H10 = rs3.getInt(99);
					int H11 = rs3.getInt(100);
					int H12 = rs3.getInt(101);
					int I1 = rs3.getInt(102);
					int I2 = rs3.getInt(103);
					int I3 = rs3.getInt(104);
					int I4 = rs3.getInt(105);
					int I5 = rs3.getInt(106);
					int I6 = rs3.getInt(107);
					int I7 = rs3.getInt(108);
					int I8 = rs3.getInt(109);
					int I9 = rs3.getInt(110);
					int I10 = rs3.getInt(111);
					int I11 = rs3.getInt(112);
					int I12 = rs3.getInt(113);
					int J1 = rs3.getInt(114);
					int J2 = rs3.getInt(115);
					int J3 = rs3.getInt(116);
					int J4 = rs3.getInt(117);
					int J5 = rs3.getInt(118);
					int J6 = rs3.getInt(119);
					int J7 = rs3.getInt(120);
					int J8 = rs3.getInt(121);
					int J9 = rs3.getInt(122);
					int J10 = rs3.getInt(123);
					int J11 = rs3.getInt(124);
					int J12 = rs3.getInt(125);

					Seats l = new Seats(movieId, multiplexId, showdate, showtime, A1, A2, A3, A4, A5, A6, A7, A8, A9,
							A10, A11, A12, B1, B2, B3, B4, B5, B6, B7, B8, B9, B10, B11, B12, C1, C2, C3, C4, C5, C6,
							C7, C8, C9, C10, C11, C12, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, E1, E2, E3,
							E4, E5, E6, E7, E8, E9, E10, E11, E12, F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
							G1, G2, G3, G4, G5, G6, G7, G8, G9, G10, G11, G12, H1, H2, H3, H4, H5, H6, H7, H8, H9, H10,
							H11, H12, I1, I2, I3, I4, I5, I6, I7, I8, I9, I10, I11, I12, J1, J2, J3, J4, J5, J6, J7, J8,
							J9, J10, J11, J12);
					System.out.println(l);
					al.add(l);
				}

				if (al.size() != 0) {
					System.out.println(al);
					return al;
				}

				else {
					return null;
				}

			} else {
				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
			return null;
		}

	}

	public ArrayList<Seats> getMatineeSeats(String date, int tid) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Seats> al = new ArrayList<Seats>();

			String cmd2 = "select * from matineeseats where tId=? and showdate=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, tid);

			String mdate = date;
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date datei = sdf1.parse(mdate);
			java.sql.Date sqlDate = new java.sql.Date(datei.getTime());

			ps2.setDate(2, sqlDate);

			ResultSet rs2 = ps2.executeQuery();

			if (rs2.next()) {

				String cmd1 = "select * from matineeseats where tId=? and showdate=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, tid);
				ps1.setDate(2, sqlDate);

				ResultSet rs3 = ps1.executeQuery();
				while (rs3.next()) {

					int movieId = rs3.getInt(2);
					int multiplexId = rs3.getInt(3);
					String showdate = rs3.getString(4);
					String showtime = rs3.getString(5);
					int A1 = rs3.getInt(6);
					int A2 = rs3.getInt(7);
					int A3 = rs3.getInt(8);
					int A4 = rs3.getInt(9);
					int A5 = rs3.getInt(10);
					int A6 = rs3.getInt(11);
					int A7 = rs3.getInt(12);
					int A8 = rs3.getInt(13);
					int A9 = rs3.getInt(14);
					int A10 = rs3.getInt(15);
					int A11 = rs3.getInt(16);
					int A12 = rs3.getInt(17);
					int B1 = rs3.getInt(18);
					int B2 = rs3.getInt(19);
					int B3 = rs3.getInt(20);
					int B4 = rs3.getInt(21);
					int B5 = rs3.getInt(22);
					int B6 = rs3.getInt(23);
					int B7 = rs3.getInt(24);
					int B8 = rs3.getInt(25);
					int B9 = rs3.getInt(26);
					int B10 = rs3.getInt(27);
					int B11 = rs3.getInt(28);
					int B12 = rs3.getInt(29);
					int C1 = rs3.getInt(30);
					int C2 = rs3.getInt(31);
					int C3 = rs3.getInt(32);
					int C4 = rs3.getInt(33);
					int C5 = rs3.getInt(34);
					int C6 = rs3.getInt(35);
					int C7 = rs3.getInt(36);
					int C8 = rs3.getInt(37);
					int C9 = rs3.getInt(38);
					int C10 = rs3.getInt(39);
					int C11 = rs3.getInt(40);
					int C12 = rs3.getInt(41);
					int D1 = rs3.getInt(42);
					int D2 = rs3.getInt(43);
					int D3 = rs3.getInt(44);
					int D4 = rs3.getInt(45);
					int D5 = rs3.getInt(46);
					int D6 = rs3.getInt(47);
					int D7 = rs3.getInt(48);
					int D8 = rs3.getInt(49);
					int D9 = rs3.getInt(50);
					int D10 = rs3.getInt(51);
					int D11 = rs3.getInt(52);
					int D12 = rs3.getInt(53);
					int E1 = rs3.getInt(54);
					int E2 = rs3.getInt(55);
					int E3 = rs3.getInt(56);
					int E4 = rs3.getInt(57);
					int E5 = rs3.getInt(58);
					int E6 = rs3.getInt(59);
					int E7 = rs3.getInt(60);
					int E8 = rs3.getInt(61);
					int E9 = rs3.getInt(62);
					int E10 = rs3.getInt(63);
					int E11 = rs3.getInt(64);
					int E12 = rs3.getInt(65);
					int F1 = rs3.getInt(66);
					int F2 = rs3.getInt(67);
					int F3 = rs3.getInt(68);
					int F4 = rs3.getInt(69);
					int F5 = rs3.getInt(70);
					int F6 = rs3.getInt(71);
					int F7 = rs3.getInt(72);
					int F8 = rs3.getInt(73);
					int F9 = rs3.getInt(74);
					int F10 = rs3.getInt(75);
					int F11 = rs3.getInt(76);
					int F12 = rs3.getInt(77);
					int G1 = rs3.getInt(78);
					int G2 = rs3.getInt(79);
					int G3 = rs3.getInt(80);
					int G4 = rs3.getInt(81);
					int G5 = rs3.getInt(82);
					int G6 = rs3.getInt(83);
					int G7 = rs3.getInt(84);
					int G8 = rs3.getInt(85);
					int G9 = rs3.getInt(86);
					int G10 = rs3.getInt(87);
					int G11 = rs3.getInt(88);
					int G12 = rs3.getInt(89);
					int H1 = rs3.getInt(90);
					int H2 = rs3.getInt(91);
					int H3 = rs3.getInt(92);
					int H4 = rs3.getInt(93);
					int H5 = rs3.getInt(94);
					int H6 = rs3.getInt(95);
					int H7 = rs3.getInt(96);
					int H8 = rs3.getInt(97);
					int H9 = rs3.getInt(98);
					int H10 = rs3.getInt(99);
					int H11 = rs3.getInt(100);
					int H12 = rs3.getInt(101);
					int I1 = rs3.getInt(102);
					int I2 = rs3.getInt(103);
					int I3 = rs3.getInt(104);
					int I4 = rs3.getInt(105);
					int I5 = rs3.getInt(106);
					int I6 = rs3.getInt(107);
					int I7 = rs3.getInt(108);
					int I8 = rs3.getInt(109);
					int I9 = rs3.getInt(110);
					int I10 = rs3.getInt(111);
					int I11 = rs3.getInt(112);
					int I12 = rs3.getInt(113);
					int J1 = rs3.getInt(114);
					int J2 = rs3.getInt(115);
					int J3 = rs3.getInt(116);
					int J4 = rs3.getInt(117);
					int J5 = rs3.getInt(118);
					int J6 = rs3.getInt(119);
					int J7 = rs3.getInt(120);
					int J8 = rs3.getInt(121);
					int J9 = rs3.getInt(122);
					int J10 = rs3.getInt(123);
					int J11 = rs3.getInt(124);
					int J12 = rs3.getInt(125);

					Seats l = new Seats(movieId, multiplexId, showdate, showtime, A1, A2, A3, A4, A5, A6, A7, A8, A9,
							A10, A11, A12, B1, B2, B3, B4, B5, B6, B7, B8, B9, B10, B11, B12, C1, C2, C3, C4, C5, C6,
							C7, C8, C9, C10, C11, C12, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, E1, E2, E3,
							E4, E5, E6, E7, E8, E9, E10, E11, E12, F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
							G1, G2, G3, G4, G5, G6, G7, G8, G9, G10, G11, G12, H1, H2, H3, H4, H5, H6, H7, H8, H9, H10,
							H11, H12, I1, I2, I3, I4, I5, I6, I7, I8, I9, I10, I11, I12, J1, J2, J3, J4, J5, J6, J7, J8,
							J9, J10, J11, J12);
					System.out.println(l);
					al.add(l);
				}

				if (al.size() != 0) {
					System.out.println(al);
					return al;
				}

				else {
					return null;
				}

			} else {
				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
			return null;
		}

	}

	public ArrayList<Seats> getSecondShowSeats(String date, int tid) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Seats> al = new ArrayList<Seats>();

			String cmd2 = "select * from secondshowseats where tId=? and showdate=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, tid);

			String mdate = date;
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date datei = sdf1.parse(mdate);
			java.sql.Date sqlDate = new java.sql.Date(datei.getTime());

			ps2.setDate(2, sqlDate);

			ResultSet rs2 = ps2.executeQuery();

			if (rs2.next()) {

				String cmd1 = "select * from secondshowseats where tId=? and showdate=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, tid);
				ps1.setDate(2, sqlDate);

				ResultSet rs3 = ps1.executeQuery();
				while (rs3.next()) {

					int movieId = rs3.getInt(2);
					int multiplexId = rs3.getInt(3);
					String showdate = rs3.getString(4);
					String showtime = rs3.getString(5);
					int A1 = rs3.getInt(6);
					int A2 = rs3.getInt(7);
					int A3 = rs3.getInt(8);
					int A4 = rs3.getInt(9);
					int A5 = rs3.getInt(10);
					int A6 = rs3.getInt(11);
					int A7 = rs3.getInt(12);
					int A8 = rs3.getInt(13);
					int A9 = rs3.getInt(14);
					int A10 = rs3.getInt(15);
					int A11 = rs3.getInt(16);
					int A12 = rs3.getInt(17);
					int B1 = rs3.getInt(18);
					int B2 = rs3.getInt(19);
					int B3 = rs3.getInt(20);
					int B4 = rs3.getInt(21);
					int B5 = rs3.getInt(22);
					int B6 = rs3.getInt(23);
					int B7 = rs3.getInt(24);
					int B8 = rs3.getInt(25);
					int B9 = rs3.getInt(26);
					int B10 = rs3.getInt(27);
					int B11 = rs3.getInt(28);
					int B12 = rs3.getInt(29);
					int C1 = rs3.getInt(30);
					int C2 = rs3.getInt(31);
					int C3 = rs3.getInt(32);
					int C4 = rs3.getInt(33);
					int C5 = rs3.getInt(34);
					int C6 = rs3.getInt(35);
					int C7 = rs3.getInt(36);
					int C8 = rs3.getInt(37);
					int C9 = rs3.getInt(38);
					int C10 = rs3.getInt(39);
					int C11 = rs3.getInt(40);
					int C12 = rs3.getInt(41);
					int D1 = rs3.getInt(42);
					int D2 = rs3.getInt(43);
					int D3 = rs3.getInt(44);
					int D4 = rs3.getInt(45);
					int D5 = rs3.getInt(46);
					int D6 = rs3.getInt(47);
					int D7 = rs3.getInt(48);
					int D8 = rs3.getInt(49);
					int D9 = rs3.getInt(50);
					int D10 = rs3.getInt(51);
					int D11 = rs3.getInt(52);
					int D12 = rs3.getInt(53);
					int E1 = rs3.getInt(54);
					int E2 = rs3.getInt(55);
					int E3 = rs3.getInt(56);
					int E4 = rs3.getInt(57);
					int E5 = rs3.getInt(58);
					int E6 = rs3.getInt(59);
					int E7 = rs3.getInt(60);
					int E8 = rs3.getInt(61);
					int E9 = rs3.getInt(62);
					int E10 = rs3.getInt(63);
					int E11 = rs3.getInt(64);
					int E12 = rs3.getInt(65);
					int F1 = rs3.getInt(66);
					int F2 = rs3.getInt(67);
					int F3 = rs3.getInt(68);
					int F4 = rs3.getInt(69);
					int F5 = rs3.getInt(70);
					int F6 = rs3.getInt(71);
					int F7 = rs3.getInt(72);
					int F8 = rs3.getInt(73);
					int F9 = rs3.getInt(74);
					int F10 = rs3.getInt(75);
					int F11 = rs3.getInt(76);
					int F12 = rs3.getInt(77);
					int G1 = rs3.getInt(78);
					int G2 = rs3.getInt(79);
					int G3 = rs3.getInt(80);
					int G4 = rs3.getInt(81);
					int G5 = rs3.getInt(82);
					int G6 = rs3.getInt(83);
					int G7 = rs3.getInt(84);
					int G8 = rs3.getInt(85);
					int G9 = rs3.getInt(86);
					int G10 = rs3.getInt(87);
					int G11 = rs3.getInt(88);
					int G12 = rs3.getInt(89);
					int H1 = rs3.getInt(90);
					int H2 = rs3.getInt(91);
					int H3 = rs3.getInt(92);
					int H4 = rs3.getInt(93);
					int H5 = rs3.getInt(94);
					int H6 = rs3.getInt(95);
					int H7 = rs3.getInt(96);
					int H8 = rs3.getInt(97);
					int H9 = rs3.getInt(98);
					int H10 = rs3.getInt(99);
					int H11 = rs3.getInt(100);
					int H12 = rs3.getInt(101);
					int I1 = rs3.getInt(102);
					int I2 = rs3.getInt(103);
					int I3 = rs3.getInt(104);
					int I4 = rs3.getInt(105);
					int I5 = rs3.getInt(106);
					int I6 = rs3.getInt(107);
					int I7 = rs3.getInt(108);
					int I8 = rs3.getInt(109);
					int I9 = rs3.getInt(110);
					int I10 = rs3.getInt(111);
					int I11 = rs3.getInt(112);
					int I12 = rs3.getInt(113);
					int J1 = rs3.getInt(114);
					int J2 = rs3.getInt(115);
					int J3 = rs3.getInt(116);
					int J4 = rs3.getInt(117);
					int J5 = rs3.getInt(118);
					int J6 = rs3.getInt(119);
					int J7 = rs3.getInt(120);
					int J8 = rs3.getInt(121);
					int J9 = rs3.getInt(122);
					int J10 = rs3.getInt(123);
					int J11 = rs3.getInt(124);
					int J12 = rs3.getInt(125);

					Seats l = new Seats(movieId, multiplexId, showdate, showtime, A1, A2, A3, A4, A5, A6, A7, A8, A9,
							A10, A11, A12, B1, B2, B3, B4, B5, B6, B7, B8, B9, B10, B11, B12, C1, C2, C3, C4, C5, C6,
							C7, C8, C9, C10, C11, C12, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, E1, E2, E3,
							E4, E5, E6, E7, E8, E9, E10, E11, E12, F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
							G1, G2, G3, G4, G5, G6, G7, G8, G9, G10, G11, G12, H1, H2, H3, H4, H5, H6, H7, H8, H9, H10,
							H11, H12, I1, I2, I3, I4, I5, I6, I7, I8, I9, I10, I11, I12, J1, J2, J3, J4, J5, J6, J7, J8,
							J9, J10, J11, J12);
					System.out.println(l);
					al.add(l);
				}

				if (al.size() != 0) {
					System.out.println(al);
					return al;
				}

				else {
					return null;
				}

			} else {
				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
			return null;
		}

	}

	public String getTime(int id, String d, String m) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd2 = "";
			System.out.println(m);
			System.out.println(d);
			System.out.println(id);
			if (m.equals(" morning")) {
				cmd2 = "select showtime from morningseats where tId=? and showdate=?";
			}

			else if (m.equals(" matinee")) {
				cmd2 = "select showtime from matineeseats where tId=? and showdate=?";
			}

			else if (m.equals(" secondshow")) {
				cmd2 = "select showtime from secondshowseats where tId=? and showdate=?";
			}

			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setInt(1, id);

			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date datei = sdf1.parse(d);
			java.sql.Date sqlDate = new java.sql.Date(datei.getTime());

			ps2.setDate(2, sqlDate);
			ResultSet rs2 = ps2.executeQuery();

			if (rs2.next()) {

				String date = rs2.getString(1);
				return date;
			}

			else {
				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
			return null;
		}

	}

}
