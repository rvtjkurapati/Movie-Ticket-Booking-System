package com.virtusa.mtms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.mtms.dto.City;
import com.virtusa.mtms.dto.Seats;
import com.virtusa.mtms.dto.Movie;
import com.virtusa.mtms.dto.Multiplex;
import com.virtusa.mtms.dto.PresentMovie;
import com.virtusa.mtms.service.IBookingServiceImpl;
import com.virtusa.mtms.service.ICityServiceImpl;
import com.virtusa.mtms.service.IMovieServiceImpl;
import com.virtusa.mtms.service.IMultiplexServiceImpl;
import com.virtusa.mtms.service.ITheatreServiceImpl;

@WebServlet("/Location")
public class LocationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LocationController() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ICityServiceImpl city = new ICityServiceImpl();
		IMovieServiceImpl mv = new IMovieServiceImpl();

		ITheatreServiceImpl ts = new ITheatreServiceImpl();
		HttpSession sn = request.getSession();
		ArrayList<City> cl = city.getCity();
		String cname = request.getParameter("city");
		ArrayList<PresentMovie> lmv = ts.getLatestMovies(cname);
		ArrayList<PresentMovie> umv = ts.getUpcomingMovies(cname);

		sn.setAttribute("cname", cname);
		sn.setAttribute("cityList", cl);
		sn.setAttribute("newMovieList", lmv);
		sn.setAttribute("upComingList", umv);
		RequestDispatcher rd = request.getRequestDispatcher("Homepage.jsp");
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
