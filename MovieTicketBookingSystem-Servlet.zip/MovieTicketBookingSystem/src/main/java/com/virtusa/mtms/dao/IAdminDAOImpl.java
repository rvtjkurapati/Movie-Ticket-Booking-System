package com.virtusa.mtms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import com.virtusa.mtms.dto.Admin;
import com.virtusa.mtms.util.DbConnection;

public class IAdminDAOImpl {

	public boolean AddAdmin(Admin l) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from admin where username=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1, l.getUserName());
			ResultSet rs = ps1.executeQuery();

			if (!rs.next()) {
				String cmd2 = "insert into admin (username, password, balance) values(?,?,400)";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setString(1, l.getUserName());
				ps2.setString(2, l.getPassWord());
				ps2.executeUpdate();
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public boolean addBal(int aid, int bal) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "update admin set balance=? where adminId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, bal);
			ps1.setInt(2, aid);
			System.out.println("*" + bal + aid + "*");
			ps1.executeUpdate();
			return true;

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return false;
	}

	public boolean DelAdmin(int s) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from admin where adminId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, s);
			ResultSet rs = ps1.executeQuery();

			if (rs.next()) {
				String cmd2 = "delete from admin where adminId=?;";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, s);
				ps2.executeUpdate();
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public boolean ValidateAdmin(Admin l) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from admin where username=? and password=?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, l.getUserName());
			ps.setString(2, l.getPassWord());
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}

		return false;
	}

	public int getId(Admin l) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select adminId from admin where username=? and password=?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, l.getUserName());
			ps.setString(2, l.getPassWord());
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);

				return id;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}

		return 0;
	}

	public int getBal(Admin l) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select balance from admin where username=? and password=?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, l.getUserName());
			ps.setString(2, l.getPassWord());
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);

				return id;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}

		return 0;
	}

	public boolean ValidateId(int id) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from admin where adminId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}

		return false;
	}

	public ArrayList<Admin> getAdmins() {
		ArrayList<Admin> log = new ArrayList<Admin>();
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from admin";
			PreparedStatement ps = con.prepareStatement(cmd);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String uName = rs.getString(2);
				String pWord = rs.getString(3);
				int bal = rs.getInt(4);
				Admin l = new Admin(id, uName, pWord, bal);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			} else {
				return null;
			}
		}

		catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public boolean ModifyAdmin(int id, String name, String pwd) {

		try {

			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from admin where username=? and adminId!=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1, name);
			ps1.setInt(2, id);
			ResultSet rs = ps1.executeQuery();

			if (!rs.next()) {
				String cmd = "update  admin  set username=? , password=? where adminId=?";
				PreparedStatement ps = con.prepareStatement(cmd);
				ps.setString(1, name);
				ps.setString(2, pwd);
				ps.setInt(3, id);
				ps.executeUpdate();
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}

		return false;
	}

	public ArrayList<Admin> SearchAdmin(String str) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Admin> log = new ArrayList<Admin>();
			String cmd = "select * from  admin  where username like ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, str + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String uName = rs.getString(2);
				String pWord = rs.getString(3);
				int bal = rs.getInt(4);
				Admin l = new Admin(id, uName, pWord, bal);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Admin> SearchId(int str) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Admin> log = new ArrayList<Admin>();
			String cmd = "select * from  admin  where adminId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, str);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String uName = rs.getString(2);
				String pWord = rs.getString(3);
				int bal = rs.getInt(4);
				Admin l = new Admin(id, uName, pWord, bal);
				log.add(l);

			}

			if (log.size() != 0) {

				return log;
			}

			else {

				return null;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

}
