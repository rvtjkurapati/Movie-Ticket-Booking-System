package com.virtusa.mtms.service;

import java.util.ArrayList;

import com.virtusa.mtms.dto.Location;

public interface ILocation {
	public boolean AddLocation(Location l);

	public boolean DelLocation(int s);

	public ArrayList<Location> getLocation();

	public boolean ModifyLocation(int l, int cid, String name);

	public ArrayList<Location> SearchLocation(String str);

}
