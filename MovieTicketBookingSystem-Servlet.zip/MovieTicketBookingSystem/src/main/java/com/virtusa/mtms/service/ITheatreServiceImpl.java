package com.virtusa.mtms.service;

import java.util.ArrayList;

import com.virtusa.mtms.dao.ITheatreDAOImpl;
import com.virtusa.mtms.dto.Movie;
import com.virtusa.mtms.dto.PresentMovie;
import com.virtusa.mtms.dto.Show;
import com.virtusa.mtms.dto.Theatre;

public class ITheatreServiceImpl {

	ITheatreDAOImpl dao;

	public boolean AddTheatre(Theatre m) {
		dao = new ITheatreDAOImpl();
		boolean flag = dao.AddTheatre(m);
		return flag;
	}

	public boolean DelTheatre(int m) {

		dao = new ITheatreDAOImpl();
		boolean flag = dao.DelTheatre(m);
		return flag;

	}

	public ArrayList<Theatre> getTheatre() {

		dao = new ITheatreDAOImpl();
		ArrayList<Theatre> al = dao.getTheatre();
		return al;

	}

	public ArrayList<Show> getTheatreByMid(int id) {

		dao = new ITheatreDAOImpl();
		ArrayList<Show> al = dao.getTheatreByMid(id);
		return al;

	}

	public ArrayList<PresentMovie> getLatestMovies(String name) {
		dao = new ITheatreDAOImpl();
		ArrayList<PresentMovie> al = dao.getLatestMovies(name);
		return al;

	}

	public ArrayList<Movie> getAllLatestMovies() {
		dao = new ITheatreDAOImpl();
		ArrayList<Movie> al = dao.getAllLatestMovies();
		return al;
	}

	public ArrayList<PresentMovie> getUpcomingMovies(String name) {
		dao = new ITheatreDAOImpl();
		ArrayList<PresentMovie> al = dao.getUpcomingMovies(name);
		return al;
	}

	public ArrayList<Movie> getAllUpcomingMovies() {
		dao = new ITheatreDAOImpl();
		ArrayList<Movie> al = dao.getAllUpcomingMovies();
		return al;
	}

	public ArrayList<Movie> searchLmv(String genre, String language) {
		dao = new ITheatreDAOImpl();
		ArrayList<Movie> al = dao.searchLmv(genre, language);
		return al;
	}

	public boolean ModifyTheatre(Theatre m) {
		dao = new ITheatreDAOImpl();
		boolean flag = dao.ModifyTheatre(m);
		return flag;
	}

	public ArrayList<Theatre> SearchTheatreByMv(int ctid) {
		dao = new ITheatreDAOImpl();
		ArrayList<Theatre> al = dao.SearchTheatreByMv(ctid);
		return al;
	}

	public ArrayList<Theatre> SearchTheatreByCity(int ctid) {
		dao = new ITheatreDAOImpl();
		ArrayList<Theatre> al = dao.SearchTheatreByCity(ctid);
		return al;
	}

	public ArrayList<Theatre> SearchTheatreByMux(int muxid) {

		dao = new ITheatreDAOImpl();
		ArrayList<Theatre> al = dao.SearchTheatreByMux(muxid);
		return al;
	}

	public int getTid(int mid, int muxid, String showt) {

		dao = new ITheatreDAOImpl();
		int al = dao.getTid(mid, muxid, showt);
		return al;
	}

	public String getShow(String time, int tid) {
		dao = new ITheatreDAOImpl();
		String al = dao.getShow(time, tid);
		return al;
	}

}
