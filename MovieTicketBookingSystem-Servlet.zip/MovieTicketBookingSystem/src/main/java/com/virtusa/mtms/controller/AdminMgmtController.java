package com.virtusa.mtms.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.mtms.dao.IMultiplexDAOImpl;
import com.virtusa.mtms.dto.Admin;
import com.virtusa.mtms.dto.Booking;
import com.virtusa.mtms.dto.City;
import com.virtusa.mtms.dto.CityLocMux;
import com.virtusa.mtms.dto.CityLocationList;
import com.virtusa.mtms.dto.Customer;
import com.virtusa.mtms.dto.Location;
import com.virtusa.mtms.dto.Movie;
import com.virtusa.mtms.dto.Multiplex;
import com.virtusa.mtms.dto.PresentMovie;
import com.virtusa.mtms.dto.Seats;
import com.virtusa.mtms.dto.Show;
import com.virtusa.mtms.dto.Theatre;
import com.virtusa.mtms.dto.Ticket;
import com.virtusa.mtms.service.IAdminServiceImpl;
import com.virtusa.mtms.service.IBookingServiceImpl;
import com.virtusa.mtms.service.ICityServiceImpl;
import com.virtusa.mtms.service.ICustomerServiceImpl;
import com.virtusa.mtms.service.ILocationServiceImpl;
import com.virtusa.mtms.service.IMovieServiceImpl;
import com.virtusa.mtms.service.IMultiplexServiceImpl;
import com.virtusa.mtms.service.ISAdminServiceImpl;
import com.virtusa.mtms.service.ITheatreServiceImpl;

@WebServlet("/AdminMgmtController")
public class AdminMgmtController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AdminMgmtController() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession sn = request.getSession();
		ICustomerServiceImpl cust = new ICustomerServiceImpl();
		ICityServiceImpl city = new ICityServiceImpl();
		ILocationServiceImpl location = new ILocationServiceImpl();
		IMultiplexDAOImpl mux = new IMultiplexDAOImpl();
		IMovieServiceImpl movie = new IMovieServiceImpl();
		ITheatreServiceImpl ts = new ITheatreServiceImpl();
		IBookingServiceImpl book = new IBookingServiceImpl();
		IAdminServiceImpl admin = new IAdminServiceImpl();
		ISAdminServiceImpl sadmin = new ISAdminServiceImpl();

		String action = request.getParameter("action");
		String target = "";
		switch (action) {

		case "LOG IN": {
			String uname = request.getParameter("username");
			String pwd = request.getParameter("password");
			boolean val = sadmin.Validate(uname, pwd);
			target = "";
			if (val == true) {

				sn.setAttribute("Sname", uname);
				sn.setAttribute("Spwd", pwd);
				target = "SuperHomepage.jsp";

			} else {
				target = "AdminLogin2.jsp";
			}
			break;
		}

		case "Log In": {
			String uname = request.getParameter("username");
			String pwd = request.getParameter("password");

			Admin a = new Admin(1, uname, pwd, 100);
			boolean val = admin.ValidateAdmin(a);
			target = "";
			if (val == true) {
				int bal = admin.getBal(a);
				int id = admin.getId(a);
				sn.setAttribute("Aname", uname);
				sn.setAttribute("Apwd", pwd);
				sn.setAttribute("Abal", bal);
				sn.setAttribute("Aid", id);
				target = "AdminHomepage.jsp";

			} else {
				target = "AdminLogin2.jsp";
			}
			break;
		}

		case "Confirm Payment": {
			int amount = Integer.valueOf(request.getParameter("amount"));
			int aid = Integer.valueOf(request.getParameter("aid"));
			int abal = Integer.valueOf(request.getParameter("abal"));
			boolean f = admin.addBal(aid, amount);
			System.out.println(amount + "" + aid);
			System.out.println(f);
			sn.setAttribute("Abal", amount + abal);
			target = "AdminProfile.jsp";

			break;
		}

		case "Proceed": {
			int amount = Integer.valueOf(request.getParameter("amount"));

			sn.setAttribute("Amount", amount);
			target = "AdminBalance.jsp";

			break;
		}

		case "bookings": {
//			int  id=Integer.valueOf(request.getParameter("aid"));
			ArrayList<Ticket> al = book.ShowTicket(203);
			System.out.println(al);
			sn.setAttribute("Ticket", al);
			target = "AdminBookings.jsp";

			break;
		}

		case "user": {
			ArrayList<Customer> c = cust.getCustomers();
			sn.setAttribute("OpSelect", "All");
			sn.setAttribute("CustList", c);
			target = "UserMgmt.jsp";
			break;
		}

		case "superbooking": {
			ArrayList<Booking> bl = book.getBookings();
			sn.setAttribute("BTable", bl);
			System.out.println(bl);
			ArrayList<Movie> cl = movie.getMovies();
			sn.setAttribute("MvList", cl);

			ArrayList<Multiplex> cli = mux.getMultiplex();
			sn.setAttribute("MList", cli);

			sn.setAttribute("BOpSelect", "All");
			target = "SuperBooking.jsp";
			break;
		}

		case "admin": {
			ArrayList<Admin> c = admin.getAdmins();
			sn.setAttribute("OpSelect", "All");
			sn.setAttribute("AdminList", c);
			target = "AdminMgmt.jsp";
			break;
		}
		case "city": {
			ArrayList<City> c = city.getCity();
			sn.setAttribute("CTable", c);
			sn.setAttribute("CityOpSelect", "All");
			target = "CityMgmt.jsp";
			break;
		}
		case "location": {
			ArrayList<Location> c = location.getLocation();
			ArrayList<City> cl = city.getCity();
			sn.setAttribute("CTable", cl);
			sn.setAttribute("LTable", c);
			sn.setAttribute("LocOpSelect", "All");
			target = "LocationMgmt.jsp";
			break;
		}
		case "multiplex": {
			ArrayList<Location> c = location.getLocation();
			ArrayList<Multiplex> cl = mux.getMultiplex();
			ArrayList<CityLocationList> lc = mux.getCList();
			ArrayList<City> ctl = city.getCity();
			ArrayList<Location> lcl = location.getLocation();
			sn.setAttribute("LcTable", lcl);
			sn.setAttribute("ClTable", ctl);

			sn.setAttribute("LTable", c);
			sn.setAttribute("MxTable", cl);
			sn.setAttribute("CTable", lc);
			sn.setAttribute("MxOpSelect", "All");
			target = "MultiplexMgmt.jsp";
			break;
		}
		case "movie": {
			ArrayList<Movie> c = movie.getMovies();
			sn.setAttribute("MvTable", c);
			sn.setAttribute("MvOpSelect", "All");
			target = "MovieMgmt.jsp";
			break;
		}
		case "booking": {
			ArrayList<Booking> bl = book.getBookings();
			sn.setAttribute("BTable", bl);
			System.out.println(bl);
			ArrayList<Movie> cl = movie.getMovies();
			sn.setAttribute("MvList", cl);

			ArrayList<Multiplex> cli = mux.getMultiplex();
			sn.setAttribute("MList", cli);

			String name = request.getParameter("aname");
			// int id=Integer.valueOf(request.getParameter("aid"));
			String pwd = request.getParameter("apwd");
			// int bal=Integer.valueOf(request.getParameter("abal"));

			// sn.setAttribute("Aid", id);
			sn.setAttribute("Aname", name);
			sn.setAttribute("Apwd", pwd);
			// sn.setAttribute("Abal", bal);

			sn.setAttribute("BOpSelect", "All");
			target = "BookingMgmt.jsp";
			break;
		}

		case "showtheatre": {
			ArrayList<Theatre> bl = ts.getTheatre();
			sn.setAttribute("Table", bl);
			System.out.println(bl);
			ArrayList<Multiplex> cl = mux.getMultiplex();
			sn.setAttribute("MList", cl);

			ArrayList<Movie> cli = movie.getMovies();
			sn.setAttribute("MvList", cli);

			ArrayList<CityLocMux> clm = mux.getMList();
			sn.setAttribute("CMList", clm);
			sn.setAttribute("TOpSelect", "All");
			target = "TheatreMgmt.jsp";
			break;
		}
		case "adminprofile": {
			String aname = request.getParameter("aname");
			String apwd = request.getParameter("apwd");
			String abal = request.getParameter("abal");
			String aid = request.getParameter("aid");
			sn.setAttribute("Aname", aname);
			sn.setAttribute("Apwd", apwd);
			sn.setAttribute("Aid", aid);
			sn.setAttribute("Abal", abal);
			target = "AdminProfile.jsp";
			break;
		}

		case "adminmoney": {
			String abal = request.getParameter("abal");
			sn.setAttribute("Abal", abal);
			target = "AdminMoney.jsp";
			break;
		}

		case "AdminMovies": {
			String abal = request.getParameter("abal");
			sn.setAttribute("Abal", abal);
			ArrayList<City> c = city.getCity();
			ArrayList<Movie> a = ts.getAllLatestMovies();
			sn.setAttribute("newMovieList", a);
			System.out.println(a);
			sn.setAttribute("gcity", "Select Location");
			sn.setAttribute("ggenre", "All Genres");
			sn.setAttribute("glang", "All Languages");
			sn.setAttribute("CTable", c);
			target = "AdminMovies.jsp";
			break;
		}

		case "Go": {
			String abal = request.getParameter("abal");
			sn.setAttribute("Abal", abal);

			String genre = request.getParameter("genre");
			String lang = request.getParameter("lang");
			System.out.println(genre);
			System.out.println(lang);
			ArrayList<City> c = city.getCity();
			ArrayList<Movie> a = ts.searchLmv(genre, lang);
			System.out.println(a);
			sn.setAttribute("ggenre", genre);
			sn.setAttribute("glang", lang);
			sn.setAttribute("CTable", c);
			sn.setAttribute("newMovieList", a);

			target = "AdminMovies.jsp";
			break;
		}

		case "AdminBook": {
			String img = request.getParameter("img");
			String mname = request.getParameter("mname");
			String lang = request.getParameter("lang");
			String cen = request.getParameter("cen");
			String gen = request.getParameter("gen");
			String dur = request.getParameter("dur");
			int id = Integer.valueOf(request.getParameter("id"));
			String cat = request.getParameter("cat");
			String dir = request.getParameter("dir");
			String cast = request.getParameter("cast");
			String syn = request.getParameter("syn");

			ArrayList<Show> c = ts.getTheatreByMid(id);
			System.out.println(id);
			System.out.println(id);
			System.out.println(id);
			System.out.println(id);
			System.out.println(c);
			System.out.println(c);
			System.out.println(c);
			sn.setAttribute("Bimg", img);
			sn.setAttribute("Bname", mname);
			sn.setAttribute("Blang", lang);
			sn.setAttribute("Bcen", cen);
			sn.setAttribute("Bgen", gen);
			sn.setAttribute("Bdur", dur);
			sn.setAttribute("Bmid", id);
			sn.setAttribute("Bcat", cat);
			sn.setAttribute("Bdir", dir);
			sn.setAttribute("Bcast", cast);
			sn.setAttribute("Bsyn", syn);
			sn.setAttribute("BTList", c);
			target = "AdminBooking.jsp";
			break;
		}

		case "Adminbook": {
			String mxname = request.getParameter("mxname");
			String add = request.getParameter("add");
			int tid = Integer.valueOf(request.getParameter("tid"));
			String screen = request.getParameter("screen");
			String show = request.getParameter("show");
			String showdate = request.getParameter("showdate");
			String price = request.getParameter("price");

//			String show=ts.getShow(showdum, tid);

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String s = LocalDate.parse(showdate, formatter).format(formatter2);

			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("MMMM-dd-yyyy");
			String styled = LocalDate.parse(showdate, formatter1).format(formatter3);
			styled = styled.replace('-', ' ');

			String showtime = book.getTime(tid, s, show);
			sn.setAttribute("Showdate", showdate);
			sn.setAttribute("Smxname", mxname);
			sn.setAttribute("Slname", add);
			sn.setAttribute("Stid", tid);
			sn.setAttribute("Sscreen", screen);
			sn.setAttribute("Show", show);
			sn.setAttribute("Sshow", showtime);
			sn.setAttribute("Sdate", s);
			sn.setAttribute("Stdate", styled);
			sn.setAttribute("Sprice", price);

			if (show.equals(" morning")) {

				ArrayList<Seats> morn = book.getMorningSeats(s, tid);
				sn.setAttribute("mul", morn);
			}

			else if (show.equals(" matinee")) {
				ArrayList<Seats> mat = book.getMatineeSeats(s, tid);
				sn.setAttribute("mul", mat);
			} else if (show.equals(" secondshow")) {
				ArrayList<Seats> sec = book.getSecondShowSeats(s, tid);
				sn.setAttribute("mul", sec);
			}
			target = "AdminSeating.jsp";
			break;
		}

		case "booktkt": {
			String seatno = request.getParameter("seatno");
			String seats = request.getParameter("seats");
			String tp = request.getParameter("tp");
			String show = request.getParameter("show");
			String screen = request.getParameter("screen");
			System.out.println(seatno);
			System.out.println(seatno);
			System.out.println(seatno);
			System.out.println(seatno);
			System.out.println(seatno);

			sn.setAttribute("FCount", tp);
			sn.setAttribute("FSeats", seats);
			sn.setAttribute("FSno", seatno);
			sn.setAttribute("Show", show);
			sn.setAttribute("Screen", screen);
			target = "AdminPayment.jsp";
			break;
		}

		case "Continue to pay": {

			int cid = 202;
			int tid = Integer.valueOf(request.getParameter("tid"));
			String mxname = request.getParameter("mxid");
			int mxid = mux.getMxid(mxname);
			int mvid = Integer.valueOf(request.getParameter("mvid"));
			String sd = request.getParameter("sd");
			String st = request.getParameter("st");
			String seats = request.getParameter("seats");
			String phone = request.getParameter("phone");
			String show = request.getParameter("show");
			int screen = Integer.valueOf(request.getParameter("screen"));

			Booking b = new Booking(0, cid, tid, mxid, mvid, sd, show, seats, phone, screen);
			boolean mod = book.BookTicket(b);
			if (mod == true) {
				ArrayList<Booking> c = book.getBookings();
				System.out.println(c);
				sn.setAttribute("custList", c);
			} else {
				System.out.println("Book Avvale");
			}

			break;
		}

		case "adminsetting": {
			String aname = request.getParameter("aname");
			String apwd = request.getParameter("apwd");
			String abal = request.getParameter("abal");
			String aid = request.getParameter("aid");
			sn.setAttribute("Aname", aname);
			sn.setAttribute("Apwd", apwd);
			sn.setAttribute("Aid", aid);
			sn.setAttribute("Abal", abal);
			System.out.println(aname);
			System.out.println(apwd);
			System.out.println(aid);
			System.out.println(abal);
			target = "ModifyAdmin.jsp";
			break;
		}

		case "searchcust": {

			String uname = request.getParameter("uname");
			String op = request.getParameter("search");
			System.out.println(op + 123456);
			System.out.println(uname + 99999);

			target = "UserMgmt.jsp";

			if (op.equals("All")) {
				ArrayList<Customer> c = cust.getCustomers();
				sn.setAttribute("CustList", c);
				sn.setAttribute("OpSelect", "All");
			}

			if (op.equals("Username")) {
				ArrayList<Customer> c = cust.SearchCustomer(uname);
				sn.setAttribute("OpSelect", "Username");
				sn.setAttribute("CustList", c);
			}
			if (op.equals("User Id")) {
				int id = Integer.parseInt(request.getParameter("uname"));
				sn.setAttribute("OpSelect", "User Id");
				ArrayList<Customer> c = cust.SearchCustomer(id);
				sn.setAttribute("CustList", c);
			}
			if (op.equals("Phone")) {
				ArrayList<Customer> c = cust.SearchByPhone(uname);
				sn.setAttribute("OpSelect", "Phone");
				sn.setAttribute("CustList", c);
			}
			if (op.equals("Email")) {
				ArrayList<Customer> c = cust.SearchByMail(uname);
				sn.setAttribute("OpSelect", "Email");
				sn.setAttribute("CustList", c);
			}
			break;
		}

		case "searchadmin": {

			String uname = request.getParameter("uname");
			String op = request.getParameter("search");
			System.out.println(op + 123456);
			System.out.println(uname + 99999);

			target = "AdminMgmt.jsp";

			if (op.equals("All")) {
				ArrayList<Admin> c = admin.getAdmins();
				sn.setAttribute("AdminList", c);
				sn.setAttribute("OpSelect", "All");
			}

			if (op.equals("Name")) {
				ArrayList<Admin> c = admin.SearchAdmin(uname);
				sn.setAttribute("OpSelect", "Name");
				sn.setAttribute("AdminList", c);
			}
			if (op.equals("Id")) {
				int id = Integer.parseInt(request.getParameter("uname"));
				sn.setAttribute("OpSelect", "Id");
				ArrayList<Admin> c = admin.SearchId(id);
				sn.setAttribute("AdminList", c);
			}

			break;
		}

		case "modifycust": {
			String mid = request.getParameter("mid");
			String mname = request.getParameter("mname");
			String mpwd = request.getParameter("mpwd");
			String mphone = request.getParameter("mphone");
			String mmail = request.getParameter("mmail");
			String mbal = request.getParameter("mbal");
			sn.setAttribute("ModUid", mid);
			sn.setAttribute("ModUname", mname);
			sn.setAttribute("ModUpwd", mpwd);
			sn.setAttribute("ModUphone", mphone);
			sn.setAttribute("ModUmail", mmail);
			sn.setAttribute("ModUbal", mbal);
			sn.setAttribute("ModCust", "true");
			target = "ModifyCust.jsp";
			break;
		}

		case "deletingcust": {
			String mid = request.getParameter("mid");
			String mname = request.getParameter("mname");
			String mpwd = request.getParameter("mpwd");
			String mphone = request.getParameter("mphone");
			String mmail = request.getParameter("mmail");
			String mbal = request.getParameter("mbal");
			sn.setAttribute("ModUid", mid);
			sn.setAttribute("ModUname", mname);
			sn.setAttribute("ModUpwd", mpwd);
			sn.setAttribute("ModUphone", mphone);
			sn.setAttribute("ModUmail", mmail);
			sn.setAttribute("ModUbal", mbal);
			sn.setAttribute("ModCust", "true");
			target = "DeleteCust.jsp";
			break;
		}

		case "Update User": {
			int muid = Integer.valueOf(request.getParameter("muid"));
			String muname = request.getParameter("muname");
			String mupwd = request.getParameter("mupwd");
			String muphone = request.getParameter("muphone");
			String mumail = request.getParameter("mumail");
			boolean mod = cust.ModifyCustomer(muid, muname, mupwd, muphone, mumail);
			ArrayList<Customer> c = cust.getCustomers();

			if (mod == true) {
				sn.setAttribute("CustList", c);
				target = "UserMgmt.jsp";
				sn.setAttribute("ModCust", "true");
			} else {
				sn.setAttribute("ModCust", "false");
				target = "ModifyCust.jsp";
			}

			break;
		}

		case "Delete User": {
			int muid = Integer.valueOf(request.getParameter("muid"));
			cust.DelCustomer(muid);
			ArrayList<Customer> c = cust.getCustomers();
			sn.setAttribute("CustList", c);
			target = "UserMgmt.jsp";
			break;
		}

		case "Add User": {
			String mupwd = request.getParameter("muname");
			String muname = request.getParameter("mupwd");
			String muphone = request.getParameter("muphone");
			String mumail = request.getParameter("mumail");
			sn.setAttribute("AddCust", "true");
			Customer a = new Customer(101, muname, mupwd, muphone, mumail, 500);
			boolean add = cust.AddCustomer(a);

			if (add == true) {
				ArrayList<Customer> c = cust.getCustomers();
				sn.setAttribute("CustList", c);
				sn.setAttribute("AddCust", "true");
				target = "UserMgmt.jsp";
			} else {
				sn.setAttribute("AddCust", "false");
				target = "AddCust.jsp";
			}

			break;
		}
		case "searchcity": {

			String cname = request.getParameter("uname");
			String op = request.getParameter("search");
			System.out.println(op + 123456);
			System.out.println(cname + 99999);

			target = "CityMgmt.jsp";

			if (op.equals("All")) {
				ArrayList<City> c = city.getCity();
				sn.setAttribute("CTable", c);
				sn.setAttribute("CityOpSelect", "All");
			}

			if (op.equals("City name")) {
				ArrayList<City> c = city.SearchCity(cname);
				sn.setAttribute("CTable", c);
				sn.setAttribute("CityOpSelect", "City name");
			}
			if (op.equals("City Id")) {
				int id = Integer.parseInt(request.getParameter("uname"));
				sn.setAttribute("CityOpSelect", "City Id");
				ArrayList<City> c = city.SearchCity(id);
				sn.setAttribute("CTable", c);
			}
			break;
		}
		case "modifycity": {
			String mcid = request.getParameter("mcid");
			String mcname = request.getParameter("mcname");
			sn.setAttribute("ModCid", mcid);
			sn.setAttribute("ModCname", mcname);
			sn.setAttribute("ModCity", "true");
			target = "ModifyCity.jsp";
			break;
		}

		case "Update City": {
			String mcname = request.getParameter("mcname");
			int mcid = Integer.valueOf(request.getParameter("mcid"));
			boolean mod = city.ModifyCity(mcid, mcname);
			ArrayList<City> c = city.getCity();

			if (mod == true) {
				sn.setAttribute("CTable", c);
				target = "CityMgmt.jsp";
				sn.setAttribute("ModCity", "true");
			} else {
				sn.setAttribute("ModCity", "false");
				target = "ModifyCity.jsp";
			}

			break;
		}

		case "Update Admin": {
			String aname = request.getParameter("aname");
			String apwd = request.getParameter("apwd");
			int aid = Integer.valueOf(request.getParameter("aid"));
			boolean mod = admin.ModifyAdmin(aid, aname, apwd);
			ArrayList<Admin> c = admin.getAdmins();

			if (mod == true) {
				sn.setAttribute("AdminList", c);
				target = "AdminMgmt.jsp";
				sn.setAttribute("ModAdmin", "true");
			} else {
				sn.setAttribute("ModAdmin", "false");
				target = "ModifyAdminUser.jsp";
			}

			break;
		}

		case "deletingcity": {
			int mcid = Integer.valueOf(request.getParameter("mcid"));
			String mcname = request.getParameter("mcname");
			sn.setAttribute("ModCid", mcid);
			sn.setAttribute("ModCname", mcname);
			target = "DeleteCity.jsp";
			break;
		}

		case "Delete City": {
			int mcid = Integer.valueOf(request.getParameter("mcid"));
			System.out.println(mcid);
			city.DelCity(mcid);
			ArrayList<City> c = city.getCity();
			sn.setAttribute("CTable", c);
			target = "CityMgmt.jsp";
			break;
		}

		case "Add City": {
			String mcname = request.getParameter("mcname");
			sn.setAttribute("AddCity", "true");
			boolean add = city.AddCity(mcname);

			if (add == true) {
				ArrayList<City> c = city.getCity();
				sn.setAttribute("CTable", c);
				sn.setAttribute("AddCity", "true");
				target = "CityMgmt.jsp";
			} else {
				sn.setAttribute("AddCity", "false");
				target = "AddCity.jsp";
			}

			break;
		}

		case "Add Admin": {
			String uname = request.getParameter("uname");
			String pwd = request.getParameter("pwd");
			sn.setAttribute("AddAdmin", "true");
			Admin l = new Admin(0, uname, pwd, 600);
			boolean add = admin.AddAdmin(l);

			if (add == true) {
				ArrayList<Admin> c = admin.getAdmins();
				sn.setAttribute("AdminList", c);
				target = "AdminMgmt.jsp";
			} else {
				sn.setAttribute("AddAdmin", "false");
				target = "AddAdmin.jsp";
			}

			break;
		}

		case "searchlocation": {

			String lname = request.getParameter("uname");
			String op = request.getParameter("search");
			System.out.println(op + 123456);
			System.out.println(lname + 99999);

			target = "LocationMgmt.jsp";

			if (op.equals("All")) {
				ArrayList<Location> c = location.getLocation();
				sn.setAttribute("LTable", c);
				sn.setAttribute("LocOpSelect", "All");
			}

			if (op.equals("Location name")) {
				ArrayList<Location> c = location.SearchLocation(lname);
				sn.setAttribute("LTable", c);
				sn.setAttribute("LocOpSelect", "Location name");
			}
			if (op.equals("City Id")) {
				int id = Integer.parseInt(request.getParameter("uname"));
				sn.setAttribute("LocOpSelect", "City Id");
				ArrayList<Location> c = location.SearchLocationByCid(id);
				sn.setAttribute("LTable", c);
			}
			if (op.equals("Location Id")) {
				int id = Integer.parseInt(request.getParameter("uname"));
				sn.setAttribute("LocOpSelect", "Location Id");
				ArrayList<Location> c = location.SearchLocationByLid(id);
				sn.setAttribute("LTable", c);
			}
			break;
		}
		case "modifylocation": {
			int mcid = Integer.valueOf(request.getParameter("mcid"));
			String mcname = city.getCname(mcid);
			String mlid = request.getParameter("mlid");
			String mlname = request.getParameter("mlname");
			System.out.println(mcname);
			sn.setAttribute("ModCid", mcid);
			sn.setAttribute("ModLid", mlid);
			sn.setAttribute("ModCname", mlname);
			sn.setAttribute("ModOpCity", mcname);
			sn.setAttribute("ModLoc", "true");
			target = "ModifyLocation.jsp";
			break;
		}
		case "modifyadmin": {
			int aid = Integer.valueOf(request.getParameter("aid"));
			String apwd = request.getParameter("apwd");
			String aname = request.getParameter("aname");
			sn.setAttribute("Aid", aid);
			sn.setAttribute("Apwd", apwd);
			sn.setAttribute("Aname", aname);
			sn.setAttribute("ModAdmin", "true");
			target = "ModifyAdminUser.jsp";
			break;
		}

		case "deletingadmin": {
			int aid = Integer.valueOf(request.getParameter("aid"));
			String apwd = request.getParameter("apwd");
			String aname = request.getParameter("aname");
			sn.setAttribute("Aid", aid);
			sn.setAttribute("Apwd", apwd);
			sn.setAttribute("Aname", aname);
			sn.setAttribute("ModAdmin", "true");
			target = "DeleteAdmin.jsp";
			break;
		}

		case "deletinglocation": {
			String mcid = request.getParameter("mcid");
			String mlid = request.getParameter("mlid");
			String mlname = request.getParameter("mlname");
			sn.setAttribute("ModCid", mcid);
			sn.setAttribute("ModLid", mlid);
			sn.setAttribute("ModCname", mlname);
			sn.setAttribute("ModLoc", "true");
			target = "DeleteLocation.jsp";
			break;
		}

		case "Update Location": {
			String mlname = request.getParameter("mlname");
			String mcname = request.getParameter("mcid");
			int mcid = city.getCid(mcname);
			int mlid = Integer.valueOf(request.getParameter("mlid"));
			boolean mod = location.ModifyLocation(mlid, mcid, mlname);
			ArrayList<Location> c = location.getLocation();

			if (mod == true) {
				sn.setAttribute("LTable", c);
				target = "LocationMgmt.jsp";

				sn.setAttribute("ModLoc", "true");
			} else {
				sn.setAttribute("ModLoc", "false");
				target = "ModifyLocation.jsp";
			}

			break;
		}

		case "Delete Location": {
			int mlid = Integer.valueOf(request.getParameter("mlid"));
			System.out.println(mlid);
			location.DelLocation(mlid);
			ArrayList<Location> c = location.getLocation();
			sn.setAttribute("LTable", c);
			target = "LocationMgmt.jsp";
			break;
		}

		case "Add Location": {
			String name = request.getParameter("mcid");
			String mlname = request.getParameter("mlname");
			sn.setAttribute("AddLocation", "true");
			int mcid = city.getCid(name);
			Location l = new Location(mcid, 1, mlname);
			boolean add = location.AddLocation(l);

			if (add == true) {
				ArrayList<Location> c = location.getLocation();
				sn.setAttribute("LTable", c);
				sn.setAttribute("AddLocation", "true");
				target = "LocationMgmt.jsp";
			} else {
				sn.setAttribute("AddLocation", "false");
				target = "AddLocation.jsp";
			}

			break;
		}

		case "searchmultiplex": {

			String mname = request.getParameter("mname");
			String op = request.getParameter("search");

			target = "MultiplexMgmt.jsp";

			if (op.equals("All")) {
				List<Multiplex> c = mux.getMultiplex();
				sn.setAttribute("MxTable", c);
				sn.setAttribute("MxOpSelect", "All");
			}

			if (op.equals("Multiplex name")) {
				List<Multiplex> c = mux.SearchMultiplex(mname);
				sn.setAttribute("MxTable", c);
				sn.setAttribute("MxOpSelect", "Multiplex name");
			}
			if (op.equals("Multiplex Id")) {
				int id = Integer.parseInt(request.getParameter("mname"));
				sn.setAttribute("MxOpSelect", "Multiplex Id");
				ArrayList<Multiplex> c = mux.SearchMultiplexByMid(id);
				sn.setAttribute("MxTable", c);
			}
			if (op.equals("Location Id")) {
				int id = Integer.parseInt(request.getParameter("mname"));
				sn.setAttribute("MxOpSelect", "Location Id");
				ArrayList<Multiplex> c = mux.SearchMultiplexLid(id);
				sn.setAttribute("MxTable", c);
			}

			if (op.equals("City Id")) {
				int id = Integer.parseInt(request.getParameter("mname"));
				sn.setAttribute("MxOpSelect", "City Id");
				ArrayList<Multiplex> c = mux.SearchMultiplexCid(id);
				sn.setAttribute("MxTable", c);
			}
			break;
		}
		case "modifymultiplex": {
			String mcid = request.getParameter("mcid");
			int mlid = Integer.valueOf(request.getParameter("mlid"));
			String mxadd = request.getParameter("mxadd");
			String mxid = request.getParameter("mxid");
			String mxname = request.getParameter("mxname");
			ArrayList<CityLocationList> lc = mux.getCList();
			String mlname = location.getLname(mlid);
			System.out.println(mlid + "123999");
			sn.setAttribute("CTable", lc);
			sn.setAttribute("ModCid", mcid);
			sn.setAttribute("ModLid", mlid);
			sn.setAttribute("ModMxid", mxid);
			sn.setAttribute("ModMxname", mxname);
			sn.setAttribute("ModMxadd", mxadd);
			sn.setAttribute("ModLname", mlname);
			sn.setAttribute("ModMx", "true");
			target = "ModifyMultiplex.jsp";
			break;
		}

		case "Update Multiplex": {
			String mxname = request.getParameter("mxname");
			String mlname = request.getParameter("mlid");
			int mlid = location.getLid(mlname);
			int mcid = location.getCid(mlname);
			int mxid = Integer.valueOf(request.getParameter("mxid"));
			String mxadd = request.getParameter("mxadd");

			System.out.println(mxname);
			System.out.println(mlname);
			System.out.println(mlid);
			System.out.println(mcid);
			System.out.println(mxid);
			System.out.println(mxadd);
			boolean mod = mux.ModifyMultiplex(mxid, mcid, mlid, mxname, mxadd);
			List<Multiplex> c = mux.getMultiplex();
			System.out.println(mod);
			System.out.println(mod);
			if (mod == true) {
				sn.setAttribute("MxTable", c);
				target = "MultiplexMgmt.jsp";
				sn.setAttribute("ModMx", "true");
			} else {
				sn.setAttribute("ModMx", "false");
				ArrayList<CityLocationList> lc = mux.getCList();
				sn.setAttribute("CTable", lc);
				target = "ModifyMultiplex.jsp";
			}

			break;
		}
		case "deletingmultiplex": {

			String mcid = request.getParameter("mcid");
			String mlid = request.getParameter("mlid");
			String mxid = request.getParameter("mxid");
			String mxadd = request.getParameter("mxadd");
			String mxname = request.getParameter("mxname");
			sn.setAttribute("ModCid", mcid);
			sn.setAttribute("ModLid", mlid);
			sn.setAttribute("ModMxid", mxid);
			sn.setAttribute("ModMxadd", mxadd);
			sn.setAttribute("ModMxname", mxname);
			sn.setAttribute("ModMx", "true");
			target = "DeleteMultiplex.jsp";
			break;
		}

		case "Delete Multiplex": {
			int mxid = Integer.valueOf(request.getParameter("mxid"));
			System.out.println(mxid);
			mux.DelMultiplex(mxid);
			List<Multiplex> c = mux.getMultiplex();
			sn.setAttribute("MxTable", c);
			target = "MultiplexMgmt.jsp";
			break;
		}

		case "Delete Admin": {
			int aid = Integer.valueOf(request.getParameter("aid"));
			boolean f = admin.DelAdmin(aid);
			ArrayList<Admin> c = admin.getAdmins();
			sn.setAttribute("AdminList", c);
			target = "AdminMgmt.jsp";
			break;
		}

		case "Add Multiplex": {
			String mlname = request.getParameter("mlid");
			int mlid = location.getLid(mlname);
			int mcid = location.getCid(mlname);
			String mxname = request.getParameter("mxname");
			String mxadd = request.getParameter("mxadd");

			sn.setAttribute("AddMultiplex", "true");
			Multiplex l = new Multiplex(mcid, mlid, mxname, 1, mxadd);
			boolean add = mux.AddMultiplex(l);

			if (add == true) {
				List<Multiplex> c = mux.getMultiplex();
				sn.setAttribute("MxTable", c);
				sn.setAttribute("AddMultiplex", "true");
				target = "MultiplexMgmt.jsp";
			} else {
				sn.setAttribute("AddMultiplex", "false");
				target = "AddMultiplex.jsp";
			}

			break;
		}

		case "searchmovie": {

			String mname = request.getParameter("mname");
			String op = request.getParameter("search");
			System.out.println(op + 123456);
			System.out.println(mname + 99999);

			target = "MovieMgmt.jsp";

			if (op.equals("All")) {
				ArrayList<Movie> c = movie.getMovies();
				sn.setAttribute("MvTable", c);
				sn.setAttribute("MvOpSelect", "All");
			}

			if (op.equals("Movie name")) {
				ArrayList<Movie> c = movie.SearchMovie(mname);
				sn.setAttribute("MvTable", c);
				sn.setAttribute("MvOpSelect", "Movie name");
			}

			if (op.equals("Category")) {
				ArrayList<Movie> c = movie.SearchMovieByCat(mname);
				sn.setAttribute("MvTable", c);
				sn.setAttribute("MvOpSelect", "Category");
			}

			if (op.equals("Language")) {
				ArrayList<Movie> c = movie.SearchMovieByLang(mname);
				sn.setAttribute("MvTable", c);
				sn.setAttribute("MvOpSelect", "Language");
			}

			if (op.equals("Genre")) {
				ArrayList<Movie> c = movie.SearchMovieByGen(mname);
				sn.setAttribute("MvTable", c);
				sn.setAttribute("MvOpSelect", "Genre");
			}

			if (op.equals("Movie Id")) {
				int id = Integer.parseInt(request.getParameter("mname"));
				sn.setAttribute("MvOpSelect", "Movie Id");
				ArrayList<Movie> c = movie.SearchMovieByMid(id);
				sn.setAttribute("MvTable", c);
			}

			break;
		}
		case "modifymovie": {
			String mvid = request.getParameter("mvid");
			String mvname = request.getParameter("mvname");
			String mvcat = request.getParameter("mvcat");
			String mvlang = request.getParameter("mvlang");
			String mvdur = request.getParameter("mvdur");
			String mvgen = request.getParameter("mvgen");
			String mvcr = request.getParameter("mvcr");
			String mvimg = request.getParameter("mvimg");
			String mvdir = request.getParameter("mvdir");
			String mvcast = request.getParameter("mvcast");
			String mvsyn = request.getParameter("mvsyn");
			String mvrel = request.getParameter("mvrel");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			mvrel = LocalDate.parse(mvrel, formatter2).format(formatter);

			sn.setAttribute("ModMvrel", mvrel);
			sn.setAttribute("ModMvid", mvid);
			sn.setAttribute("ModMvname", mvname);
			sn.setAttribute("ModMvcat", mvcat);
			sn.setAttribute("ModMvlang", mvlang);
			sn.setAttribute("ModMvdur", mvdur);
			sn.setAttribute("ModMvgen", mvgen);
			sn.setAttribute("ModMvcr", mvcr);

			sn.setAttribute("ModMvimg", mvimg);

			sn.setAttribute("ModMvdir", mvdir);
			sn.setAttribute("ModMvcast", mvcast);
			sn.setAttribute("ModMvsyn", mvsyn);

			sn.setAttribute("ModMv", "true");
			target = "ModifyMovie.jsp";
			break;
		}

		case "deletingmovie": {
			String mvid = request.getParameter("mvid");
			String mvname = request.getParameter("mvname");
			String mvcat = request.getParameter("mvcat");
			String mvlang = request.getParameter("mvlang");
			String mvdur = request.getParameter("mvdur");
			String mvgen = request.getParameter("mvgen");
			String mvcr = request.getParameter("mvcr");
			String mvimg = request.getParameter("mvimg");
			String mvdir = request.getParameter("mvdir");
			String mvcast = request.getParameter("mvcast");
			String mvsyn = request.getParameter("mvsyn");
			String mvrel = request.getParameter("mvrel");
			System.out.println(mvrel);

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			mvrel = LocalDate.parse(mvrel, formatter2).format(formatter);
			sn.setAttribute("ModMvrel", mvrel);

			sn.setAttribute("ModMvid", mvid);
			sn.setAttribute("ModMvname", mvname);
			sn.setAttribute("ModMvcat", mvcat);
			sn.setAttribute("ModMvlang", mvlang);
			sn.setAttribute("ModMvdur", mvdur);
			sn.setAttribute("ModMvgen", mvgen);
			sn.setAttribute("ModMvcr", mvcr);

			sn.setAttribute("ModMvimg", mvimg);

			sn.setAttribute("ModMvdir", mvdir);
			sn.setAttribute("ModMvcast", mvcast);
			sn.setAttribute("ModMvsyn", mvsyn);

			sn.setAttribute("ModMv", "true");
			target = "DeleteMovie.jsp";
			break;
		}

		case "Update Movie": {
			int mvid = Integer.valueOf(request.getParameter("mvid"));
			String mvname = request.getParameter("mvname");
			String mvcat = request.getParameter("mvcat");
			String mvlang = request.getParameter("mvlang");
			String mvdur = request.getParameter("mvdur");
			String mvgen = request.getParameter("mvgen");
			String mvcr = request.getParameter("mvcr");

			String mvimg = "Images/" + request.getParameter("mvimg");

			String mvdir = request.getParameter("mvdir");
			String mvcast = request.getParameter("mvcast");
			String mvsyn = request.getParameter("mvsyn");
			String mvrel = request.getParameter("mvrel");

			Movie m = new Movie(mvid, mvname, mvcat, mvlang, mvdur, mvgen, mvcr, mvimg, mvdir, mvcast, mvsyn, mvrel);

			boolean mod = movie.ModifyMovie(m);
			ArrayList<Movie> c = movie.getMovies();

			if (mod == true) {
				sn.setAttribute("MvTable", c);
				target = "MovieMgmt.jsp";
				sn.setAttribute("ModMv", "true");
			} else {
				sn.setAttribute("ModMv", "false");
				target = "ModifyMovie.jsp";
			}

			break;
		}

		case "Delete Movie": {
			int mvid = Integer.valueOf(request.getParameter("mvid"));
			System.out.println("******************");
			System.out.println(mvid);
			System.out.println(mvid);
			System.out.println(mvid);
			movie.DelMovie(mvid);
			ArrayList<Movie> c = movie.getMovies();
			sn.setAttribute("MvTable", c);
			target = "MovieMgmt.jsp";
			break;
		}

		case "Add Movie": {

			String mvname = request.getParameter("mvname");
			String mvcat = request.getParameter("mvcat");
			String mvlang = request.getParameter("mvlang");
			String hour = request.getParameter("hour");
			String min = request.getParameter("min");
			String mvdur = hour + " Hours " + min + " Min";
			String mvgen = request.getParameter("mvgen");
			String mvcr = request.getParameter("mvcr");

			String mvimg = "Images/" + request.getParameter("mvimg");

			String mvdir = request.getParameter("mvdir");
			String mvcast = request.getParameter("mvcast");
			String mvsyn = request.getParameter("mvsyn");
			String mvrel = request.getParameter("mvrel");

			sn.setAttribute("AddMovie", "true");
			Movie m = new Movie(0, mvname, mvcat, mvlang, mvdur, mvgen, mvcr, mvimg, mvdir, mvcast, mvsyn, mvrel);

			boolean add = movie.AddMovie(m);

			if (add == true) {
				ArrayList<Movie> c = movie.getMovies();
				sn.setAttribute("MvTable", c);
				sn.setAttribute("AddMovie", "true");
				target = "MovieMgmt.jsp";
			} else {
				sn.setAttribute("AddMovie", "false");
				target = "AddMovie.jsp";
			}

			break;
		}

		case "moviedetails": {
			int mvid = Integer.valueOf(request.getParameter("mvid"));
			String mvname = request.getParameter("mvname");
			String mvcat = request.getParameter("mvcat");
			String mvlang = request.getParameter("mvlang");
			String mvdur = request.getParameter("mvdur");
			String mvgen = request.getParameter("mvgen");
			String mvcr = request.getParameter("mvcr");
			String mvimg = request.getParameter("mvimg");
			String mvdir = request.getParameter("mvdir");
			String mvcast = request.getParameter("mvcast");
			String mvsyn = request.getParameter("mvsyn");
			String mvrel = request.getParameter("mvrel");

			sn.setAttribute("ModMvrel", mvrel);
			ArrayList<Multiplex> cl = mux.getMultiplex();
			sn.setAttribute("MList", cl);

			ArrayList<City> cli = city.getCity();
			sn.setAttribute("CList", cli);

			ArrayList<CityLocMux> clm = mux.getMList();
			sn.setAttribute("CMList", clm);

			sn.setAttribute("ModMvid", mvid);
			sn.setAttribute("ModMvname", mvname);
			sn.setAttribute("ModMvcat", mvcat);
			sn.setAttribute("ModMvlang", mvlang);
			sn.setAttribute("ModMvdur", mvdur);
			sn.setAttribute("ModMvgen", mvgen);
			sn.setAttribute("ModMvcr", mvcr);

			sn.setAttribute("ModMvimg", mvimg);

			sn.setAttribute("ModMvdir", mvdir);
			sn.setAttribute("ModMvcast", mvcast);
			sn.setAttribute("ModMvsyn", mvsyn);
			sn.setAttribute("TOpSelect", "All");
			ArrayList<Theatre> c = ts.SearchTheatreByMv(mvid);
			sn.setAttribute("TList", c);
			sn.setAttribute("ModMv", "true");
			target = "MovieDetails.jsp";
			break;

		}

		case "searchtheatre": {

			String mname = request.getParameter("mname");
			String mvname = request.getParameter("mvname");
			int mvid = movie.getMid(mvname);
			String op = request.getParameter("search");
			System.out.println(op + 123456);
			System.out.println(mname + 99999);

			target = "MovieDetails.jsp";

			if (op.equals("All")) {
				ArrayList<Theatre> c = ts.SearchTheatreByMv(mvid);
				sn.setAttribute("TList", c);
				sn.setAttribute("TOpSelect", "All");
			}

			if (op.equals("Multiplex Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Theatre> c = ts.SearchTheatreByMux(id);
				sn.setAttribute("TList", c);
				sn.setAttribute("TOpSelect", "Multiplex Id");
			}

			if (op.equals("City Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Theatre> c = ts.SearchTheatreByCity(id);
				sn.setAttribute("TList", c);
				sn.setAttribute("TOpSelect", "City Id");
			}

			break;
		}

		case "SearchTheatre": {

			String mname = request.getParameter("mname");
			String op = request.getParameter("search");
			System.out.println(op + 123456);
			System.out.println(mname + 99999);

			target = "TheatreMgmt.jsp";

			if (op.equals("All")) {
				ArrayList<Theatre> c = ts.getTheatre();
				sn.setAttribute("TList", c);
				sn.setAttribute("TOpSelect", "All");
			}

			if (op.equals("Multiplex Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Theatre> c = ts.SearchTheatreByMux(id);
				sn.setAttribute("TList", c);
				sn.setAttribute("TOpSelect", "Multiplex Id");
			}

			if (op.equals("City Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Theatre> c = ts.SearchTheatreByCity(id);
				sn.setAttribute("TList", c);
				sn.setAttribute("TOpSelect", "City Id");
			}

			break;
		}
		case "modifytheatre": {
			String tid = request.getParameter("tid");
			String mvid = request.getParameter("mvid");
			int mxid = Integer.valueOf(request.getParameter("mxid"));

			String mxname = mux.getMxname(mxid);

			String mcid = request.getParameter("mcid");
			String mvmorn = request.getParameter("mvmorn");
			String mvmat = request.getParameter("mvmat");
			String mvsec = request.getParameter("mvsec");
			String mvsd = request.getParameter("mvsd");
			String mved = request.getParameter("mved");
			String mvs = request.getParameter("mvs");
			String mvp = request.getParameter("mvp");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			mvsd = LocalDate.parse(mvsd, formatter).format(formatter2);
			mved = LocalDate.parse(mved, formatter).format(formatter2);

			sn.setAttribute("ModTid", tid);
			sn.setAttribute("ModMvid", mvid);
			sn.setAttribute("ModMxid", mxid);
			sn.setAttribute("ModMxname", mxname);
			sn.setAttribute("ModMcid", mcid);
			sn.setAttribute("ModMvmorn", mvmorn);
			sn.setAttribute("ModMvmat", mvmat);
			sn.setAttribute("ModMvsec", mvsec);
			sn.setAttribute("ModMvsd", mvsd);
			sn.setAttribute("ModMved", mved);
			sn.setAttribute("ModMvs", mvs);
			sn.setAttribute("ModMvp", mvp);

			sn.setAttribute("ModT", "true");
			target = "ModifyTheatre.jsp";
			break;
		}

		case "modifytheatre1": {
			String tid = request.getParameter("tid");
			String mvid = request.getParameter("mvid");
			int mxid = Integer.valueOf(request.getParameter("mxid"));

			String mxname = mux.getMxname(mxid);

			String mcid = request.getParameter("mcid");
			String mvmorn = request.getParameter("mvmorn");
			String mvmat = request.getParameter("mvmat");
			String mvsec = request.getParameter("mvsec");
			String mvsd = request.getParameter("mvsd");
			String mved = request.getParameter("mved");
			String mvs = request.getParameter("mvs");
			String mvp = request.getParameter("mvp");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			mvsd = LocalDate.parse(mvsd, formatter).format(formatter2);
			mved = LocalDate.parse(mved, formatter).format(formatter2);

			sn.setAttribute("ModTid", tid);
			sn.setAttribute("ModMvid", mvid);
			sn.setAttribute("ModMxid", mxid);
			sn.setAttribute("ModMxname", mxname);
			sn.setAttribute("ModMcid", mcid);
			sn.setAttribute("ModMvmorn", mvmorn);
			sn.setAttribute("ModMvmat", mvmat);
			sn.setAttribute("ModMvsec", mvsec);
			sn.setAttribute("ModMvsd", mvsd);
			sn.setAttribute("ModMved", mved);
			sn.setAttribute("ModMvs", mvs);
			sn.setAttribute("ModMvp", mvp);

			sn.setAttribute("ModT", "true");
			target = "ModifyTheatre1.jsp";
			break;
		}
		case "deletingtheatre1": {
			String tid = request.getParameter("tid");
			String mvid = request.getParameter("mvid");
			String mxid = request.getParameter("mxid");
			String mcid = request.getParameter("mcid");
			String mvmorn = request.getParameter("mvmorn");
			String mvmat = request.getParameter("mvmat");
			String mvsec = request.getParameter("mvsec");
			String mvsd = request.getParameter("mvsd");
			String mved = request.getParameter("mved");
			String mvs = request.getParameter("mvs");
			String mvp = request.getParameter("mvp");

			sn.setAttribute("ModTid", tid);
			sn.setAttribute("ModMvid", mvid);
			sn.setAttribute("ModMxid", mxid);
			sn.setAttribute("ModMcid", mcid);
			sn.setAttribute("ModMvmorn", mvmorn + " AM");
			sn.setAttribute("ModMvmat", mvmat + " PM");
			sn.setAttribute("ModMvsec", mvsec + " PM");
			sn.setAttribute("ModMvsd", mvsd);
			sn.setAttribute("ModMved", mved);
			sn.setAttribute("ModMvs", mvs);
			sn.setAttribute("ModMvp", mvp);

			sn.setAttribute("ModT", "true");
			target = "DeleteTheatre1.jsp";
			break;
		}

		case "deletingtheatre": {
			String tid = request.getParameter("tid");
			String mvid = request.getParameter("mvid");
			String mxid = request.getParameter("mxid");
			String mcid = request.getParameter("mcid");
			String mvmorn = request.getParameter("mvmorn");
			String mvmat = request.getParameter("mvmat");
			String mvsec = request.getParameter("mvsec");
			String mvsd = request.getParameter("mvsd");
			String mved = request.getParameter("mved");
			String mvs = request.getParameter("mvs");
			String mvp = request.getParameter("mvp");

			sn.setAttribute("ModTid", tid);
			sn.setAttribute("ModMvid", mvid);
			sn.setAttribute("ModMxid", mxid);
			sn.setAttribute("ModMcid", mcid);
			sn.setAttribute("ModMvmorn", mvmorn + " AM");
			sn.setAttribute("ModMvmat", mvmat + " PM");
			sn.setAttribute("ModMvsec", mvsec + " PM");
			sn.setAttribute("ModMvsd", mvsd);
			sn.setAttribute("ModMved", mved);
			sn.setAttribute("ModMvs", mvs);
			sn.setAttribute("ModMvp", mvp);

			sn.setAttribute("ModT", "true");
			target = "DeleteTheatre.jsp";
			break;
		}
		case "Update Theatre": {
			int mvid = Integer.valueOf(request.getParameter("mvid"));
			int tid = Integer.valueOf(request.getParameter("tid"));
			String mxname = request.getParameter("mxid");

			int mxid = mux.getMxid(mxname);
			int mcid = mux.getCid(mxname);

			String mvmorn = request.getParameter("mvmorn");
			String mvmat = request.getParameter("mvmat");
			String mvsec = request.getParameter("mvsec");
			String mvsd = request.getParameter("mvsd");
			String mved = request.getParameter("mved");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			mvsd = LocalDate.parse(mvsd, formatter).format(formatter2);
			mved = LocalDate.parse(mved, formatter).format(formatter2);

			int mvs = Integer.valueOf(request.getParameter("mvs"));
			int mvp = Integer.valueOf(request.getParameter("mvp"));

			Theatre m = new Theatre(tid, mvid, mxid, mcid, mvmorn, mvmat, mvsec, mvsd, mved, mvs, mvp);

			boolean mod = ts.ModifyTheatre(m);
			ArrayList<Theatre> c = ts.SearchTheatreByMv(mvid);

			if (mod == true) {
				sn.setAttribute("TList", c);
				target = "MovieDetails.jsp";
				sn.setAttribute("ModT", "true");
			} else {
				sn.setAttribute("ModT", "false");
				target = "ModifyTheatre.jsp";
			}

			break;
		}

		case "update Theatre": {
			int mvid = Integer.valueOf(request.getParameter("mvid"));
			int tid = Integer.valueOf(request.getParameter("tid"));
			String mxname = request.getParameter("mxid");

			int mxid = mux.getMxid(mxname);
			int mcid = mux.getCid(mxname);

			String mvmorn = request.getParameter("mvmorn");
			String mvmat = request.getParameter("mvmat");
			String mvsec = request.getParameter("mvsec");
			String mvsd = request.getParameter("mvsd");
			String mved = request.getParameter("mved");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			mvsd = LocalDate.parse(mvsd, formatter).format(formatter2);
			mved = LocalDate.parse(mved, formatter).format(formatter2);

			int mvs = Integer.valueOf(request.getParameter("mvs"));
			int mvp = Integer.valueOf(request.getParameter("mvp"));

			Theatre m = new Theatre(tid, mvid, mxid, mcid, mvmorn, mvmat, mvsec, mvsd, mved, mvs, mvp);

			boolean mod = ts.ModifyTheatre(m);
			ArrayList<Theatre> c = ts.getTheatre();

			if (mod == true) {
				sn.setAttribute("TList", c);
				target = "TheatreMgmt.jsp";
				sn.setAttribute("ModT", "true");
			} else {
				sn.setAttribute("ModT", "false");
				target = "ModifyTheatre1.jsp";
			}

			break;
		}

		case "Delete Theatre": {
			int mvid = Integer.valueOf(request.getParameter("tid"));
			System.out.println(mvid);
			ts.DelTheatre(mvid);
			ArrayList<Theatre> c = ts.SearchTheatreByMv(mvid);
			sn.setAttribute("TList", c);
			target = "MovieDetails.jsp";
			break;
		}

		case "delete Theatre": {
			int mvid = Integer.valueOf(request.getParameter("tid"));
			System.out.println(mvid);
			ts.DelTheatre(mvid);
			ArrayList<Theatre> c = ts.getTheatre();
			sn.setAttribute("TList", c);
			target = "TheatreMgmt.jsp";
			break;
		}

		case "Add Theatre": {

			String mxname = request.getParameter("mxid");

			int mcid = mux.getCid(mxname);
			int mxid = mux.getLid(mxname);
			int mvid = Integer.valueOf(request.getParameter("mvid"));
			String mvmorn = request.getParameter("mvmorn");
			String mvmat = request.getParameter("mvmat");
			String mvsec = request.getParameter("mvsec");
			String mvsd = request.getParameter("mvsd");
			String mved = request.getParameter("mved");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			mvsd = LocalDate.parse(mvsd, formatter).format(formatter2);
			mved = LocalDate.parse(mved, formatter).format(formatter2);

			int mvs = Integer.valueOf(request.getParameter("mvs"));
			int mvp = Integer.valueOf(request.getParameter("mvp"));

			System.out.println(mcid);
			System.out.println(mxid);
			System.out.println(mvid);
			System.out.println(mvmorn);
			System.out.println(mvmat);
			System.out.println(mvsec);
			System.out.println(mvsd);
			System.out.println(mved);
			System.out.println(mvs);
			System.out.println(mvp);

			Theatre m = new Theatre(0, mvid, mxid, mcid, mvmorn, mvmat, mvsec, mvsd, mved, mvs, mvp);

			boolean add = ts.AddTheatre(m);

			if (add == true) {
				ArrayList<Theatre> c = ts.getTheatre();
				sn.setAttribute("TList", c);
				sn.setAttribute("AddTheatre", "true");
				target = "MovieDetails.jsp";
			} else {
				sn.setAttribute("AddTheatre", "false");
				target = "AddTheatre.jsp";
			}

			break;
		}

		case "searchbooking": {

			String mname = request.getParameter("mname");
			String op = request.getParameter("search");
			System.out.println(op + 123456);
			System.out.println(mname + 99999);

			target = "BookingMgmt.jsp";

			if (op.equals("All")) {
				ArrayList<Booking> c = book.getBookings();
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "All");
			}

			if (op.equals("Multiplex Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Booking> c = book.SearchBookingMxid(id);
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "Multiplex Id");
			}

			if (op.equals("Cust Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Booking> c = book.SearchBookingCid(id);
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "Cust Id");
			}

			if (op.equals("Booking Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Booking> c = book.SearchBookingBid(id);
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "Booking Id");
			}

			if (op.equals("Movie Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Booking> c = book.SearchBookingMid(id);
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "Movie Id");
			}

			break;
		}

		case "searchbookings": {

			String mname = request.getParameter("mname");
			String op = request.getParameter("search");
			System.out.println(op + 123456);
			System.out.println(mname + 99999);

			target = "SuperBooking.jsp";

			if (op.equals("All")) {
				ArrayList<Booking> c = book.getBookings();
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "All");
			}

			if (op.equals("Multiplex Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Booking> c = book.SearchBookingMxid(id);
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "Multiplex Id");
			}

			if (op.equals("Cust Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Booking> c = book.SearchBookingCid(id);
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "Cust Id");
			}

			if (op.equals("Booking Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Booking> c = book.SearchBookingBid(id);
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "Booking Id");
			}

			if (op.equals("Movie Id")) {
				int id = Integer.valueOf(request.getParameter("mname"));
				ArrayList<Booking> c = book.SearchBookingMid(id);
				sn.setAttribute("BTable", c);
				sn.setAttribute("BOpSelect", "Movie Id");
			}

			break;
		}

		case "modifybooking": {
			String bid = request.getParameter("bid");
			String cid = request.getParameter("cid");
			String tid = request.getParameter("tid");
			String mxid = request.getParameter("mxid");
			String mvid = request.getParameter("mvid");
			String showd = request.getParameter("showd");
			String showt = request.getParameter("showt");
			String seats = request.getParameter("seats");
			String screen = request.getParameter("screen");
			String price = request.getParameter("phone");

			sn.setAttribute("ModTid", tid);
			sn.setAttribute("ModMvid", mvid);
			sn.setAttribute("ModBid", bid);
			sn.setAttribute("ModCid", cid);
			sn.setAttribute("ModMxid", mxid);
			sn.setAttribute("ModShowd", showd);
			sn.setAttribute("ModShowt", showt);
			sn.setAttribute("ModSeats", seats);
			sn.setAttribute("ModScreen", screen);
			sn.setAttribute("ModPhone", price);

			sn.setAttribute("ModT", "true");
			target = "ModifyBooking.jsp";
			break;
		}

		case "deletingbooking": {
			String bid = request.getParameter("bid");
			String cid = request.getParameter("cid");
			String tid = request.getParameter("tid");
			String mxid = request.getParameter("mxid");
			String mvid = request.getParameter("mvid");
			String showd = request.getParameter("showd");
			String showt = request.getParameter("showt");
			String seats = request.getParameter("seats");
			String screen = request.getParameter("screen");
			String price = request.getParameter("phone");

			sn.setAttribute("ModTid", tid);
			sn.setAttribute("ModMvid", mvid);
			sn.setAttribute("ModBid", bid);
			sn.setAttribute("ModCid", cid);
			sn.setAttribute("ModMxid", mxid);
			sn.setAttribute("ModShowd", showd);
			sn.setAttribute("ModShowt", showt);
			sn.setAttribute("ModSeats", seats);
			sn.setAttribute("ModScreen", screen);
			sn.setAttribute("ModPhone", price);

			sn.setAttribute("ModT", "true");
			target = "DeleteBooking.jsp";
			break;
		}

		case "Update Booking": {
			int bid = Integer.valueOf(request.getParameter("bid"));
			int cid = Integer.valueOf(request.getParameter("cid"));
			int tid = Integer.valueOf(request.getParameter("tid"));
			int mxid = Integer.valueOf(request.getParameter("mxid"));
			int mvid = Integer.valueOf(request.getParameter("mvid"));
			String showd = request.getParameter("showd");
			String showt = request.getParameter("showt");
			String seats = request.getParameter("seats");
			int screen = Integer.valueOf(request.getParameter("screen"));
			String phone = request.getParameter("phone");

			Booking b = new Booking(bid, cid, tid, mxid, mvid, showd, showt, seats, phone, screen);

			boolean mod = book.ModifyBooking(b);
			ArrayList<Booking> c = book.getBookings();

			if (mod == true) {
				sn.setAttribute("BTable", c);
				target = "BookingMgmt.jsp";
				sn.setAttribute("ModT", "true");
			} else {
				sn.setAttribute("ModT", "false");
				target = "ModifyBooking.jsp";
			}

			break;
		}

		case "Delete Booking": {
			int bid = Integer.valueOf(request.getParameter("bid"));
			System.out.println(bid);
			book.CancelTicket(bid);
			ArrayList<Booking> c = book.getBookings();
			sn.setAttribute("BTable", c);
			target = "BookingMgmt.jsp";
			break;
		}

		case "Cancel Ticket": {
			int bid = Integer.valueOf(request.getParameter("bid"));
			System.out.println(bid);
			book.CancelTicket(bid);
			ArrayList<Ticket> al = book.ShowTicket(203);
			System.out.println(al);
			sn.setAttribute("Ticket", al);
			target = "AdminBookings.jsp";
			break;
		}

		case "canceltkt": {
			int bid = Integer.valueOf(request.getParameter("bid"));
			int cid = Integer.valueOf(request.getParameter("cid"));
			String img = request.getParameter("img");
			String mname = request.getParameter("mname");
			String cen = request.getParameter("cen");
			String lang = request.getParameter("lang");
			String cat = request.getParameter("cat");
			String dur = request.getParameter("dur");
			String mxname = request.getParameter("mxname");
			String loc = request.getParameter("loc");
			String date = request.getParameter("date");
			String showt = request.getParameter("showt");
			int screen = Integer.valueOf(request.getParameter("screen"));
			String seats = request.getParameter("seats");
			int mxid = Integer.valueOf(request.getParameter("mxid"));

			sn.setAttribute("Bid", bid);
			sn.setAttribute("Custid ", cid);
			sn.setAttribute("Img", img);
			sn.setAttribute("Mname", mname);
			sn.setAttribute("Cen", cen);
			sn.setAttribute("Lang", lang);
			sn.setAttribute("Dur", dur);
			sn.setAttribute("Cat", cat);
			sn.setAttribute("Mxname", mxname);
			sn.setAttribute("Loc", loc);
			sn.setAttribute("Date", date);
			sn.setAttribute("Showt", showt);
			sn.setAttribute("Screen", screen);
			sn.setAttribute("Seats", seats);
			sn.setAttribute("Mxid ", mxid);

			target = "CancelTicket.jsp";
			break;
		}

		default:
			target = "Homepage.jsp";

		}

		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
