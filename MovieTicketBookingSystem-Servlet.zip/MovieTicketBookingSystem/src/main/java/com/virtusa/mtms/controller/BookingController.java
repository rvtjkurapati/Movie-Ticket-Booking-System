package com.virtusa.mtms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.mtms.dto.Multiplex;
import com.virtusa.mtms.dto.Seats;
import com.virtusa.mtms.service.IBookingServiceImpl;

@WebServlet("/Booking")
public class BookingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BookingController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession sn = request.getSession();

		String seatno = request.getParameter("seatno");
		String seats = request.getParameter("seats");
		String tp = request.getParameter("tp");
		String show = request.getParameter("show");
		String screen = request.getParameter("screen");
		System.out.println(seatno);
		System.out.println(seatno);
		System.out.println(seatno);
		System.out.println(seatno);
		System.out.println(seatno);

		sn.setAttribute("FCount", tp);
		sn.setAttribute("FSeats", seats);
		sn.setAttribute("FSno", seatno);
		sn.setAttribute("Show", show);
		sn.setAttribute("Screen", screen);

		RequestDispatcher rd = request.getRequestDispatcher("Payment.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
