package com.virtusa.mtms.dto;

public class Movie {

	int mid;
	String mname;
	String Category;
	String lang;
	String duration;
	String genre;
	String censor;
	String image;
	String dir;
	String cast;
	String syn;
	String relDate;

	public Movie() {
		super();
	}

	public Movie(int mid, String mname, String category, String lang, String duration, String genre, String censor,
			String image, String dir, String cast, String syn, String relDate) {
		super();
		this.mid = mid;
		this.mname = mname;
		Category = category;
		this.lang = lang;
		this.duration = duration;
		this.genre = genre;
		this.censor = censor;
		this.image = image;
		this.dir = dir;
		this.cast = cast;
		this.syn = syn;
		this.relDate = relDate;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getCensor() {
		return censor;
	}

	public void setCensor(String censor) {
		this.censor = censor;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDir() {
		return dir;
	}

	public void setDir(String dir) {
		this.dir = dir;
	}

	public String getCast() {
		return cast;
	}

	public void setCast(String cast) {
		this.cast = cast;
	}

	public String getSyn() {
		return syn;
	}

	public void setSyn(String syn) {
		this.syn = syn;
	}

	public String getRelDate() {
		return relDate;
	}

	public void setRelDate(String relDate) {
		this.relDate = relDate;
	}

	@Override
	public String toString() {
		return "Movie [mid=" + mid + ", mname=" + mname + ", Category=" + Category + ", lang=" + lang + ", duration="
				+ duration + ", genre=" + genre + ", censor=" + censor + ", image=" + image + ", dir=" + dir + ", cast="
				+ cast + ", syn=" + syn + ", relDate=" + relDate + "]";
	}

}
