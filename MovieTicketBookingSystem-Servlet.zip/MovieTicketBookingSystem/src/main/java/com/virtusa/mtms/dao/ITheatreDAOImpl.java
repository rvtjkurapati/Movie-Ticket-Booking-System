package com.virtusa.mtms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

import com.virtusa.mtms.dto.Movie;
import com.virtusa.mtms.dto.PresentMovie;
import com.virtusa.mtms.dto.Show;
import com.virtusa.mtms.dto.Theatre;
import com.virtusa.mtms.util.DbConnection;

public class ITheatreDAOImpl {

	public boolean AddTheatre(Theatre m) {
		try {
			Connection con = DbConnection.getConnection();
			int stop = 0;
			String cmd17 = "select * from multiplex where multiplexId=?";
			PreparedStatement ps17 = con.prepareStatement(cmd17);
			ps17.setInt(1, m.getMplexid());
			ResultSet rs17 = ps17.executeQuery();

			String cmd18 = "select * from theatre where multiplexId=? and screen=? ";
			PreparedStatement ps18 = con.prepareStatement(cmd18);
			ps18.setInt(1, m.getMplexid());
			ps18.setInt(2, m.getScreen());
			ResultSet rs18 = ps18.executeQuery();
			while (rs18.next()) {

				String cmd19 = " select * from theatre where multiplexId=? and screen=?  and ( start_date <= ?  and end_date>=?) ;";
				PreparedStatement ps19 = con.prepareStatement(cmd19);
				ps19.setInt(1, m.getMplexid());
				ps19.setInt(2, m.getScreen());
				String s = m.getEdate();
				String s1 = m.getSdate();
				System.out.println(s);
				System.out.println(s1);
				SimpleDateFormat sdf3 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date date3 = sdf3.parse(s);
				java.util.Date date4 = sdf3.parse(s1);
				java.sql.Date sd1 = new java.sql.Date(date3.getTime());
				java.sql.Date sd2 = new java.sql.Date(date4.getTime());

				ps19.setDate(3, sd1);
				ps19.setDate(4, sd2);
				ResultSet rs19 = ps19.executeQuery();
				while (rs19.next()) {
					stop = 1;

				}

			}

			System.out.println(stop);
			System.out.println(stop);
			System.out.println(stop);
			System.out.println(stop);

			if (rs17.next() && stop == 0) {
				int cid = 0;

				String cmd16 = "select * from multiplex  where multiplexId=?";
				PreparedStatement ps16 = con.prepareStatement(cmd16);

				ps16.setInt(1, m.getMplexid());
				ResultSet rs16 = ps16.executeQuery();
				while (rs16.next()) {

					cid = rs16.getInt(1);
				}

				String cmd2 = "insert into theatre (movieId,morning,matinee,secondshow,start_date,end_date,multiplexId,cityId,screen,price) values(?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, m.getMid());
				ps2.setString(2, m.getShow1());
				ps2.setString(3, m.getShow2());
				ps2.setString(4, m.getShow3());

				String sdate = m.getSdate();
				String edate = m.getEdate();

				SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date date1 = sdf1.parse(sdate);
				java.util.Date date2 = sdf1.parse(edate);

				java.sql.Date sqlStartDate = new java.sql.Date(date1.getTime());
				java.sql.Date sqlEndDate = new java.sql.Date(date2.getTime());

				ps2.setDate(5, sqlStartDate);
				ps2.setDate(6, sqlEndDate);

				ps2.setInt(7, m.getMplexid());
				ps2.setInt(8, cid);

				ps2.setInt(9, m.getScreen());
				ps2.setInt(10, m.getPrice());
				ps2.executeUpdate();

				int mid = m.getMid();

				int tid = 0;

				String cmd10 = "select * from theatre where movieId=? and multiplexId=? and screen=?";
				PreparedStatement ps10 = con.prepareStatement(cmd10);
				ps10.setInt(1, m.getMid());
				ps10.setInt(2, m.getMplexid());
				ps10.setInt(3, m.getScreen());
				ResultSet rs10 = ps10.executeQuery();
				while (rs10.next()) {
					tid = rs10.getInt(1);
				}

				System.out.println("in here");
				String cmd3 = "with recursive Date_Ranges as (select ? as Date union all select date +interval 1 day from Date_Ranges where date < ?) select * from Date_Ranges";
				PreparedStatement ps3 = con.prepareStatement(cmd3);
				System.out.println("in recursive");
				ps3.setDate(1, sqlStartDate);
				ps3.setDate(2, sqlEndDate);
				ResultSet rs3 = ps3.executeQuery();
				while (rs3.next()) {
					String isdate = rs3.getString(1);

					SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");
					java.util.Date date3 = sdf3.parse(isdate);
					java.sql.Date sqlSDate = new java.sql.Date(date3.getTime());
					int mxid = m.getMplexid();
					System.out.println("afterrecursive");
					String cmd5 = "insert into morningseats (movieId,multiplexId,showdate,showtime,A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,B1,B2,B3,B4,B5,B6,B7,B8,B9,B10,B11,B12,C1,C2,C3,C4,C5,C6,C7,C8,C9,C10,C11,C12,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,D11,D12,E1,E2,E3,E4,E5,E6,E7,E8,E9,E10,E11,E12,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,G1,G2,G3,G4,G5,G6,G7,G8,G9,G10,G11,G12,H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,I1,I2,I3,I4,I5,I6,I7,I8,I9,I10,I11,I12,J1,J2,J3,J4,J5,J6,J7,J8,J9,J10,J11,J12,tId) values(?,?,?,?,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,?)";
					PreparedStatement ps5 = con.prepareStatement(cmd5);
					ps5.setInt(1, mid);
					ps5.setInt(2, mxid);
					ps5.setDate(3, sqlSDate);
					ps5.setString(4, m.getShow1());
					ps5.setInt(5, tid);
					System.out.println("in morn");
					ps5.executeUpdate();
					System.out.println("af morn");

					String cmd7 = "insert into matineeseats (movieId,multiplexId,showdate,showtime,A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,B1,B2,B3,B4,B5,B6,B7,B8,B9,B10,B11,B12,C1,C2,C3,C4,C5,C6,C7,C8,C9,C10,C11,C12,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,D11,D12,E1,E2,E3,E4,E5,E6,E7,E8,E9,E10,E11,E12,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,G1,G2,G3,G4,G5,G6,G7,G8,G9,G10,G11,G12,H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,I1,I2,I3,I4,I5,I6,I7,I8,I9,I10,I11,I12,J1,J2,J3,J4,J5,J6,J7,J8,J9,J10,J11,J12,tId) values(?,?,?,?,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,?)";
					PreparedStatement ps7 = con.prepareStatement(cmd7);
					ps7.setInt(1, mid);
					ps7.setInt(2, mxid);
					ps7.setDate(3, sqlSDate);
					ps7.setString(4, m.getShow2());
					ps7.setInt(5, tid);
					ps7.executeUpdate();

					String cmd9 = "insert into secondshowseats (movieId,multiplexId,showdate,showtime,A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,B1,B2,B3,B4,B5,B6,B7,B8,B9,B10,B11,B12,C1,C2,C3,C4,C5,C6,C7,C8,C9,C10,C11,C12,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,D11,D12,E1,E2,E3,E4,E5,E6,E7,E8,E9,E10,E11,E12,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,G1,G2,G3,G4,G5,G6,G7,G8,G9,G10,G11,G12,H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,I1,I2,I3,I4,I5,I6,I7,I8,I9,I10,I11,I12,J1,J2,J3,J4,J5,J6,J7,J8,J9,J10,J11,J12,tId) values(?,?,?,?,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,?)";
					PreparedStatement ps9 = con.prepareStatement(cmd9);
					ps9.setInt(1, mid);
					ps9.setInt(2, mxid);
					ps9.setDate(3, sqlSDate);
					ps9.setString(4, m.getShow3());
					ps9.setInt(5, tid);
					ps9.executeUpdate();

				}
				rs3.close();
				ps3.close();

				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {

			System.out.println(e);
			e.getStackTrace();

		}
		return false;
	}

	public boolean DelTheatre(int m) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from theatre where tId=?;";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, m);
			ResultSet rs = ps1.executeQuery();
			if (rs.next()) {

				String cmd3 = "delete from booking where tId=?;";
				PreparedStatement ps3 = con.prepareStatement(cmd3);
				ps3.setInt(1, m);
				ps3.executeUpdate();

				String cmd4 = "delete from morningseats where tId=?;";
				PreparedStatement ps4 = con.prepareStatement(cmd4);
				ps4.setInt(1, m);
				ps4.executeUpdate();

				String cmd5 = "delete from matineeseats where tId=?;";
				PreparedStatement ps5 = con.prepareStatement(cmd5);
				ps5.setInt(1, m);
				ps5.executeUpdate();

				String cmd6 = "delete from secondshowseats where tId=?;";
				PreparedStatement ps6 = con.prepareStatement(cmd6);
				ps6.setInt(1, m);
				ps6.executeUpdate();

				String cmd2 = "delete from theatre where tId=?;";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, m);
				ps2.executeUpdate();

				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public ArrayList<Theatre> getTheatre() {

		try {
			ArrayList<Theatre> log = new ArrayList<Theatre>();
			Connection con = DbConnection.getConnection();
			String cmd = "select * from theatre";
			PreparedStatement ps = con.prepareStatement(cmd);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				int mid = rs.getInt(2);
				int mxid = rs.getInt(3);
				int cid = rs.getInt(4);

				String show1 = rs.getString(5);
				String show2 = rs.getString(6);
				String show3 = rs.getString(7);

				String sdate = rs.getString(8);
				String edate = rs.getString(9);
				String sd = sdate;
				String ed = edate;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				String s = LocalDate.parse(sd, formatter).format(formatter2);
				String e = LocalDate.parse(ed, formatter).format(formatter2);

				int screen = rs.getInt(10);
				int price = rs.getInt(11);

				Theatre l = new Theatre(id, mid, mxid, cid, show1, show2, show3, s, e, screen, price);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println("get mv");
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Show> getTheatreByMid(int bmid) {

		try {
			ArrayList<Show> log = new ArrayList<Show>();
			Connection con = DbConnection.getConnection();
			String cmd = "select * from theatre where movieId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, bmid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				int mid = rs.getInt(2);
				int mxid = rs.getInt(3);
				int cid = rs.getInt(4);

				String show1 = rs.getString(5);
				String show2 = rs.getString(6);
				String show3 = rs.getString(7);

				String sdate = rs.getString(8);
				String edate = rs.getString(9);

				int screen = rs.getInt(10);
				int price = rs.getInt(11);

				String cmd1 = "select * from multiplex where multiplexId=?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, mxid);
				ResultSet rs1 = ps1.executeQuery();
				int lid = 0;
				String mxname = "";
				String add = "";
				String img = "";
				while (rs1.next()) {
					lid = rs1.getInt(2);
					mxname = rs1.getString(3);
					add = rs1.getString(5);
				}

				String cmd2 = "select * from city where cityId=?";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, cid);
				ResultSet rs2 = ps2.executeQuery();
				String cname = "";
				while (rs2.next()) {
					cname = rs2.getString(2);
				}

				String cmd3 = "select * from multiplex where multiplexId=?";
				PreparedStatement ps3 = con.prepareStatement(cmd3);
				ps3.setInt(1, mxid);
				ResultSet rs3 = ps3.executeQuery();
				String lname = "";
				while (rs3.next()) {
					lname = rs3.getString(3);
				}

				Show l = new Show(id, mid, mxid, cid, show1, show2, show3, sdate, edate, screen, price, lid, mxname,
						add, img, cname, lname);
				log.add(l);
				System.out.println(l + "ram thara ram pam");

			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<PresentMovie> getLatestMovies(String name) {

		try {
			ArrayList<PresentMovie> log = new ArrayList<PresentMovie>();
			Connection con = DbConnection.getConnection();

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date date = new Date();
			String s = formatter.format(date);

			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date1 = sdf1.parse(s);
			java.sql.Date sqlDate = new java.sql.Date(date1.getTime());

			String cmd2 = "select cityId from city where cityname=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setString(1, name);
			ResultSet rs2 = ps2.executeQuery();
			int ctid = 0;
			while (rs2.next()) {

				ctid = rs2.getInt(1);

			}

			int id = 0;
			String mname = "";
			String cat = "";
			String lang = "";
			String dur = "";
			String gen = "";
			String cen = "";

			String dir = "";
			String cast = "";
			String syn = "";
			String img = "";

			int mid = 0;
			int mxid = 0;
			int cid = 0;
			String show1 = "";
			String show2 = "";
			String show3 = "";
			String sdate = "";
			String edate = "";

			int screen = 0;
			int price = 0;

			String cmd = "select * from theatre where (? >= start_date) and cityId=? order by start_date desc";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setDate(1, sqlDate);
			ps.setInt(2, ctid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				mid = rs.getInt(2);
				mxid = rs.getInt(3);
				cid = rs.getInt(4);
				show1 = rs.getString(5);
				show2 = rs.getString(6);
				show3 = rs.getString(7);
				sdate = rs.getString(8);
				edate = rs.getString(9);

				screen = rs.getInt(10);
				price = rs.getInt(11);

				String cmd3 = "select * from movie where movieId=?";
				PreparedStatement ps3 = con.prepareStatement(cmd3);
				ps3.setInt(1, mid);
				ResultSet rs3 = ps3.executeQuery();

				while (rs3.next()) {

					id = rs3.getInt(1);
					mname = rs3.getString(2);
					cat = rs3.getString(3);
					lang = rs3.getString(4);
					dur = rs3.getString(5);
					gen = rs3.getString(6);
					cen = rs3.getString(7);
					dir = rs3.getString(8);
					cast = rs3.getString(9);
					syn = rs3.getString(10);
					img = rs3.getString(11);
				}

				PresentMovie l = new PresentMovie(id, mname, cat, lang, dur, gen, cen, show1, show2, show3, sdate,
						edate, mxid, cid, screen, price, img, dir, cast, syn);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println("lat mv");
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Movie> getAllLatestMovies() {

		try {
			ArrayList<Movie> log = new ArrayList<Movie>();
			Connection con = DbConnection.getConnection();

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date date = new Date();
			String s = formatter.format(date);

			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date1 = sdf1.parse(s);
			java.sql.Date sqlDate = new java.sql.Date(date1.getTime());
			System.out.println(sqlDate + "arigatho");

			String cmd = "select * from movie where (? >= relDate) order by relDate desc";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setDate(1, sqlDate);

			ResultSet rs3 = ps.executeQuery();

			while (rs3.next()) {

				int id = rs3.getInt(1);
				String mname = rs3.getString(2);
				String cat = rs3.getString(3);
				String lang = rs3.getString(4);
				String dur = rs3.getString(5);
				String gen = rs3.getString(6);
				String cen = rs3.getString(7);
				String dir = rs3.getString(8);
				String cast = rs3.getString(9);
				String syn = rs3.getString(10);
				String img = rs3.getString(11);
				String rel = rs3.getString(12);
				Movie l = new Movie(id, mname, cat, lang, dur, gen, cen, img, dir, cast, syn, rel);
				log.add(l);
				System.out.println(l);
			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println("all lat mv");
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<PresentMovie> getUpcomingMovies(String name) {

		try {
			ArrayList<PresentMovie> log = new ArrayList<PresentMovie>();
			Connection con = DbConnection.getConnection();

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date date = new Date();
			String s = formatter.format(date);

			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date1 = sdf1.parse(s);
			java.sql.Date sqlDate = new java.sql.Date(date1.getTime());

			String cmd2 = "select cityId from city where cityname=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setString(1, name);
			ResultSet rs2 = ps2.executeQuery();
			int ctid = 0;
			while (rs2.next()) {

				ctid = rs2.getInt(1);

			}

			int id = 0;
			String mname = "";
			String cat = "";
			String lang = "";
			String dur = "";
			String gen = "";
			String cen = "";

			String dir = "";
			String cast = "";
			String syn = "";
			String img = "";

			int mid = 0;
			int mxid = 0;
			int cid = 0;
			String show1 = "";
			String show2 = "";
			String show3 = "";
			String sdate = "";
			String edate = "";

			int screen = 0;
			int price = 0;

			String cmd = "select * from theatre where (? < start_date) and cityId=? order by start_date desc";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setDate(1, sqlDate);
			ps.setInt(2, ctid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				mid = rs.getInt(2);
				mxid = rs.getInt(3);
				cid = rs.getInt(4);
				show1 = rs.getString(5);
				show2 = rs.getString(6);
				show3 = rs.getString(7);
				sdate = rs.getString(8);
				edate = rs.getString(9);

				screen = rs.getInt(10);
				price = rs.getInt(11);

				String cmd3 = "select * from movie where movieId=?";
				PreparedStatement ps3 = con.prepareStatement(cmd3);
				ps3.setInt(1, mid);
				ResultSet rs3 = ps3.executeQuery();

				while (rs3.next()) {

					id = rs3.getInt(1);
					mname = rs3.getString(2);
					cat = rs3.getString(3);
					lang = rs3.getString(4);
					dur = rs3.getString(5);
					gen = rs3.getString(6);
					cen = rs3.getString(7);
					dir = rs3.getString(8);
					cast = rs3.getString(9);
					syn = rs3.getString(10);
					img = rs3.getString(11);
				}

				PresentMovie l = new PresentMovie(id, mname, cat, lang, dur, gen, cen, show1, show2, show3, sdate,
						edate, mxid, cid, screen, price, img, dir, cast, syn);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println("up mv");
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Movie> getAllUpcomingMovies() {

		try {
			ArrayList<Movie> log = new ArrayList<Movie>();
			Connection con = DbConnection.getConnection();

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date date = new Date();
			String s = formatter.format(date);

			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date1 = sdf1.parse(s);
			java.sql.Date sqlDate = new java.sql.Date(date1.getTime());

			String cmd = "select * from movie where (? <= relDate) order by relDate desc";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setDate(1, sqlDate);

			ResultSet rs3 = ps.executeQuery();

			while (rs3.next()) {

				int id = rs3.getInt(1);
				String mname = rs3.getString(2);
				String cat = rs3.getString(3);
				String lang = rs3.getString(4);
				String dur = rs3.getString(5);
				String gen = rs3.getString(6);
				String cen = rs3.getString(7);
				String dir = rs3.getString(8);
				String cast = rs3.getString(9);
				String syn = rs3.getString(10);
				String img = rs3.getString(11);
				String rel = rs3.getString(12);
				Movie l = new Movie(id, mname, cat, lang, dur, gen, cen, img, dir, cast, syn, rel);
				log.add(l);
			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println("All up mv");
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public boolean ModifyTheatre(Theatre m) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from theatre where tId=?;";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, m.getTid());
			ResultSet rs1 = ps1.executeQuery();

			String cmd17 = "select * from multiplex  where multiplexId=?";
			PreparedStatement ps17 = con.prepareStatement(cmd17);
			ps17.setInt(1, m.getMplexid());
			ResultSet rs17 = ps17.executeQuery();

			String cmd21 = "select * from movie  where movieId=?";
			PreparedStatement ps21 = con.prepareStatement(cmd21);
			ps21.setInt(1, m.getMid());
			ResultSet rs21 = ps21.executeQuery();

			int stop = 0;
			String cmd18 = "select * from theatre where multiplexId=? and screen=? ";
			PreparedStatement ps18 = con.prepareStatement(cmd18);
			ps18.setInt(1, m.getMplexid());
			ps18.setInt(2, m.getScreen());
			ResultSet rs18 = ps18.executeQuery();
			while (rs18.next()) {

				String cmd19 = " select * from theatre where multiplexId=? and screen=?  and ( start_date <= ?  and end_date>=?) and tId!=?;";
				PreparedStatement ps19 = con.prepareStatement(cmd19);
				ps19.setInt(1, m.getMplexid());
				ps19.setInt(2, m.getScreen());

				String s = m.getEdate();
				String s1 = m.getSdate();

				System.out.println(s);
				System.out.println(s1);

				SimpleDateFormat sdf3 = new SimpleDateFormat("dd-MM-yyyy");

				java.util.Date date3 = sdf3.parse(s);
				java.util.Date date4 = sdf3.parse(s1);

				java.sql.Date sd1 = new java.sql.Date(date3.getTime());
				java.sql.Date sd2 = new java.sql.Date(date4.getTime());

				ps19.setDate(3, sd1);
				ps19.setDate(4, sd2);
				ps19.setInt(5, m.getTid());
				ResultSet rs19 = ps19.executeQuery();
				while (rs19.next()) {
					stop = 1;

				}

			}

			int cid = 0;
			String cmd16 = "select cityId from multiplex  where multiplexId=?";
			PreparedStatement ps16 = con.prepareStatement(cmd16);

			ps16.setInt(1, m.getMplexid());
			ResultSet rs16 = ps16.executeQuery();
			while (rs16.next()) {

				cid = rs16.getInt(1);
			}

			if (rs17.next() && stop == 0 && rs1.next() && rs21.next()) {

				String cmd = "update  theatre  set movieId=?,multiplexId=?,cityId=?,morning=?,matinee=?,secondshow=?,start_date=?,end_date=?,screen=?,price=? where tId=?;";
				PreparedStatement ps = con.prepareStatement(cmd);
				ps.setInt(1, m.getMid());
				ps.setInt(2, m.getMplexid());
				ps.setInt(3, cid);
				ps.setString(4, m.getShow1());
				ps.setString(5, m.getShow2());
				ps.setString(6, m.getShow3());
				String sdate = m.getSdate();
				String edate = m.getEdate();

				SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date date1 = sdf1.parse(sdate);
				java.util.Date date2 = sdf1.parse(edate);

				java.sql.Date sqlStartDate = new java.sql.Date(date1.getTime());
				java.sql.Date sqlEndDate = new java.sql.Date(date2.getTime());

				ps.setDate(7, sqlStartDate);
				ps.setDate(8, sqlEndDate);
				ps.setInt(9, m.getScreen());
				ps.setInt(10, m.getPrice());
				ps.setInt(11, m.getTid());
				ps.executeUpdate();

				String cmd7 = "delete from  booking  where tId=?;";
				PreparedStatement ps7 = con.prepareStatement(cmd7);
				ps7.setInt(1, m.getTid());
				ps7.executeUpdate();

				String cmd3 = "with recursive Date_Ranges as (select ? as Date union all select date +interval 1 day from Date_Ranges where date < ?) select * from Date_Ranges";
				PreparedStatement ps3 = con.prepareStatement(cmd3);
				ps3.setDate(1, sqlStartDate);
				ps3.setDate(2, sqlEndDate);
				ResultSet rs3 = ps3.executeQuery();
				while (rs3.next()) {
					String isdate = rs3.getString(1);

					SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");
					java.util.Date date3 = sdf3.parse(isdate);
					java.sql.Date sqlSDate = new java.sql.Date(date3.getTime());

					String cmd5 = "update morningseats set movieId=?,multiplexId=?,showdate=?,showtime=?,A1=1,A2=1,A3=1,A4=1,A5=1,A6=1,A7=1,A8=1,A9=1,A10=1,A11=1,A12=1,B1=1,B2=1,B3=1,B4=1,B5=1,B6=1,B7=1,B8=1,B9=1,B10=1,B11=1,B12=1,C1=1,C2=1,C3=1,C4=1,C5=1,C6=1,C7=1,C8=1,C9=1,C10=1,C11=1,C12=1,D1=1,D2=1,D3=1,D4=1,D5=1,D6=1,D7=1,D8=1,D9=1,D10=1,D11=1,D12=1,E1=1,E2=1,E3=1,E4=1,E5=1,E6=1,E7=1,E8=1,E9=1,E10=1,E11=1,E12=1,F1=1,F2=1,F3=1,F4=1,F5=1,F6=1,F7=1,F8=1,F9=1,F10=1,F11=1,F12=1,G1=1,G2=1,G3=1,G4=1,G5=1,G6=1,G7=1,G8=1,G9=1,G10=1,G11=1,G12=1,H1=1,H2=1,H3=1,H4=1,H5=1,H6=1,H7=1,H8=1,H9=1,H10=1,H11=1,H12=1,I1=1,I2=1,I3=1,I4=1,I5=1,I6=1,I7=1,I8=1,I9=1,I10=1,I11=1,I12=1,J1=1,J2=1,J3=1,J4=1,J5=1,J6=1,J7=1,J8=1,J9=1,J10=1,J11=1,J12=1  where tId=?";
					PreparedStatement ps5 = con.prepareStatement(cmd5);
					ps5.setInt(1, m.getMid());
					ps5.setInt(2, m.getMplexid());
					ps5.setDate(3, sqlSDate);
					ps5.setString(4, m.getShow1());
					ps5.setInt(5, m.getTid());
					ps5.executeUpdate();

					String cmd12 = "update matineeseats set movieId=?,multiplexId=?,showdate=?,showtime=?,A1=1,A2=1,A3=1,A4=1,A5=1,A6=1,A7=1,A8=1,A9=1,A10=1,A11=1,A12=1,B1=1,B2=1,B3=1,B4=1,B5=1,B6=1,B7=1,B8=1,B9=1,B10=1,B11=1,B12=1,C1=1,C2=1,C3=1,C4=1,C5=1,C6=1,C7=1,C8=1,C9=1,C10=1,C11=1,C12=1,D1=1,D2=1,D3=1,D4=1,D5=1,D6=1,D7=1,D8=1,D9=1,D10=1,D11=1,D12=1,E1=1,E2=1,E3=1,E4=1,E5=1,E6=1,E7=1,E8=1,E9=1,E10=1,E11=1,E12=1,F1=1,F2=1,F3=1,F4=1,F5=1,F6=1,F7=1,F8=1,F9=1,F10=1,F11=1,F12=1,G1=1,G2=1,G3=1,G4=1,G5=1,G6=1,G7=1,G8=1,G9=1,G10=1,G11=1,G12=1,H1=1,H2=1,H3=1,H4=1,H5=1,H6=1,H7=1,H8=1,H9=1,H10=1,H11=1,H12=1,I1=1,I2=1,I3=1,I4=1,I5=1,I6=1,I7=1,I8=1,I9=1,I10=1,I11=1,I12=1,J1=1,J2=1,J3=1,J4=1,J5=1,J6=1,J7=1,J8=1,J9=1,J10=1,J11=1,J12=1  where tId=?";
					PreparedStatement ps12 = con.prepareStatement(cmd12);
					ps12.setInt(1, m.getMid());
					ps12.setInt(2, m.getMplexid());
					ps12.setDate(3, sqlSDate);
					ps12.setString(4, m.getShow2());
					ps12.setInt(5, m.getTid());
					ps12.executeUpdate();

					String cmd13 = "update secondshowseats set movieId=?,multiplexId=?,showdate=?,showtime=?,A1=1,A2=1,A3=1,A4=1,A5=1,A6=1,A7=1,A8=1,A9=1,A10=1,A11=1,A12=1,B1=1,B2=1,B3=1,B4=1,B5=1,B6=1,B7=1,B8=1,B9=1,B10=1,B11=1,B12=1,C1=1,C2=1,C3=1,C4=1,C5=1,C6=1,C7=1,C8=1,C9=1,C10=1,C11=1,C12=1,D1=1,D2=1,D3=1,D4=1,D5=1,D6=1,D7=1,D8=1,D9=1,D10=1,D11=1,D12=1,E1=1,E2=1,E3=1,E4=1,E5=1,E6=1,E7=1,E8=1,E9=1,E10=1,E11=1,E12=1,F1=1,F2=1,F3=1,F4=1,F5=1,F6=1,F7=1,F8=1,F9=1,F10=1,F11=1,F12=1,G1=1,G2=1,G3=1,G4=1,G5=1,G6=1,G7=1,G8=1,G9=1,G10=1,G11=1,G12=1,H1=1,H2=1,H3=1,H4=1,H5=1,H6=1,H7=1,H8=1,H9=1,H10=1,H11=1,H12=1,I1=1,I2=1,I3=1,I4=1,I5=1,I6=1,I7=1,I8=1,I9=1,I10=1,I11=1,I12=1,J1=1,J2=1,J3=1,J4=1,J5=1,J6=1,J7=1,J8=1,J9=1,J10=1,J11=1,J12=1  where tId=?";
					PreparedStatement ps13 = con.prepareStatement(cmd13);
					ps13.setInt(1, m.getMid());
					ps13.setInt(2, m.getMplexid());
					ps13.setDate(3, sqlSDate);
					ps13.setString(4, m.getShow2());
					ps13.setInt(5, m.getTid());
					ps13.executeUpdate();

				}
				return true;

			} else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e + "haha");
			e.getStackTrace();
		}

		return false;
	}

	public ArrayList<Theatre> SearchTheatreByCity(int ctid) {

		try {
			ArrayList<Theatre> log = new ArrayList<Theatre>();
			Connection con = DbConnection.getConnection();

			String cmd = "select * from theatre where cityId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, ctid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				int mid = rs.getInt(2);
				int mxid = rs.getInt(3);
				int cid = rs.getInt(4);

				String show1 = rs.getString(5);
				String show2 = rs.getString(6);
				String show3 = rs.getString(7);
				String sdate = rs.getString(8);
				String edate = rs.getString(9);

				int screen = rs.getInt(10);
				int price = rs.getInt(11);

				Theatre l = new Theatre(id, mid, mxid, cid, show1, show2, show3, sdate, edate, screen, price);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println("get mv");
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Theatre> SearchTheatreByMux(int muxid) {

		try {
			ArrayList<Theatre> log = new ArrayList<Theatre>();
			Connection con = DbConnection.getConnection();

			String cmd = "select * from theatre where multiplexId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, muxid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				int mid = rs.getInt(2);
				int mxid = rs.getInt(3);
				int cid = rs.getInt(4);

				String show1 = rs.getString(5);
				String show2 = rs.getString(6);
				String show3 = rs.getString(7);
				String sdate = rs.getString(8);
				String edate = rs.getString(9);

				int screen = rs.getInt(10);
				int price = rs.getInt(11);

				Theatre l = new Theatre(id, mid, mxid, cid, show1, show2, show3, sdate, edate, screen, price);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println("get mv");
			e.getStackTrace();
		}
		return null;
	}

	public ArrayList<Theatre> SearchTheatreByMv(int muxid) {

		try {
			ArrayList<Theatre> log = new ArrayList<Theatre>();
			Connection con = DbConnection.getConnection();

			String cmd = "select * from theatre where movieId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, muxid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				int mid = rs.getInt(2);
				int mxid = rs.getInt(3);
				int cid = rs.getInt(4);

				String show1 = rs.getString(5);
				String show2 = rs.getString(6);
				String show3 = rs.getString(7);

				String sdate = rs.getString(8);
				String edate = rs.getString(9);
				String sd = sdate;
				String ed = edate;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				String s = LocalDate.parse(sd, formatter).format(formatter2);
				String e = LocalDate.parse(ed, formatter).format(formatter2);

				int screen = rs.getInt(10);
				int price = rs.getInt(11);

				Theatre l = new Theatre(id, mid, mxid, cid, show1, show2, show3, s, e, screen, price);
				log.add(l);

			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}

		}

		catch (Exception e) {
			System.out.println("get mv");
			e.getStackTrace();
		}
		return null;
	}

	public int getTid(int mid, int muxid, String showt) {

		try {
			Connection con = DbConnection.getConnection();

			String cmd = "select tId from theatre where movieId=? and multiplexId=? and morning=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, mid);
			ps.setInt(2, muxid);
			ps.setString(3, showt);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);

				return id;
			}
		} catch (Exception e) {
			System.out.println("get mv");
			e.getStackTrace();
		}
		return 0;
	}

	public ArrayList<Movie> searchLmv(String genre, String language) {

		try {
			ArrayList<Movie> log = new ArrayList<Movie>();
			Connection con = DbConnection.getConnection();

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date date = new Date();
			String s = formatter.format(date);

			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date1 = sdf1.parse(s);
			java.sql.Date sqlDate = new java.sql.Date(date1.getTime());

			System.out.println(genre);
			System.out.println(language);
			String cmd = " ";
			PreparedStatement ps = con.prepareStatement(cmd);
			if ((genre.equals("All Genres")) && (language.equals("All Languages"))) {
				cmd = "select * from movie where (? >= relDate) order by relDate desc";
				ps = con.prepareStatement(cmd);
				ps.setDate(1, sqlDate);
			}

			else if ((!genre.equals("All Genres")) && (!language.equals("All Languages"))) {

				cmd = "select * from movie where (? >= relDate)  and lang=? and genre=?  order by relDate desc";
				ps = con.prepareStatement(cmd);
				ps.setDate(1, sqlDate);
				ps.setString(2, language);
				ps.setString(3, genre);

			}

			else if (!(genre.equals("All Genres")) && (language.equals("All Languages"))) {
				System.out.println("hoot");
				cmd = "select * from movie where (? >= relDate)  and genre=? order by relDate desc";
				ps = con.prepareStatement(cmd);
				ps.setDate(1, sqlDate);
				ps.setString(2, genre);

			}

			else if ((genre.equals("All Genres")) && !(language.equals("All Languages"))) {
				System.out.println("hoot");
				cmd = "select * from movie where (? >= relDate)  and lang=? order by relDate desc";
				ps = con.prepareStatement(cmd);
				ps.setDate(1, sqlDate);
				ps.setString(2, language);

			}

			ResultSet rs3 = ps.executeQuery();

			while (rs3.next()) {

				int id = rs3.getInt(1);
				String mname = rs3.getString(2);
				String cat = rs3.getString(3);
				String lang = rs3.getString(4);
				String dur = rs3.getString(5);
				String gen = rs3.getString(6);
				String cen = rs3.getString(7);
				String dir = rs3.getString(8);
				String cast = rs3.getString(9);
				String syn = rs3.getString(10);
				String img = rs3.getString(11);
				String rel = rs3.getString(12);
				Movie l = new Movie(id, mname, cat, lang, dur, gen, cen, img, dir, cast, syn, rel);
				log.add(l);
				System.out.println(l);
			}

			if (log.size() != 0) {
				return log;
			}

			else {
				return null;
			}
		} catch (Exception e) {
			System.out.println("all lat mv");
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

	public String getShow(String time, int tid) {

		try {

			Connection con = DbConnection.getConnection();
			String time1 = "";
			String time2 = "";
			String time3 = "";
			String ftime = "";
			String cmd = "select morning,matinee,secondshow from theatre where tId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, tid);
			ResultSet rs3 = ps.executeQuery();
			while (rs3.next()) {
				time1 = rs3.getString(1);
				time2 = rs3.getString(2);
				time3 = rs3.getString(3);
			}

			if (time1.equals(time)) {
				ftime = " morning";
			} else if (time2.equals(time)) {
				ftime = " matinee";
			} else if (time3.equals(time)) {
				ftime = " secondshow";
			}

			return ftime;
		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return null;
	}

}
