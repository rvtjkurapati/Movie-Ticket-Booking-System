package com.virtusa.mtms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.mtms.dto.City;
import com.virtusa.mtms.dto.Customer;
import com.virtusa.mtms.dto.Movie;
import com.virtusa.mtms.dto.Multiplex;
import com.virtusa.mtms.dto.PresentMovie;
import com.virtusa.mtms.dto.Show;
import com.virtusa.mtms.dto.Booking;
import com.virtusa.mtms.dto.Theatre;
import com.virtusa.mtms.dto.Ticket;
import com.virtusa.mtms.service.IBookingServiceImpl;
import com.virtusa.mtms.service.ICityServiceImpl;
import com.virtusa.mtms.service.ICustomerServiceImpl;
import com.virtusa.mtms.service.IMovieServiceImpl;
import com.virtusa.mtms.service.IMultiplexServiceImpl;
import com.virtusa.mtms.service.ITheatreServiceImpl;

@WebServlet("/CustomerController")
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CustomerController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ICustomerServiceImpl cust = new ICustomerServiceImpl();
		ICityServiceImpl city = new ICityServiceImpl();
		IMovieServiceImpl mv = new IMovieServiceImpl();
		IMultiplexServiceImpl mux = new IMultiplexServiceImpl();
		ITheatreServiceImpl ts = new ITheatreServiceImpl();
		IBookingServiceImpl book = new IBookingServiceImpl();
		HttpSession sn = request.getSession();

		ArrayList<City> cl = city.getCity();
		ArrayList<Movie> lmv = ts.getAllLatestMovies();
		ArrayList<Movie> umv = ts.getAllUpcomingMovies();
		String action = request.getParameter("action");
		System.out.println("***");
		System.out.println(action);
		String target = "";
		switch (action) {

		case "Login": {
			String uname = request.getParameter("uname");
			String pwd = request.getParameter("pwd");
			boolean check = cust.ValidateCustomer(uname, pwd);
			if (check == true) {
				sn.setAttribute("LogError", "false");
				sn.setAttribute("cname", "Select Location");
				sn.setAttribute("cityList", cl);
				sn.setAttribute("newMovieList", lmv);
				sn.setAttribute("upComingList", umv);
				ArrayList<Customer> c = cust.SearchByMail(uname);
				String name = cust.getName(uname);
				String phn = cust.getPhn(uname);
				int bal = cust.getBal(uname);
				int id = cust.getId(uname);
				sn.setAttribute("custId", id);
				sn.setAttribute("custName", name);
				sn.setAttribute("custPhn", phn);
				sn.setAttribute("custMail", uname);
				sn.setAttribute("custBal", bal);
				sn.setAttribute("custList", c);
				target = "CustHomepage.jsp";
			} else {
				sn.setAttribute("LogError", "true");
				target = "Signin.jsp";
			}

			break;
		}

		case "Home": {

			sn.setAttribute("cityList", cl);
			sn.setAttribute("newMovieList", lmv);
			sn.setAttribute("upComingList", umv);
			target = "CustHomepage.jsp";

			break;
		}

		case "Signup": {
			String uname = request.getParameter("rname");
			String phone = request.getParameter("rphone");
			String mail = request.getParameter("rmail");
			String pwd = request.getParameter("rpwd");
			Customer c = new Customer(0, pwd, uname, phone, mail, 100);
			boolean check = cust.AddCustomer(c);
			if (check == true) {
				sn.setAttribute("LogError", "false");
				sn.setAttribute("cname", "Select Location");
				sn.setAttribute("cityList", cl);
				sn.setAttribute("newMovieList", lmv);
				sn.setAttribute("upComingList", umv);
				target = "CustHomepage.jsp";
			} else {
				sn.setAttribute("LogError", "true");
				target = "Signin.jsp";
			}

			break;
		}

		case "Book": {
			String img = request.getParameter("img");
			String mname = request.getParameter("mname");
			String lang = request.getParameter("lang");
			String cen = request.getParameter("cen");
			String gen = request.getParameter("gen");
			String dur = request.getParameter("dur");
			int id = Integer.valueOf(request.getParameter("id"));
			String cat = request.getParameter("cat");
			String dir = request.getParameter("dir");
			String cast = request.getParameter("cast");
			String syn = request.getParameter("syn");

			ArrayList<Show> c = ts.getTheatreByMid(id);

			sn.setAttribute("Bimg", img);
			sn.setAttribute("Bname", mname);
			sn.setAttribute("Blang", lang);
			sn.setAttribute("Bcen", cen);
			sn.setAttribute("Bgen", gen);
			sn.setAttribute("Bdur", dur);
			sn.setAttribute("Bmid", id);
			sn.setAttribute("Bcat", cat);
			sn.setAttribute("Bdir", dir);
			sn.setAttribute("Bcast", cast);
			sn.setAttribute("Bsyn", syn);
			sn.setAttribute("BTList", c);
			target = "Booking.jsp";

			break;
		}

		case "editprofile": {
			String uname = request.getParameter("uname");
			String phn = request.getParameter("phn");
			String mail = request.getParameter("mail");
			String pwd = request.getParameter("pwd");
			String id = request.getParameter("uid");
			sn.setAttribute("custName", pwd);
			sn.setAttribute("custPhn", phn);
			sn.setAttribute("custMail", mail);
			sn.setAttribute("custPwd", uname);
			sn.setAttribute("custId", id);
			target = "ModifyUser.jsp";

			break;
		}

		case "Update User": {
			String uname = request.getParameter("muname");
			String phn = request.getParameter("muphone");
			String mail = request.getParameter("mumail");
			String pwd = request.getParameter("mupwd");
			int id = Integer.valueOf(request.getParameter("muid"));
			boolean mod = cust.ModifyCustomer(id, uname, pwd, phn, mail);
			System.out.println(mod);
			if (mod == true) {
				ArrayList<Customer> c = cust.SearchByMail(mail);
				String name = cust.getName(uname);
				sn.setAttribute("custName", name);
				System.out.println(name);
				sn.setAttribute("custList", c);
				target = "UserProfile.jsp";
				sn.setAttribute("ModCust", "true");
			} else {
				sn.setAttribute("ModCust", "false");
				target = "ModifyUser.jsp";
			}

			break;
		}

		case "Continue to pay": {

			int cid = Integer.valueOf(request.getParameter("cid"));
			int tid = Integer.valueOf(request.getParameter("tid"));
//			int  mxid=Integer.valueOf(request.getParameter("mxid"));
			int mxid = 6969;
			int mvid = Integer.valueOf(request.getParameter("mvid"));
			String sd = request.getParameter("sd");
			String st = request.getParameter("st");
			String seats = request.getParameter("seats");
			String phone = request.getParameter("phone");
			String show = request.getParameter("show");
			int screen = Integer.valueOf(request.getParameter("screen"));

			Booking b = new Booking(0, cid, tid, mxid, mvid, sd, show, seats, phone, screen);
			boolean mod = book.BookTicket(b);
			if (mod == true) {
				ArrayList<Booking> c = book.getBookings();
				System.out.println(c);
				sn.setAttribute("custList", c);
			} else {

			}

			break;
		}

		case "bookings": {
			int id = Integer.valueOf(request.getParameter("cid"));
			ArrayList<Ticket> al = book.ShowTicket(id);
			System.out.println(al);
			sn.setAttribute("Ticket", al);
			target = "UserBookings.jsp";

			break;
		}

		case "canceltkt": {
			int bid = Integer.valueOf(request.getParameter("bid"));
			boolean al = book.CancelTicket(bid);
			System.out.println(al);

			int id = Integer.valueOf(request.getParameter("cid"));
			ArrayList<Ticket> tl = book.ShowTicket(id);
			System.out.println(tl);

			sn.setAttribute("Ticket", tl);

			target = "UserBookings.jsp";

			break;
		}

		default:
			break;

		}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
