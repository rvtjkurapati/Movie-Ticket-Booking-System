package com.virtusa.mtms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.virtusa.mtms.dto.Customer;
import com.virtusa.mtms.util.DbConnection;

public class ICustomerDAOImpl {

	public boolean AddCustomer(Customer cust) {

		try {

			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from customer where phone=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1, cust.getPhone());
			ResultSet rs = ps1.executeQuery();

			String cmd3 = "select * from customer where email=?";
			PreparedStatement ps3 = con.prepareStatement(cmd3);
			ps3.setString(1, cust.getEmail());
			ResultSet rs3 = ps3.executeQuery();

			if (!rs.next() && !rs3.next()) {
				String cmd2 = "insert into customer(username,password,phone,email,balance) values(?,?,?,?,?);";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setString(1, cust.getName());
				ps2.setString(2, cust.getPwd());
				ps2.setString(3, cust.getPhone());
				ps2.setString(4, cust.getEmail());
				ps2.setInt(5, cust.getBal());
				ps2.executeUpdate();
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			e.getStackTrace();
		}
		return false;
	}

	public boolean DelCustomer(int s) {

		try {
			Connection con = DbConnection.getConnection();

			String cmd1 = "select * from customer where custId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, s);
			ResultSet rs = ps1.executeQuery();
			if (rs.next()) {
				String cmd2 = "delete from customer where custId=?";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1, s);
				ps2.executeUpdate();
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;

	}

	public boolean ValidateCustomer(String phone, String pwd) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from customer where phone=? and password=?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, phone);
			ps.setString(2, pwd);
			ResultSet rs = ps.executeQuery();

			String cmd1 = "select * from customer where email=? and password=?;";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1, phone);
			ps1.setString(2, pwd);
			ResultSet rs1 = ps1.executeQuery();

			if (rs.next() || rs1.next()) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}

		return false;
	}

	public ArrayList<Customer> getCustomers() {
		ArrayList<Customer> log = new ArrayList<Customer>();
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from customer";
			PreparedStatement ps = con.prepareStatement(cmd);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int id = rs.getInt(1);
				String uName = rs.getString(2);
				String pWord = rs.getString(3);
				String phone = rs.getString(4);
				String mail = rs.getString(5);
				int bal = rs.getInt(6);
				Customer l = new Customer(id, uName, pWord, phone, mail, bal);
				log.add(l);

			}
			if (log.size() != 0) {

				return log;
			} else {
				return null;
			}
		}

		catch (Exception e) {
			e.getStackTrace();
		}
		return null;
	}

	public boolean ModifyCustomer(int id, String uname, String pwd, String phn, String mail) {

		try {
			Connection con = DbConnection.getConnection();
			String cmd1 = "select * from customer where custId=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1, id);
			ResultSet rs = ps1.executeQuery();

			String cmd2 = " select count(phone) from customer where  phone=? and custId!=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setString(1, phn);
			ps2.setInt(2, id);
			ResultSet rs2 = ps2.executeQuery();
			int p = 1;
			int e = 1;
			while (rs2.next()) {
				p = rs2.getInt(1);
			}

			String cmd3 = " select count(email) from customer where email=? and custId!=?";
			PreparedStatement ps3 = con.prepareStatement(cmd3);
			ps3.setString(1, mail);
			ps3.setInt(2, id);
			ResultSet rs3 = ps3.executeQuery();
			while (rs3.next()) {
				e = rs3.getInt(1);
			}
			System.out.println(p);
			System.out.println(e);
			if (rs.next() && (p == 0) && (e == 0)) {

				String cmd = "update  customer  set username=? , password=? , phone=? , email=? where custId=?";
				PreparedStatement ps = con.prepareStatement(cmd);
				ps.setString(1, uname);
				ps.setString(2, pwd);
				ps.setString(3, phn);
				ps.setString(4, mail);
				ps.setInt(5, id);
				ps.executeUpdate();
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}

		return false;
	}

	public ArrayList<Customer> SearchCustomer(String str) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Customer> log = new ArrayList<Customer>();
			String cmd = "select * from  customer  where username like ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, str + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String uName = rs.getString(2);
				String pWord = rs.getString(3);
				String phone = rs.getString(4);
				String mail = rs.getString(5);
				int bal = rs.getInt(6);
				Customer l = new Customer(id, uName, pWord, phone, mail, bal);
				log.add(l);

			}

			if (log.size() > 0) {

				return log;
			}

			else {

				return null;
			}

		}

		catch (Exception e) {
			e.getStackTrace();
		}

		return null;
	}

	public ArrayList<Customer> SearchCustomer(int cid) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Customer> log = new ArrayList<Customer>();
			String cmd = "select * from  customer  where custId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, cid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String uName = rs.getString(2);
				String pWord = rs.getString(3);
				String phone = rs.getString(4);
				String mail = rs.getString(5);
				int bal = rs.getInt(6);
				Customer l = new Customer(id, uName, pWord, phone, mail, bal);
				log.add(l);

			}

			if (log.size() > 0) {

				return log;
			}

			else {

				return null;
			}

		}

		catch (Exception e) {
			e.getStackTrace();
		}

		return null;
	}

	public ArrayList<Customer> SearchByPhone(String str) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Customer> log = new ArrayList<Customer>();
			String cmd = "select * from  customer  where phone like ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, str + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String uName = rs.getString(2);
				String pWord = rs.getString(3);
				String phone = rs.getString(4);
				String mail = rs.getString(5);
				int bal = rs.getInt(6);
				Customer l = new Customer(id, uName, pWord, phone, mail, bal);
				log.add(l);

			}

			if (log.size() > 0) {

				return log;
			}

			else {

				return null;
			}

		}

		catch (Exception e) {
			e.getStackTrace();
		}

		return null;
	}

	public ArrayList<Customer> SearchByMail(String str) {

		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Customer> log = new ArrayList<Customer>();
			String cmd = "select * from  customer  where email like ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, str + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String uName = rs.getString(2);
				String pWord = rs.getString(3);
				String phone = rs.getString(4);
				String mail = rs.getString(5);
				int bal = rs.getInt(6);
				Customer l = new Customer(id, uName, pWord, phone, mail, bal);
				log.add(l);

			}

			if (log.size() > 0) {

				return log;
			}

			else {

				return null;
			}

		}

		catch (Exception e) {
			e.getStackTrace();
		}

		return null;
	}

	public Customer getCustIdPhone(Customer l) {
		try {
			int id = 0;
			String phn = "";
			Customer c = new Customer();
			Connection con = DbConnection.getConnection();
			String cmd = "select custId,phone from customer where username=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, l.getName());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				id = rs.getInt(1);
				phn = rs.getString(2);
				c = new Customer(id, "", "", phn, "", 0);
				return c;
			}
			return null;
		}

		catch (Exception e) {
			e.getStackTrace();
			return null;
		}
	}

	public boolean ValidateId(int id) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select * from customer where custId=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return true;
			}

			else {
				return false;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}

		return false;
	}

	public String getName(String mail) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select username from customer where email=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, mail);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				String s = rs.getString(1);
				return s;
			}

			else {
				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			System.out.println("in this");
			e.getStackTrace();
		}

		return null;
	}

	public String getPhn(String mail) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select phone from customer where email=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, mail);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				String s = rs.getString(1);
				return s;
			}

			else {
				return null;
			}

		} catch (Exception e) {
			System.out.println(e);
			System.out.println("in this");
			e.getStackTrace();
		}

		return null;
	}

	public int getBal(String mail) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select balance from customer where email=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, mail);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				int s = rs.getInt(1);
				return s;
			}

			else {
				return 0;
			}

		} catch (Exception e) {
			System.out.println(e);
			System.out.println("in this");
			e.getStackTrace();
		}

		return 0;
	}

	public int getId(String mail) {
		try {
			Connection con = DbConnection.getConnection();
			String cmd = "select custId from customer where email=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1, mail);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				int s = rs.getInt(1);
				return s;
			}

			else {
				return 0;
			}

		} catch (Exception e) {
			System.out.println(e);
			System.out.println("in this");
			e.getStackTrace();
		}

		return 0;
	}

}
