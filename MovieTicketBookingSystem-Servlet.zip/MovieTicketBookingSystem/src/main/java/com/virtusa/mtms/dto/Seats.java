package com.virtusa.mtms.dto;

public class Seats {

	int movieId;
	int multiplexId;
	String showdate;
	String showtime;
	int A1;
	int A2;
	int A3;
	int A4;
	int A5;
	int A6;
	int A7;
	int A8;
	int A9;
	int A10;
	int A11;
	int A12;
	int B1;
	int B2;
	int B3;
	int B4;
	int B5;
	int B6;
	int B7;
	int B8;
	int B9;
	int B10;
	int B11;
	int B12;
	int C1;
	int C2;
	int C3;
	int C4;
	int C5;
	int C6;
	int C7;
	int C8;
	int C9;
	int C10;
	int C11;
	int C12;
	int D1;
	int D2;
	int D3;
	int D4;
	int D5;
	int D6;
	int D7;
	int D8;
	int D9;
	int D10;
	int D11;
	int D12;
	int E1;
	int E2;
	int E3;
	int E4;
	int E5;
	int E6;
	int E7;
	int E8;
	int E9;
	int E10;
	int E11;
	int E12;
	int F1;
	int F2;
	int F3;
	int F4;
	int F5;
	int F6;
	int F7;
	int F8;
	int F9;
	int F10;
	int F11;
	int F12;
	int G1;
	int G2;
	int G3;
	int G4;
	int G5;
	int G6;
	int G7;
	int G8;
	int G9;
	int G10;
	int G11;
	int G12;
	int H1;
	int H2;
	int H3;
	int H4;
	int H5;
	int H6;
	int H7;
	int H8;
	int H9;
	int H10;
	int H11;
	int H12;
	int I1;
	int I2;
	int I3;
	int I4;
	int I5;
	int I6;
	int I7;
	int I8;
	int I9;
	int I10;
	int I11;
	int I12;
	int J1;
	int J2;
	int J3;
	int J4;
	int J5;
	int J6;
	int J7;
	int J8;
	int J9;
	int J10;
	int J11;
	int J12;

	public Seats() {
		super();
	}

	public Seats(int movieId, int multiplexId, String showdate, String showtime, int a1, int a2, int a3, int a4, int a5,
			int a6, int a7, int a8, int a9, int a10, int a11, int a12, int b1, int b2, int b3, int b4, int b5, int b6,
			int b7, int b8, int b9, int b10, int b11, int b12, int c1, int c2, int c3, int c4, int c5, int c6, int c7,
			int c8, int c9, int c10, int c11, int c12, int d1, int d2, int d3, int d4, int d5, int d6, int d7, int d8,
			int d9, int d10, int d11, int d12, int e1, int e2, int e3, int e4, int e5, int e6, int e7, int e8, int e9,
			int e10, int e11, int e12, int f1, int f2, int f3, int f4, int f5, int f6, int f7, int f8, int f9, int f10,
			int f11, int f12, int g1, int g2, int g3, int g4, int g5, int g6, int g7, int g8, int g9, int g10, int g11,
			int g12, int h1, int h2, int h3, int h4, int h5, int h6, int h7, int h8, int h9, int h10, int h11, int h12,
			int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int j1,
			int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10, int j11, int j12) {
		super();
		this.movieId = movieId;
		this.multiplexId = multiplexId;
		this.showdate = showdate;
		this.showtime = showtime;
		this.A1 = a1;
		this.A2 = a2;
		this.A3 = a3;
		this.A4 = a4;
		this.A5 = a5;
		this.A6 = a6;
		this.A7 = a7;
		this.A8 = a8;
		this.A9 = a9;
		this.A10 = a10;
		this.A11 = a11;
		this.A12 = a12;
		this.B1 = b1;
		this.B2 = b2;
		this.B3 = b3;
		this.B4 = b4;
		this.B5 = b5;
		this.B6 = b6;
		this.B7 = b7;
		this.B8 = b8;
		this.B9 = b9;
		this.B10 = b10;
		this.B11 = b11;
		this.B12 = b12;
		this.C1 = c1;
		this.C2 = c2;
		this.C3 = c3;
		this.C4 = c4;
		this.C5 = c5;
		this.C6 = c6;
		this.C7 = c7;
		this.C8 = c8;
		this.C9 = c9;
		this.C10 = c10;
		this.C11 = c11;
		this.C12 = c12;
		this.D1 = d1;
		this.D2 = d2;
		this.D3 = d3;
		this.D4 = d4;
		this.D5 = d5;
		this.D6 = d6;
		this.D7 = d7;
		this.D8 = d8;
		this.D9 = d9;
		this.D10 = d10;
		this.D11 = d11;
		this.D12 = d12;
		this.E1 = e1;
		this.E2 = e2;
		this.E3 = e3;
		this.E4 = e4;
		this.E5 = e5;
		this.E6 = e6;
		this.E7 = e7;
		this.E8 = e8;
		this.E9 = e9;
		this.E10 = e10;
		this.E11 = e11;
		this.E12 = e12;
		this.F1 = f1;
		this.F2 = f2;
		this.F3 = f3;
		this.F4 = f4;
		this.F5 = f5;
		this.F6 = f6;
		this.F7 = f7;
		this.F8 = f8;
		this.F9 = f9;
		this.F10 = f10;
		this.F11 = f11;
		this.F12 = f12;
		this.G1 = g1;
		this.G2 = g2;
		this.G3 = g3;
		this.G4 = g4;
		this.G5 = g5;
		this.G6 = g6;
		this.G7 = g7;
		this.G8 = g8;
		this.G9 = g9;
		this.G10 = g10;
		this.G11 = g11;
		this.G12 = g12;
		this.H1 = h1;
		this.H2 = h2;
		this.H3 = h3;
		this.H4 = h4;
		this.H5 = h5;
		this.H6 = h6;
		this.H7 = h7;
		this.H8 = h8;
		this.H9 = h9;
		this.H10 = h10;
		this.H11 = h11;
		this.H12 = h12;
		this.I1 = i1;
		this.I2 = i2;
		this.I3 = i3;
		this.I4 = i4;
		this.I5 = i5;
		this.I6 = i6;
		this.I7 = i7;
		this.I8 = i8;
		this.I9 = i9;
		this.I10 = i10;
		this.I11 = i11;
		this.I12 = i12;
		this.J1 = j1;
		this.J2 = j2;
		this.J3 = j3;
		this.J4 = j4;
		this.J5 = j5;
		this.J6 = j6;
		this.J7 = j7;
		this.J8 = j8;
		this.J9 = j9;
		this.J10 = j10;
		this.J11 = j11;
		this.J12 = j12;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public int getMultiplexId() {
		return multiplexId;
	}

	public void setMultiplexId(int multiplexId) {
		this.multiplexId = multiplexId;
	}

	public String getShowdate() {
		return showdate;
	}

	public void setShowdate(String showdate) {
		this.showdate = showdate;
	}

	public String getShowtime() {
		return showtime;
	}

	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}

	public int getA1() {
		return A1;
	}

	public void setA1(int a1) {
		A1 = a1;
	}

	public int getA2() {
		return A2;
	}

	public void setA2(int a2) {
		A2 = a2;
	}

	public int getA3() {
		return A3;
	}

	public void setA3(int a3) {
		A3 = a3;
	}

	public int getA4() {
		return A4;
	}

	public void setA4(int a4) {
		A4 = a4;
	}

	public int getA5() {
		return A5;
	}

	public void setA5(int a5) {
		A5 = a5;
	}

	public int getA6() {
		return A6;
	}

	public void setA6(int a6) {
		A6 = a6;
	}

	public int getA7() {
		return A7;
	}

	public void setA7(int a7) {
		A7 = a7;
	}

	public int getA8() {
		return A8;
	}

	public void setA8(int a8) {
		A8 = a8;
	}

	public int getA9() {
		return A9;
	}

	public void setA9(int a9) {
		A9 = a9;
	}

	public int getA10() {
		return A10;
	}

	public void setA10(int a10) {
		A10 = a10;
	}

	public int getA11() {
		return A11;
	}

	public void setA11(int a11) {
		A11 = a11;
	}

	public int getA12() {
		return A12;
	}

	public void setA12(int a12) {
		A12 = a12;
	}

	public int getB1() {
		return B1;
	}

	public void setB1(int b1) {
		B1 = b1;
	}

	public int getB2() {
		return B2;
	}

	public void setB2(int b2) {
		B2 = b2;
	}

	public int getB3() {
		return B3;
	}

	public void setB3(int b3) {
		B3 = b3;
	}

	public int getB4() {
		return B4;
	}

	public void setB4(int b4) {
		B4 = b4;
	}

	public int getB5() {
		return B5;
	}

	public void setB5(int b5) {
		B5 = b5;
	}

	public int getB6() {
		return B6;
	}

	public void setB6(int b6) {
		B6 = b6;
	}

	public int getB7() {
		return B7;
	}

	public void setB7(int b7) {
		B7 = b7;
	}

	public int getB8() {
		return B8;
	}

	public void setB8(int b8) {
		B8 = b8;
	}

	public int getB9() {
		return B9;
	}

	public void setB9(int b9) {
		B9 = b9;
	}

	public int getB10() {
		return B10;
	}

	public void setB10(int b10) {
		B10 = b10;
	}

	public int getB11() {
		return B11;
	}

	public void setB11(int b11) {
		B11 = b11;
	}

	public int getB12() {
		return B12;
	}

	public void setB12(int b12) {
		B12 = b12;
	}

	public int getC1() {
		return C1;
	}

	public void setC1(int c1) {
		C1 = c1;
	}

	public int getC2() {
		return C2;
	}

	public void setC2(int c2) {
		C2 = c2;
	}

	public int getC3() {
		return C3;
	}

	public void setC3(int c3) {
		C3 = c3;
	}

	public int getC4() {
		return C4;
	}

	public void setC4(int c4) {
		C4 = c4;
	}

	public int getC5() {
		return C5;
	}

	public void setC5(int c5) {
		C5 = c5;
	}

	public int getC6() {
		return C6;
	}

	public void setC6(int c6) {
		C6 = c6;
	}

	public int getC7() {
		return C7;
	}

	public void setC7(int c7) {
		C7 = c7;
	}

	public int getC8() {
		return C8;
	}

	public void setC8(int c8) {
		C8 = c8;
	}

	public int getC9() {
		return C9;
	}

	public void setC9(int c9) {
		C9 = c9;
	}

	public int getC10() {
		return C10;
	}

	public void setC10(int c10) {
		C10 = c10;
	}

	public int getC11() {
		return C11;
	}

	public void setC11(int c11) {
		C11 = c11;
	}

	public int getC12() {
		return C12;
	}

	public void setC12(int c12) {
		C12 = c12;
	}

	public int getD1() {
		return D1;
	}

	public void setD1(int d1) {
		D1 = d1;
	}

	public int getD2() {
		return D2;
	}

	public void setD2(int d2) {
		D2 = d2;
	}

	public int getD3() {
		return D3;
	}

	public void setD3(int d3) {
		D3 = d3;
	}

	public int getD4() {
		return D4;
	}

	public void setD4(int d4) {
		D4 = d4;
	}

	public int getD5() {
		return D5;
	}

	public void setD5(int d5) {
		D5 = d5;
	}

	public int getD6() {
		return D6;
	}

	public void setD6(int d6) {
		D6 = d6;
	}

	public int getD7() {
		return D7;
	}

	public void setD7(int d7) {
		D7 = d7;
	}

	public int getD8() {
		return D8;
	}

	public void setD8(int d8) {
		D8 = d8;
	}

	public int getD9() {
		return D9;
	}

	public void setD9(int d9) {
		D9 = d9;
	}

	public int getD10() {
		return D10;
	}

	public void setD10(int d10) {
		D10 = d10;
	}

	public int getD11() {
		return D11;
	}

	public void setD11(int d11) {
		D11 = d11;
	}

	public int getD12() {
		return D12;
	}

	public void setD12(int d12) {
		D12 = d12;
	}

	public int getE1() {
		return E1;
	}

	public void setE1(int e1) {
		E1 = e1;
	}

	public int getE2() {
		return E2;
	}

	public void setE2(int e2) {
		E2 = e2;
	}

	public int getE3() {
		return E3;
	}

	public void setE3(int e3) {
		E3 = e3;
	}

	public int getE4() {
		return E4;
	}

	public void setE4(int e4) {
		E4 = e4;
	}

	public int getE5() {
		return E5;
	}

	public void setE5(int e5) {
		E5 = e5;
	}

	public int getE6() {
		return E6;
	}

	public void setE6(int e6) {
		E6 = e6;
	}

	public int getE7() {
		return E7;
	}

	public void setE7(int e7) {
		E7 = e7;
	}

	public int getE8() {
		return E8;
	}

	public void setE8(int e8) {
		E8 = e8;
	}

	public int getE9() {
		return E9;
	}

	public void setE9(int e9) {
		E9 = e9;
	}

	public int getE10() {
		return E10;
	}

	public void setE10(int e10) {
		E10 = e10;
	}

	public int getE11() {
		return E11;
	}

	public void setE11(int e11) {
		E11 = e11;
	}

	public int getE12() {
		return E12;
	}

	public void setE12(int e12) {
		E12 = e12;
	}

	public int getF1() {
		return F1;
	}

	public void setF1(int f1) {
		F1 = f1;
	}

	public int getF2() {
		return F2;
	}

	public void setF2(int f2) {
		F2 = f2;
	}

	public int getF3() {
		return F3;
	}

	public void setF3(int f3) {
		F3 = f3;
	}

	public int getF4() {
		return F4;
	}

	public void setF4(int f4) {
		F4 = f4;
	}

	public int getF5() {
		return F5;
	}

	public void setF5(int f5) {
		F5 = f5;
	}

	public int getF6() {
		return F6;
	}

	public void setF6(int f6) {
		F6 = f6;
	}

	public int getF7() {
		return F7;
	}

	public void setF7(int f7) {
		F7 = f7;
	}

	public int getF8() {
		return F8;
	}

	public void setF8(int f8) {
		F8 = f8;
	}

	public int getF9() {
		return F9;
	}

	public void setF9(int f9) {
		F9 = f9;
	}

	public int getF10() {
		return F10;
	}

	public void setF10(int f10) {
		F10 = f10;
	}

	public int getF11() {
		return F11;
	}

	public void setF11(int f11) {
		F11 = f11;
	}

	public int getF12() {
		return F12;
	}

	public void setF12(int f12) {
		F12 = f12;
	}

	public int getG1() {
		return G1;
	}

	public void setG1(int g1) {
		G1 = g1;
	}

	public int getG2() {
		return G2;
	}

	public void setG2(int g2) {
		G2 = g2;
	}

	public int getG3() {
		return G3;
	}

	public void setG3(int g3) {
		G3 = g3;
	}

	public int getG4() {
		return G4;
	}

	public void setG4(int g4) {
		G4 = g4;
	}

	public int getG5() {
		return G5;
	}

	public void setG5(int g5) {
		G5 = g5;
	}

	public int getG6() {
		return G6;
	}

	public void setG6(int g6) {
		G6 = g6;
	}

	public int getG7() {
		return G7;
	}

	public void setG7(int g7) {
		G7 = g7;
	}

	public int getG8() {
		return G8;
	}

	public void setG8(int g8) {
		G8 = g8;
	}

	public int getG9() {
		return G9;
	}

	public void setG9(int g9) {
		G9 = g9;
	}

	public int getG10() {
		return G10;
	}

	public void setG10(int g10) {
		G10 = g10;
	}

	public int getG11() {
		return G11;
	}

	public void setG11(int g11) {
		G11 = g11;
	}

	public int getG12() {
		return G12;
	}

	public void setG12(int g12) {
		G12 = g12;
	}

	public int getH1() {
		return H1;
	}

	public void setH1(int h1) {
		H1 = h1;
	}

	public int getH2() {
		return H2;
	}

	public void setH2(int h2) {
		H2 = h2;
	}

	public int getH3() {
		return H3;
	}

	public void setH3(int h3) {
		H3 = h3;
	}

	public int getH4() {
		return H4;
	}

	public void setH4(int h4) {
		H4 = h4;
	}

	public int getH5() {
		return H5;
	}

	public void setH5(int h5) {
		H5 = h5;
	}

	public int getH6() {
		return H6;
	}

	public void setH6(int h6) {
		H6 = h6;
	}

	public int getH7() {
		return H7;
	}

	public void setH7(int h7) {
		H7 = h7;
	}

	public int getH8() {
		return H8;
	}

	public void setH8(int h8) {
		H8 = h8;
	}

	public int getH9() {
		return H9;
	}

	public void setH9(int h9) {
		H9 = h9;
	}

	public int getH10() {
		return H10;
	}

	public void setH10(int h10) {
		H10 = h10;
	}

	public int getH11() {
		return H11;
	}

	public void setH11(int h11) {
		H11 = h11;
	}

	public int getH12() {
		return H12;
	}

	public void setH12(int h12) {
		H12 = h12;
	}

	public int getI1() {
		return I1;
	}

	public void setI1(int i1) {
		I1 = i1;
	}

	public int getI2() {
		return I2;
	}

	public void setI2(int i2) {
		I2 = i2;
	}

	public int getI3() {
		return I3;
	}

	public void setI3(int i3) {
		I3 = i3;
	}

	public int getI4() {
		return I4;
	}

	public void setI4(int i4) {
		I4 = i4;
	}

	public int getI5() {
		return I5;
	}

	public void setI5(int i5) {
		I5 = i5;
	}

	public int getI6() {
		return I6;
	}

	public void setI6(int i6) {
		I6 = i6;
	}

	public int getI7() {
		return I7;
	}

	public void setI7(int i7) {
		I7 = i7;
	}

	public int getI8() {
		return I8;
	}

	public void setI8(int i8) {
		I8 = i8;
	}

	public int getI9() {
		return I9;
	}

	public void setI9(int i9) {
		I9 = i9;
	}

	public int getI10() {
		return I10;
	}

	public void setI10(int i10) {
		I10 = i10;
	}

	public int getI11() {
		return I11;
	}

	public void setI11(int i11) {
		I11 = i11;
	}

	public int getI12() {
		return I12;
	}

	public void setI12(int i12) {
		I12 = i12;
	}

	public int getJ1() {
		return J1;
	}

	public void setJ1(int j1) {
		J1 = j1;
	}

	public int getJ2() {
		return J2;
	}

	public void setJ2(int j2) {
		J2 = j2;
	}

	public int getJ3() {
		return J3;
	}

	public void setJ3(int j3) {
		J3 = j3;
	}

	public int getJ4() {
		return J4;
	}

	public void setJ4(int j4) {
		J4 = j4;
	}

	public int getJ5() {
		return J5;
	}

	public void setJ5(int j5) {
		J5 = j5;
	}

	public int getJ6() {
		return J6;
	}

	public void setJ6(int j6) {
		J6 = j6;
	}

	public int getJ7() {
		return J7;
	}

	public void setJ7(int j7) {
		J7 = j7;
	}

	public int getJ8() {
		return J8;
	}

	public void setJ8(int j8) {
		J8 = j8;
	}

	public int getJ9() {
		return J9;
	}

	public void setJ9(int j9) {
		J9 = j9;
	}

	public int getJ10() {
		return J10;
	}

	public void setJ10(int j10) {
		J10 = j10;
	}

	public int getJ11() {
		return J11;
	}

	public void setJ11(int j11) {
		J11 = j11;
	}

	public int getJ12() {
		return J12;
	}

	public void setJ12(int j12) {
		J12 = j12;
	}

	@Override
	public String toString() {
		return "MatineeSeats [movieId=" + movieId + ", multiplexId=" + multiplexId + ", showdate=" + showdate
				+ ", showtime=" + showtime + ", A1=" + A1 + ", A2=" + A2 + ", A3=" + A3 + ", A4=" + A4 + ", A5=" + A5
				+ ", A6=" + A6 + ", A7=" + A7 + ", A8=" + A8 + ", A9=" + A9 + ", A10=" + A10 + ", A11=" + A11 + ", A12="
				+ A12 + ", B1=" + B1 + ", B2=" + B2 + ", B3=" + B3 + ", B4=" + B4 + ", B5=" + B5 + ", B6=" + B6
				+ ", B7=" + B7 + ", B8=" + B8 + ", B9=" + B9 + ", B10=" + B10 + ", B11=" + B11 + ", B12=" + B12
				+ ", C1=" + C1 + ", C2=" + C2 + ", C3=" + C3 + ", C4=" + C4 + ", C5=" + C5 + ", C6=" + C6 + ", C7=" + C7
				+ ", C8=" + C8 + ", C9=" + C9 + ", C10=" + C10 + ", C11=" + C11 + ", C12=" + C12 + ", D1=" + D1
				+ ", D2=" + D2 + ", D3=" + D3 + ", D4=" + D4 + ", D5=" + D5 + ", D6=" + D6 + ", D7=" + D7 + ", D8=" + D8
				+ ", D9=" + D9 + ", D10=" + D10 + ", D11=" + D11 + ", D12=" + D12 + ", E1=" + E1 + ", E2=" + E2
				+ ", E3=" + E3 + ", E4=" + E4 + ", E5=" + E5 + ", E6=" + E6 + ", E7=" + E7 + ", E8=" + E8 + ", E9=" + E9
				+ ", E10=" + E10 + ", E11=" + E11 + ", E12=" + E12 + ", F1=" + F1 + ", F2=" + F2 + ", F3=" + F3
				+ ", F4=" + F4 + ", F5=" + F5 + ", F6=" + F6 + ", F7=" + F7 + ", F8=" + F8 + ", F9=" + F9 + ", F10="
				+ F10 + ", F11=" + F11 + ", F12=" + F12 + ", G1=" + G1 + ", G2=" + G2 + ", G3=" + G3 + ", G4=" + G4
				+ ", G5=" + G5 + ", G6=" + G6 + ", G7=" + G7 + ", G8=" + G8 + ", G9=" + G9 + ", G10=" + G10 + ", G11="
				+ G11 + ", G12=" + G12 + ", H1=" + H1 + ", H2=" + H2 + ", H3=" + H3 + ", H4=" + H4 + ", H5=" + H5
				+ ", H6=" + H6 + ", H7=" + H7 + ", H8=" + H8 + ", H9=" + H9 + ", H10=" + H10 + ", H11=" + H11 + ", H12="
				+ H12 + ", I1=" + I1 + ", I2=" + I2 + ", I3=" + I3 + ", I4=" + I4 + ", I5=" + I5 + ", I6=" + I6
				+ ", I7=" + I7 + ", I8=" + I8 + ", I9=" + I9 + ", I10=" + I10 + ", I11=" + I11 + ", I12=" + I12
				+ ", J1=" + J1 + ", J2=" + J2 + ", J3=" + J3 + ", J4=" + J4 + ", J5=" + J5 + ", J6=" + J6 + ", J7=" + J7
				+ ", J8=" + J8 + ", J9=" + J9 + ", J10=" + J10 + ", J11=" + J11 + ", J12=" + J12 + "]";
	}

}
