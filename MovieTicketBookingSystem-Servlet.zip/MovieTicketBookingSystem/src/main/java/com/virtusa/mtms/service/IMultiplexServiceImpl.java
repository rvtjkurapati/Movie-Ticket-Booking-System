package com.virtusa.mtms.service;

import java.util.ArrayList;

import com.virtusa.mtms.dto.CityLocMux;
import com.virtusa.mtms.dto.Multiplex;

public class IMultiplexServiceImpl implements IMultiplex{
	
IMultiplexServiceImpl dao;
	
	
	public boolean AddMultiplex(Multiplex l)
	{
		dao=new IMultiplexServiceImpl();
		boolean flag=dao.AddMultiplex(l);
		return flag;
	}
	public boolean DelMultiplex(int s)
	{
		dao=new IMultiplexServiceImpl();
		boolean flag=dao.DelMultiplex(s);
		return flag;
	}
	public ArrayList<Multiplex> getMultiplex()
	{
		dao=new IMultiplexServiceImpl();
		ArrayList<Multiplex> al= dao.getMultiplex();
		return al;
	}
	public boolean ModifyMultiplex(int l,int cid,int lid,String name,String add)
	{
		dao=new IMultiplexServiceImpl();
		boolean flag=dao.ModifyMultiplex(l, cid, lid, name, add);
		return flag;
	}
	public ArrayList<Multiplex> SearchMultiplex(String str)
	{
		dao=new IMultiplexServiceImpl();
		ArrayList<Multiplex> al= dao.SearchMultiplex(str);
		return al;
	}
	
	public ArrayList<Multiplex> SearchMultiplexByMid(int id)
	{
		dao=new IMultiplexServiceImpl();
		ArrayList<Multiplex> al= dao.SearchMultiplexByMid(id);
		return al;
	}
	
	public ArrayList<Multiplex> SearchMultiplexByLid(int id)
	{
		dao=new IMultiplexServiceImpl();
		ArrayList<Multiplex> al= dao.SearchMultiplexByLid(id);
		return al;
	}
	
	public ArrayList<Multiplex> SearchMultiplexByCid(int id)
	{
		dao=new IMultiplexServiceImpl();
		ArrayList<Multiplex> al= dao.SearchMultiplexByCid(id);
		return al;
	}
	public String getMxname(int id)
	{
		dao=new IMultiplexServiceImpl();
		String al= dao.getMxname(id);
		return al;
	}
	
	public ArrayList<CityLocMux> getMList()
	{
		dao=new IMultiplexServiceImpl();
		ArrayList<CityLocMux> al= dao.getMList();
		return al;
	}
	
	public int getLid(String id)
	{
		dao=new IMultiplexServiceImpl();
		int al= dao.getLid(id);
		return al;
	}
	
	public int getCid(String id)
	{
		dao=new IMultiplexServiceImpl();
		int al= dao.getCid(id);
		return al;
	}

}
