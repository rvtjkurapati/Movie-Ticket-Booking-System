package com.virtusa.mtms.service;

public interface ISAdmin {
	public boolean Validate(String name, String pwd);

	public boolean Modify(String name, String pwd);

}
