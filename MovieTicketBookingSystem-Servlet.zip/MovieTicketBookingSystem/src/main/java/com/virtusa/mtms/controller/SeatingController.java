package com.virtusa.mtms.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.mtms.dto.Seats;
import com.virtusa.mtms.service.IBookingServiceImpl;

/**
 * Servlet implementation class Seating
 */
@WebServlet("/Seating")
public class SeatingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SeatingController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IBookingServiceImpl mul = new IBookingServiceImpl();
		HttpSession sn = request.getSession();

		String action = request.getParameter("action");
		String target = "";
		switch (action) {

		case "Search": {
			String mxname = request.getParameter("mxname");
			String add = request.getParameter("add");
			int tid = Integer.valueOf(request.getParameter("tid"));
			String screen = request.getParameter("screen");
			String show = request.getParameter("show1");
			String showdate = request.getParameter("s1");
			String price = request.getParameter("price");

			show = " " + show;

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String s = LocalDate.parse(showdate, formatter).format(formatter2);

			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("MMMM-dd-yyyy");
			String styled = LocalDate.parse(showdate, formatter1).format(formatter3);
			styled = styled.replace('-', ' ');

			String showtime = mul.getTime(tid, s, show);
			System.out.println(tid);
			System.out.println(s);
			System.out.println(show);
			System.out.println(showtime);

			sn.setAttribute("Smxname", mxname);
			sn.setAttribute("Slname", add);
			sn.setAttribute("Stid", tid);
			sn.setAttribute("Sscreen", screen);
			sn.setAttribute("Show", show);
			sn.setAttribute("Sshow", showtime);
			sn.setAttribute("Sdate", s);
			sn.setAttribute("Stdate", styled);
			sn.setAttribute("Sprice", price);

			if (show.equals(" morning")) {

				ArrayList<Seats> morn = mul.getMorningSeats(s, tid);
				sn.setAttribute("mul", morn);
			}

			else if (show.equals(" matinee")) {
				ArrayList<Seats> mat = mul.getMatineeSeats(s, tid);
				sn.setAttribute("mul", mat);
			} else if (show.equals(" secondshow")) {
				ArrayList<Seats> sec = mul.getSecondShowSeats(s, tid);
				sn.setAttribute("mul", sec);
			}

			target = "Seating.jsp";
			break;
		}

		case "GSearch": {
			String mxname = request.getParameter("mxname");
			String add = request.getParameter("add");
			int tid = Integer.valueOf(request.getParameter("tid"));
			String screen = request.getParameter("screen");
			String show = request.getParameter("show1");
			String showdate = request.getParameter("s1");
			String price = request.getParameter("price");

			show = " " + show;

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String s = LocalDate.parse(showdate, formatter).format(formatter2);

			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("MMMM-dd-yyyy");
			String styled = LocalDate.parse(showdate, formatter1).format(formatter3);
			styled = styled.replace('-', ' ');

			String showtime = mul.getTime(tid, s, show);
			System.out.println(tid);
			System.out.println(s);
			System.out.println(show);
			System.out.println(showtime);

			sn.setAttribute("Smxname", mxname);
			sn.setAttribute("Slname", add);
			sn.setAttribute("Stid", tid);
			sn.setAttribute("Sscreen", screen);
			sn.setAttribute("Show", show);
			sn.setAttribute("Sshow", showtime);
			sn.setAttribute("Sdate", s);
			sn.setAttribute("Stdate", styled);
			sn.setAttribute("Sprice", price);

			if (show.equals(" morning")) {

				ArrayList<Seats> morn = mul.getMorningSeats(s, tid);
				sn.setAttribute("mul", morn);
			}

			else if (show.equals(" matinee")) {
				ArrayList<Seats> mat = mul.getMatineeSeats(s, tid);
				sn.setAttribute("mul", mat);
			} else if (show.equals(" secondshow")) {
				ArrayList<Seats> sec = mul.getSecondShowSeats(s, tid);
				sn.setAttribute("mul", sec);
			}

			target = "GuestSeating.jsp";
			break;
		}

		case "new": {

			String mxname = request.getParameter("mxname");
			String add = request.getParameter("add");
			int tid = Integer.valueOf(request.getParameter("tid"));
			String screen = request.getParameter("screen");
			String show = request.getParameter("show");
			String showdate = request.getParameter("showdate");
			String price = request.getParameter("price");

			System.out.println(mxname);
			System.out.println(add);
			System.out.println(tid);
			System.out.println(screen);
			System.out.println(show);
			System.out.println(showdate);
			System.out.println(price);

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String s = LocalDate.parse(showdate, formatter).format(formatter2);

			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("MMMM-dd-yyyy");
			String styled = LocalDate.parse(showdate, formatter1).format(formatter3);
			styled = styled.replace('-', ' ');

			String showtime = mul.getTime(tid, s, show);

			sn.setAttribute("Smxname", mxname);
			sn.setAttribute("Slname", add);
			sn.setAttribute("Stid", tid);
			sn.setAttribute("Sscreen", screen);
			sn.setAttribute("Show", show);
			sn.setAttribute("Sshow", showtime);
			sn.setAttribute("Sdate", s);
			sn.setAttribute("Stdate", styled);
			sn.setAttribute("Sprice", price);

			if (show.equals(" morning")) {

				ArrayList<Seats> morn = mul.getMorningSeats(s, tid);
				sn.setAttribute("mul", morn);
			}

			else if (show.equals(" matinee")) {
				ArrayList<Seats> mat = mul.getMatineeSeats(s, tid);
				sn.setAttribute("mul", mat);
			} else if (show.equals(" secondshow")) {
				ArrayList<Seats> sec = mul.getSecondShowSeats(s, tid);
				sn.setAttribute("mul", sec);
			}
			target = "Seating.jsp";
			break;

		}

		case "guest": {

			String mxname = request.getParameter("mxname");
			String add = request.getParameter("add");
			int tid = Integer.valueOf(request.getParameter("tid"));
			String screen = request.getParameter("screen");
			String show = request.getParameter("show");
			String showdate = request.getParameter("showdate");
			String price = request.getParameter("price");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String s = LocalDate.parse(showdate, formatter).format(formatter2);

			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("MMMM-dd-yyyy");
			String styled = LocalDate.parse(showdate, formatter1).format(formatter3);
			styled = styled.replace('-', ' ');

			String showtime = mul.getTime(tid, s, show);
			sn.setAttribute("Showdate", showdate);
			sn.setAttribute("Smxname", mxname);
			sn.setAttribute("Slname", add);
			sn.setAttribute("Stid", tid);
			sn.setAttribute("Sscreen", screen);
			sn.setAttribute("Show", show);
			sn.setAttribute("Sshow", showtime);
			sn.setAttribute("Sdate", s);
			sn.setAttribute("Stdate", styled);
			sn.setAttribute("Sprice", price);

			if (show.equals(" morning")) {

				ArrayList<Seats> morn = mul.getMorningSeats(s, tid);
				sn.setAttribute("mul", morn);
			}

			else if (show.equals(" matinee")) {
				ArrayList<Seats> mat = mul.getMatineeSeats(s, tid);
				sn.setAttribute("mul", mat);
			} else if (show.equals(" secondshow")) {
				ArrayList<Seats> sec = mul.getSecondShowSeats(s, tid);
				sn.setAttribute("mul", sec);
			}
			target = "GuestSeating.jsp";
			break;

		}
		}

		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
