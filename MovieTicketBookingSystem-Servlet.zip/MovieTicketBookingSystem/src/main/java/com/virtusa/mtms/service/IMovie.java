package com.virtusa.mtms.service;

import java.util.ArrayList;

import com.virtusa.mtms.dto.Movie;

public interface IMovie {

	public boolean AddMovie(Movie m);

	public boolean DelMovie(int s);

	public ArrayList<Movie> getMovies();

	public boolean ModifyMovie(Movie l);

	public ArrayList<Movie> SearchMovie(String name);

	public boolean ValMovieId(int d);

	public String SuggestMovie();
	// public ArrayList<Availability> CheckSeatAvail(String m);

}
