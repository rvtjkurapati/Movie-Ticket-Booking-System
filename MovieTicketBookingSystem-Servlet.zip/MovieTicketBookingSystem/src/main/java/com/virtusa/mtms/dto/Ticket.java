package com.virtusa.mtms.dto;

public class Ticket {

	int bid;
	int custid;
	int mxid;
	String img;
	String mname;
	String cen;
	String lang;
	String dur;
	String cat;
	String mxname;
	String loc;
	String date;
	String showt;
	String seats;
	int screen;

	public Ticket() {
		super();
	}

	public Ticket(int bid, int custid, int mxid, String img, String mname, String cen, String lang, String dur,
			String cat, String mxname, String loc, String date, String showt, String seats, int screen) {
		super();
		this.bid = bid;
		this.custid = custid;
		this.mxid = mxid;
		this.img = img;
		this.mname = mname;
		this.cen = cen;
		this.lang = lang;
		this.dur = dur;
		this.cat = cat;
		this.mxname = mxname;
		this.loc = loc;
		this.date = date;
		this.showt = showt;
		this.seats = seats;
		this.screen = screen;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public int getCustid() {
		return custid;
	}

	public void setCustid(int custid) {
		this.custid = custid;
	}

	public int getMxid() {
		return mxid;
	}

	public void setMxid(int mxid) {
		this.mxid = mxid;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getCen() {
		return cen;
	}

	public void setCen(String cen) {
		this.cen = cen;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getDur() {
		return dur;
	}

	public void setDur(String dur) {
		this.dur = dur;
	}

	public String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}

	public String getMxname() {
		return mxname;
	}

	public void setMxname(String mxname) {
		this.mxname = mxname;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getShowt() {
		return showt;
	}

	public void setShowt(String showt) {
		this.showt = showt;
	}

	public String getSeats() {
		return seats;
	}

	public void setSeats(String seats) {
		this.seats = seats;
	}

	public int getScreen() {
		return screen;
	}

	public void setScreen(int screen) {
		this.screen = screen;
	}

	@Override
	public String toString() {
		return "Ticket [bid=" + bid + ", custid=" + custid + ", mxid=" + mxid + ", img=" + img + ", mname=" + mname
				+ ", cen=" + cen + ", lang=" + lang + ", dur=" + dur + ", cat=" + cat + ", mxname=" + mxname + ", loc="
				+ loc + ", date=" + date + ", showt=" + showt + ", seats=" + seats + ", screen=" + screen + "]";
	}

}
